class <lambda>(torch.nn.Module):
    def forward(self, arg0_1: "f32[128, 1024]", arg1_1: "f32[1024, 1024]", arg2_1: "f32[1024, 2048]", arg3_1: "f32[2048]", arg4_1: "f32[2048, 1024]", arg5_1: "f32[1024]"):
        # File: /w/composed-matrix/matrix_torch.py:17 in graph, code: p=xi@wo;hr=p@up;h=torch.relu(hr+b1);mr=h@down;m=mr+b2;y=(p+m)*.25
        mm: "f32[128, 1024]" = torch.ops.aten.mm.default(arg0_1, arg1_1);  arg0_1 = arg1_1 = None
        mm_1: "f32[128, 2048]" = torch.ops.aten.mm.default(mm, arg2_1);  arg2_1 = None
        add: "f32[128, 2048]" = torch.ops.aten.add.Tensor(mm_1, arg3_1);  arg3_1 = None
        relu: "f32[128, 2048]" = torch.ops.aten.relu.default(add);  add = None
        mm_2: "f32[128, 1024]" = torch.ops.aten.mm.default(relu, arg4_1);  arg4_1 = None
        add_1: "f32[128, 1024]" = torch.ops.aten.add.Tensor(mm_2, arg5_1);  arg5_1 = None
        add_2: "f32[128, 1024]" = torch.ops.aten.add.Tensor(mm, add_1)
        mul: "f32[128, 1024]" = torch.ops.aten.mul.Tensor(add_2, 0.25);  add_2 = None
        return (mm, mm_1, relu, mm_2, add_1, mul)
