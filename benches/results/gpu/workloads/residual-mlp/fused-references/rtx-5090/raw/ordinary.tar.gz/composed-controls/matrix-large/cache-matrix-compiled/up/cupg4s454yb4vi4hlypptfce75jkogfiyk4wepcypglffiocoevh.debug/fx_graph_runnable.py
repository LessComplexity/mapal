
import os
os.environ['TORCHINDUCTOR_CACHE_DIR'] = '/w/trace/composed-controls/matrix-large/cache-matrix-compiled'
os.environ['TORCH_LOGS'] = 'graph_breaks,recompiles,output_code'
os.environ['TORCH_COMPILE_DEBUG'] = '1'
os.environ.pop('TORCHDYNAMO_REPRO_AFTER', None)
os.environ.pop('TORCHDYNAMO_REPRO_LEVEL', None)

import torch
from torch import tensor, device
import torch.fx as fx
from torch._dynamo.testing import rand_strided
from math import inf
import torch._inductor.inductor_prims



import torch._dynamo.config
import torch._inductor.config
import torch._functorch.config
import torch.fx.experimental._config
torch._dynamo.config.assume_static_by_default = True
torch._dynamo.config.automatic_dynamic_shapes = False
torch._dynamo.config.suppress_errors = False
torch._inductor.config.deterministic = True
torch._inductor.config.triton.cudagraphs = False
torch._inductor.config.trace.enabled = False
torch._inductor.config.trace.save_real_tensors = False
torch._functorch.config.functionalize_rng_ops = False
torch._functorch.config.debug_partitioner = True
torch._functorch.config.fake_tensor_allow_unsafe_data_ptr_access = True
torch._functorch.config.unlift_effect_tokens = True
torch._functorch.config.selective_decompose = False



isolate_fails_code_str = None





if "__compile_source__" in globals():
    import inspect as __after_aot_inspect
    import linecache as __after_aot_linecache
    __after_aot_filename = __after_aot_inspect.currentframe().f_code.co_filename
    __after_aot_linecache.cache[__after_aot_filename] = (
        len(__compile_source__),
        None,
        __compile_source__.splitlines(True),
        __after_aot_filename,
    )
# torch version: 2.13.0+cu130
# torch cuda version: 13.0
# torch git version: cf30153c4c131c8164ee7798e5022d810682e2cb


# CUDA Info: 
# nvcc: NVIDIA (R) Cuda compiler driver 
# Copyright (c) 2005-2025 NVIDIA Corporation 
# Built on Fri_Feb_21_20:23:50_PST_2025 
# Cuda compilation tools, release 12.8, V12.8.93 
# Build cuda_12.8.r12.8/compiler.35583870_0 

# GPU Hardware Info: 
# NVIDIA GeForce RTX 5090 : 1 

torch._higher_order_ops.triton_kernel_wrap.kernel_side_table.reset_table()

from torch.nn import *
class Repro(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()



    def forward(self, arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1):
        mm = torch.ops.aten.mm.default(arg0_1, arg1_1);  arg0_1 = arg1_1 = None
        mm_1 = torch.ops.aten.mm.default(mm, arg2_1);  arg2_1 = None
        add = torch.ops.aten.add.Tensor(mm_1, arg3_1);  arg3_1 = None
        relu = torch.ops.aten.relu.default(add);  add = None
        mm_2 = torch.ops.aten.mm.default(relu, arg4_1);  arg4_1 = None
        add_1 = torch.ops.aten.add.Tensor(mm_2, arg5_1);  arg5_1 = None
        add_2 = torch.ops.aten.add.Tensor(mm, add_1)
        mul = torch.ops.aten.mul.Tensor(add_2, 0.25);  add_2 = None
        return (mm, mm_1, relu, mm_2, add_1, mul)

def load_args(reader):
    buf0 = reader.storage(None, 524288, device=device(type='cuda', index=0))
    reader.tensor(buf0, (128, 1024), is_leaf=True)  # arg0_1
    buf1 = reader.storage(None, 4194304, device=device(type='cuda', index=0))
    reader.tensor(buf1, (1024, 1024), is_leaf=True)  # arg1_1
    buf2 = reader.storage(None, 8388608, device=device(type='cuda', index=0))
    reader.tensor(buf2, (1024, 2048), is_leaf=True)  # arg2_1
    buf3 = reader.storage(None, 8192, device=device(type='cuda', index=0))
    reader.tensor(buf3, (2048,), is_leaf=True)  # arg3_1
    buf4 = reader.storage(None, 8388608, device=device(type='cuda', index=0))
    reader.tensor(buf4, (2048, 1024), is_leaf=True)  # arg4_1
    buf5 = reader.storage(None, 4096, device=device(type='cuda', index=0))
    reader.tensor(buf5, (1024,), is_leaf=True)  # arg5_1
load_args._version = 0
mod = Repro()
if __name__ == '__main__':
    from torch._dynamo.repro.after_aot import run_repro
    with torch.no_grad():
        run_repro(mod, load_args, accuracy=False, command='run', save_dir=None, tracing_mode='real', check_str=None)
        # To run it separately, do 
        # mod, args = run_repro(mod, load_args, accuracy=False, command='get_args', save_dir=None, tracing_mode='real', check_str=None)
        # mod(*args)