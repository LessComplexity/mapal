; mapal-backend-llvm device module
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@mapal_smem = external addrspace(3) global [0 x i8], align 16
declare i32 @llvm.nvvm.read.ptx.sreg.tid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
declare void @llvm.nvvm.barrier0()
declare void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.8(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.commit.group()
declare void @llvm.nvvm.cp.async.wait.group(i32 immarg)
declare float @llvm.fma.f32(float, float, float)
declare double @llvm.fma.f64(double, double, double)

define ptx_kernel void @mapal_tile_259382a2b468f871(ptr addrspace(1) noalias readonly align 16 %a, ptr addrspace(1) noalias readonly align 16 %b, ptr addrspace(1) noalias align 16 %o) "nvvm.maxntid"="128" {
entry:
  %v1 = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = zext i32 %v1 to i64
  %v3 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v4 = zext i32 %v3 to i64
  %v5 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v6 = zext i32 %v5 to i64
  %v7 = udiv i64 %v2, 8
  %v8 = urem i64 %v2, 8
  %v9 = mul i64 %v6, 128
  %v10 = mul i64 %v4, 64
  %v11 = alloca [64 x float], align 16
  %v12 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 0
  store float 0x0000000000000000, ptr %v12, align 4
  %v13 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 1
  store float 0x0000000000000000, ptr %v13, align 4
  %v14 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 2
  store float 0x0000000000000000, ptr %v14, align 4
  %v15 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 3
  store float 0x0000000000000000, ptr %v15, align 4
  %v16 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 4
  store float 0x0000000000000000, ptr %v16, align 4
  %v17 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 5
  store float 0x0000000000000000, ptr %v17, align 4
  %v18 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 6
  store float 0x0000000000000000, ptr %v18, align 4
  %v19 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 7
  store float 0x0000000000000000, ptr %v19, align 4
  %v20 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 8
  store float 0x0000000000000000, ptr %v20, align 4
  %v21 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 9
  store float 0x0000000000000000, ptr %v21, align 4
  %v22 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 10
  store float 0x0000000000000000, ptr %v22, align 4
  %v23 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 11
  store float 0x0000000000000000, ptr %v23, align 4
  %v24 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 12
  store float 0x0000000000000000, ptr %v24, align 4
  %v25 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 13
  store float 0x0000000000000000, ptr %v25, align 4
  %v26 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 14
  store float 0x0000000000000000, ptr %v26, align 4
  %v27 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 15
  store float 0x0000000000000000, ptr %v27, align 4
  %v28 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 16
  store float 0x0000000000000000, ptr %v28, align 4
  %v29 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 17
  store float 0x0000000000000000, ptr %v29, align 4
  %v30 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 18
  store float 0x0000000000000000, ptr %v30, align 4
  %v31 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 19
  store float 0x0000000000000000, ptr %v31, align 4
  %v32 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 20
  store float 0x0000000000000000, ptr %v32, align 4
  %v33 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 21
  store float 0x0000000000000000, ptr %v33, align 4
  %v34 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 22
  store float 0x0000000000000000, ptr %v34, align 4
  %v35 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 23
  store float 0x0000000000000000, ptr %v35, align 4
  %v36 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 24
  store float 0x0000000000000000, ptr %v36, align 4
  %v37 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 25
  store float 0x0000000000000000, ptr %v37, align 4
  %v38 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 26
  store float 0x0000000000000000, ptr %v38, align 4
  %v39 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 27
  store float 0x0000000000000000, ptr %v39, align 4
  %v40 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 28
  store float 0x0000000000000000, ptr %v40, align 4
  %v41 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 29
  store float 0x0000000000000000, ptr %v41, align 4
  %v42 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 30
  store float 0x0000000000000000, ptr %v42, align 4
  %v43 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 31
  store float 0x0000000000000000, ptr %v43, align 4
  %v44 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 32
  store float 0x0000000000000000, ptr %v44, align 4
  %v45 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 33
  store float 0x0000000000000000, ptr %v45, align 4
  %v46 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 34
  store float 0x0000000000000000, ptr %v46, align 4
  %v47 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 35
  store float 0x0000000000000000, ptr %v47, align 4
  %v48 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 36
  store float 0x0000000000000000, ptr %v48, align 4
  %v49 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 37
  store float 0x0000000000000000, ptr %v49, align 4
  %v50 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 38
  store float 0x0000000000000000, ptr %v50, align 4
  %v51 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 39
  store float 0x0000000000000000, ptr %v51, align 4
  %v52 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 40
  store float 0x0000000000000000, ptr %v52, align 4
  %v53 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 41
  store float 0x0000000000000000, ptr %v53, align 4
  %v54 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 42
  store float 0x0000000000000000, ptr %v54, align 4
  %v55 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 43
  store float 0x0000000000000000, ptr %v55, align 4
  %v56 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 44
  store float 0x0000000000000000, ptr %v56, align 4
  %v57 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 45
  store float 0x0000000000000000, ptr %v57, align 4
  %v58 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 46
  store float 0x0000000000000000, ptr %v58, align 4
  %v59 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 47
  store float 0x0000000000000000, ptr %v59, align 4
  %v60 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 48
  store float 0x0000000000000000, ptr %v60, align 4
  %v61 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 49
  store float 0x0000000000000000, ptr %v61, align 4
  %v62 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 50
  store float 0x0000000000000000, ptr %v62, align 4
  %v63 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 51
  store float 0x0000000000000000, ptr %v63, align 4
  %v64 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 52
  store float 0x0000000000000000, ptr %v64, align 4
  %v65 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 53
  store float 0x0000000000000000, ptr %v65, align 4
  %v66 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 54
  store float 0x0000000000000000, ptr %v66, align 4
  %v67 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 55
  store float 0x0000000000000000, ptr %v67, align 4
  %v68 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 56
  store float 0x0000000000000000, ptr %v68, align 4
  %v69 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 57
  store float 0x0000000000000000, ptr %v69, align 4
  %v70 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 58
  store float 0x0000000000000000, ptr %v70, align 4
  %v71 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 59
  store float 0x0000000000000000, ptr %v71, align 4
  %v72 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 60
  store float 0x0000000000000000, ptr %v72, align 4
  %v73 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 61
  store float 0x0000000000000000, ptr %v73, align 4
  %v74 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 62
  store float 0x0000000000000000, ptr %v74, align 4
  %v75 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 63
  store float 0x0000000000000000, ptr %v75, align 4
  %v76 = add i64 %v2, 0
  %v77 = udiv i64 %v76, 2
  %v78 = urem i64 %v76, 2
  %v79 = mul i64 %v78, 4
  %v80 = add i64 %v9, %v77
  %v81 = mul i64 %v80, 1024
  %v82 = mul i64 %v79, 1
  %v83 = add i64 %v81, %v82
  %v84 = add i64 %v83, 0
  %v85 = mul i64 %v79, 132
  %v86 = add i64 %v85, %v77
  %v87 = add i64 %v2, 128
  %v88 = udiv i64 %v87, 2
  %v89 = urem i64 %v87, 2
  %v90 = mul i64 %v89, 4
  %v91 = add i64 %v9, %v88
  %v92 = mul i64 %v91, 1024
  %v93 = mul i64 %v90, 1
  %v94 = add i64 %v92, %v93
  %v95 = add i64 %v94, 0
  %v96 = mul i64 %v90, 132
  %v97 = add i64 %v96, %v88
  %v98 = add i64 %v2, 0
  %v99 = udiv i64 %v98, 16
  %v100 = urem i64 %v98, 16
  %v101 = mul i64 %v100, 4
  %v102 = mul i64 %v99, 1024
  %v103 = add i64 %v10, %v101
  %v104 = mul i64 %v103, 1
  %v105 = add i64 %v102, %v104
  %v106 = add i64 %v105, 0
  %v107 = mul i64 %v99, 64
  %v108 = add i64 %v107, %v101
  %v109 = add i64 %v108, 1056
  %v110 = mul i64 %v7, 8
  %v111 = mul i64 %v8, 8
  %v112 = mul i64 0, 1
  %v113 = mul i64 0, 1024
  %v114 = add i64 %v84, %v112
  %v115 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v114
  %v116 = load <4 x float>, ptr addrspace(1) %v115, align 16
  %v117 = add i64 %v95, %v112
  %v118 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v117
  %v119 = load <4 x float>, ptr addrspace(1) %v118, align 16
  %v120 = add i64 %v106, %v113
  %v121 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v120
  %v122 = load <4 x float>, ptr addrspace(1) %v121, align 16
  br label %kt
kt:
  %v123 = phi i64 [0, %entry], [%v124, %ktl]
  %v125 = phi <4 x float> [%v116, %entry], [%v160, %ktl]
  %v126 = phi <4 x float> [%v119, %entry], [%v163, %ktl]
  %v127 = phi <4 x float> [%v122, %entry], [%v166, %ktl]
  %v128 = extractelement <4 x float> %v125, i64 0
  %v129 = add i64 %v86, 0
  %v130 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v129
  store float %v128, ptr addrspace(3) %v130, align 4
  %v131 = extractelement <4 x float> %v125, i64 1
  %v132 = add i64 %v86, 132
  %v133 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v132
  store float %v131, ptr addrspace(3) %v133, align 4
  %v134 = extractelement <4 x float> %v125, i64 2
  %v135 = add i64 %v86, 264
  %v136 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v135
  store float %v134, ptr addrspace(3) %v136, align 4
  %v137 = extractelement <4 x float> %v125, i64 3
  %v138 = add i64 %v86, 396
  %v139 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v138
  store float %v137, ptr addrspace(3) %v139, align 4
  %v140 = extractelement <4 x float> %v126, i64 0
  %v141 = add i64 %v97, 0
  %v142 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v141
  store float %v140, ptr addrspace(3) %v142, align 4
  %v143 = extractelement <4 x float> %v126, i64 1
  %v144 = add i64 %v97, 132
  %v145 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v144
  store float %v143, ptr addrspace(3) %v145, align 4
  %v146 = extractelement <4 x float> %v126, i64 2
  %v147 = add i64 %v97, 264
  %v148 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v147
  store float %v146, ptr addrspace(3) %v148, align 4
  %v149 = extractelement <4 x float> %v126, i64 3
  %v150 = add i64 %v97, 396
  %v151 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v150
  store float %v149, ptr addrspace(3) %v151, align 4
  %v152 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v109
  store <4 x float> %v127, ptr addrspace(3) %v152, align 16
  call void @llvm.nvvm.barrier0()
  %v153 = add i64 %v123, 8
  %v154 = icmp ult i64 %v153, 1024
  %v155 = select i1 %v154, i64 %v153, i64 %v123
  %v156 = mul i64 %v155, 1
  %v157 = mul i64 %v155, 1024
  %v158 = add i64 %v84, %v156
  %v159 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v158
  %v160 = load <4 x float>, ptr addrspace(1) %v159, align 16
  %v161 = add i64 %v95, %v156
  %v162 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v161
  %v163 = load <4 x float>, ptr addrspace(1) %v162, align 16
  %v164 = add i64 %v106, %v157
  %v165 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v164
  %v166 = load <4 x float>, ptr addrspace(1) %v165, align 16
  br label %kk
kk:
  %v167 = phi i64 [0, %kt], [%v168, %kk]
  %v169 = mul i64 %v167, 132
  %v170 = add i64 %v169, %v110
  %v171 = add i64 %v170, 0
  %v172 = add i64 %v171, 0
  %v173 = add i64 %v172, 0
  %v174 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v173
  %v175 = load <4 x float>, ptr addrspace(3) %v174, align 16
  %v176 = extractelement <4 x float> %v175, i64 0
  %v177 = extractelement <4 x float> %v175, i64 1
  %v178 = extractelement <4 x float> %v175, i64 2
  %v179 = extractelement <4 x float> %v175, i64 3
  %v180 = add i64 %v172, 4
  %v181 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v180
  %v182 = load <4 x float>, ptr addrspace(3) %v181, align 16
  %v183 = extractelement <4 x float> %v182, i64 0
  %v184 = extractelement <4 x float> %v182, i64 1
  %v185 = extractelement <4 x float> %v182, i64 2
  %v186 = extractelement <4 x float> %v182, i64 3
  %v187 = mul i64 %v167, 64
  %v188 = add i64 %v187, %v111
  %v189 = add i64 %v188, 1056
  %v190 = add i64 %v189, 0
  %v191 = add i64 %v190, 0
  %v192 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v191
  %v193 = load <4 x float>, ptr addrspace(3) %v192, align 16
  %v194 = extractelement <4 x float> %v193, i64 0
  %v195 = extractelement <4 x float> %v193, i64 1
  %v196 = extractelement <4 x float> %v193, i64 2
  %v197 = extractelement <4 x float> %v193, i64 3
  %v198 = add i64 %v190, 4
  %v199 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v198
  %v200 = load <4 x float>, ptr addrspace(3) %v199, align 16
  %v201 = extractelement <4 x float> %v200, i64 0
  %v202 = extractelement <4 x float> %v200, i64 1
  %v203 = extractelement <4 x float> %v200, i64 2
  %v204 = extractelement <4 x float> %v200, i64 3
  %v205 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 0
  %v206 = load float, ptr %v205, align 4
  %v207 = call float @llvm.fma.f32(float %v176, float %v194, float %v206)
  store float %v207, ptr %v205, align 4
  %v208 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 1
  %v209 = load float, ptr %v208, align 4
  %v210 = call float @llvm.fma.f32(float %v176, float %v195, float %v209)
  store float %v210, ptr %v208, align 4
  %v211 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 2
  %v212 = load float, ptr %v211, align 4
  %v213 = call float @llvm.fma.f32(float %v176, float %v196, float %v212)
  store float %v213, ptr %v211, align 4
  %v214 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 3
  %v215 = load float, ptr %v214, align 4
  %v216 = call float @llvm.fma.f32(float %v176, float %v197, float %v215)
  store float %v216, ptr %v214, align 4
  %v217 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 4
  %v218 = load float, ptr %v217, align 4
  %v219 = call float @llvm.fma.f32(float %v176, float %v201, float %v218)
  store float %v219, ptr %v217, align 4
  %v220 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 5
  %v221 = load float, ptr %v220, align 4
  %v222 = call float @llvm.fma.f32(float %v176, float %v202, float %v221)
  store float %v222, ptr %v220, align 4
  %v223 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 6
  %v224 = load float, ptr %v223, align 4
  %v225 = call float @llvm.fma.f32(float %v176, float %v203, float %v224)
  store float %v225, ptr %v223, align 4
  %v226 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 7
  %v227 = load float, ptr %v226, align 4
  %v228 = call float @llvm.fma.f32(float %v176, float %v204, float %v227)
  store float %v228, ptr %v226, align 4
  %v229 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 8
  %v230 = load float, ptr %v229, align 4
  %v231 = call float @llvm.fma.f32(float %v177, float %v194, float %v230)
  store float %v231, ptr %v229, align 4
  %v232 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 9
  %v233 = load float, ptr %v232, align 4
  %v234 = call float @llvm.fma.f32(float %v177, float %v195, float %v233)
  store float %v234, ptr %v232, align 4
  %v235 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 10
  %v236 = load float, ptr %v235, align 4
  %v237 = call float @llvm.fma.f32(float %v177, float %v196, float %v236)
  store float %v237, ptr %v235, align 4
  %v238 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 11
  %v239 = load float, ptr %v238, align 4
  %v240 = call float @llvm.fma.f32(float %v177, float %v197, float %v239)
  store float %v240, ptr %v238, align 4
  %v241 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 12
  %v242 = load float, ptr %v241, align 4
  %v243 = call float @llvm.fma.f32(float %v177, float %v201, float %v242)
  store float %v243, ptr %v241, align 4
  %v244 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 13
  %v245 = load float, ptr %v244, align 4
  %v246 = call float @llvm.fma.f32(float %v177, float %v202, float %v245)
  store float %v246, ptr %v244, align 4
  %v247 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 14
  %v248 = load float, ptr %v247, align 4
  %v249 = call float @llvm.fma.f32(float %v177, float %v203, float %v248)
  store float %v249, ptr %v247, align 4
  %v250 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 15
  %v251 = load float, ptr %v250, align 4
  %v252 = call float @llvm.fma.f32(float %v177, float %v204, float %v251)
  store float %v252, ptr %v250, align 4
  %v253 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 16
  %v254 = load float, ptr %v253, align 4
  %v255 = call float @llvm.fma.f32(float %v178, float %v194, float %v254)
  store float %v255, ptr %v253, align 4
  %v256 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 17
  %v257 = load float, ptr %v256, align 4
  %v258 = call float @llvm.fma.f32(float %v178, float %v195, float %v257)
  store float %v258, ptr %v256, align 4
  %v259 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 18
  %v260 = load float, ptr %v259, align 4
  %v261 = call float @llvm.fma.f32(float %v178, float %v196, float %v260)
  store float %v261, ptr %v259, align 4
  %v262 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 19
  %v263 = load float, ptr %v262, align 4
  %v264 = call float @llvm.fma.f32(float %v178, float %v197, float %v263)
  store float %v264, ptr %v262, align 4
  %v265 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 20
  %v266 = load float, ptr %v265, align 4
  %v267 = call float @llvm.fma.f32(float %v178, float %v201, float %v266)
  store float %v267, ptr %v265, align 4
  %v268 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 21
  %v269 = load float, ptr %v268, align 4
  %v270 = call float @llvm.fma.f32(float %v178, float %v202, float %v269)
  store float %v270, ptr %v268, align 4
  %v271 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 22
  %v272 = load float, ptr %v271, align 4
  %v273 = call float @llvm.fma.f32(float %v178, float %v203, float %v272)
  store float %v273, ptr %v271, align 4
  %v274 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 23
  %v275 = load float, ptr %v274, align 4
  %v276 = call float @llvm.fma.f32(float %v178, float %v204, float %v275)
  store float %v276, ptr %v274, align 4
  %v277 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 24
  %v278 = load float, ptr %v277, align 4
  %v279 = call float @llvm.fma.f32(float %v179, float %v194, float %v278)
  store float %v279, ptr %v277, align 4
  %v280 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 25
  %v281 = load float, ptr %v280, align 4
  %v282 = call float @llvm.fma.f32(float %v179, float %v195, float %v281)
  store float %v282, ptr %v280, align 4
  %v283 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 26
  %v284 = load float, ptr %v283, align 4
  %v285 = call float @llvm.fma.f32(float %v179, float %v196, float %v284)
  store float %v285, ptr %v283, align 4
  %v286 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 27
  %v287 = load float, ptr %v286, align 4
  %v288 = call float @llvm.fma.f32(float %v179, float %v197, float %v287)
  store float %v288, ptr %v286, align 4
  %v289 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 28
  %v290 = load float, ptr %v289, align 4
  %v291 = call float @llvm.fma.f32(float %v179, float %v201, float %v290)
  store float %v291, ptr %v289, align 4
  %v292 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 29
  %v293 = load float, ptr %v292, align 4
  %v294 = call float @llvm.fma.f32(float %v179, float %v202, float %v293)
  store float %v294, ptr %v292, align 4
  %v295 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 30
  %v296 = load float, ptr %v295, align 4
  %v297 = call float @llvm.fma.f32(float %v179, float %v203, float %v296)
  store float %v297, ptr %v295, align 4
  %v298 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 31
  %v299 = load float, ptr %v298, align 4
  %v300 = call float @llvm.fma.f32(float %v179, float %v204, float %v299)
  store float %v300, ptr %v298, align 4
  %v301 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 32
  %v302 = load float, ptr %v301, align 4
  %v303 = call float @llvm.fma.f32(float %v183, float %v194, float %v302)
  store float %v303, ptr %v301, align 4
  %v304 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 33
  %v305 = load float, ptr %v304, align 4
  %v306 = call float @llvm.fma.f32(float %v183, float %v195, float %v305)
  store float %v306, ptr %v304, align 4
  %v307 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 34
  %v308 = load float, ptr %v307, align 4
  %v309 = call float @llvm.fma.f32(float %v183, float %v196, float %v308)
  store float %v309, ptr %v307, align 4
  %v310 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 35
  %v311 = load float, ptr %v310, align 4
  %v312 = call float @llvm.fma.f32(float %v183, float %v197, float %v311)
  store float %v312, ptr %v310, align 4
  %v313 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 36
  %v314 = load float, ptr %v313, align 4
  %v315 = call float @llvm.fma.f32(float %v183, float %v201, float %v314)
  store float %v315, ptr %v313, align 4
  %v316 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 37
  %v317 = load float, ptr %v316, align 4
  %v318 = call float @llvm.fma.f32(float %v183, float %v202, float %v317)
  store float %v318, ptr %v316, align 4
  %v319 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 38
  %v320 = load float, ptr %v319, align 4
  %v321 = call float @llvm.fma.f32(float %v183, float %v203, float %v320)
  store float %v321, ptr %v319, align 4
  %v322 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 39
  %v323 = load float, ptr %v322, align 4
  %v324 = call float @llvm.fma.f32(float %v183, float %v204, float %v323)
  store float %v324, ptr %v322, align 4
  %v325 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 40
  %v326 = load float, ptr %v325, align 4
  %v327 = call float @llvm.fma.f32(float %v184, float %v194, float %v326)
  store float %v327, ptr %v325, align 4
  %v328 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 41
  %v329 = load float, ptr %v328, align 4
  %v330 = call float @llvm.fma.f32(float %v184, float %v195, float %v329)
  store float %v330, ptr %v328, align 4
  %v331 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 42
  %v332 = load float, ptr %v331, align 4
  %v333 = call float @llvm.fma.f32(float %v184, float %v196, float %v332)
  store float %v333, ptr %v331, align 4
  %v334 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 43
  %v335 = load float, ptr %v334, align 4
  %v336 = call float @llvm.fma.f32(float %v184, float %v197, float %v335)
  store float %v336, ptr %v334, align 4
  %v337 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 44
  %v338 = load float, ptr %v337, align 4
  %v339 = call float @llvm.fma.f32(float %v184, float %v201, float %v338)
  store float %v339, ptr %v337, align 4
  %v340 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 45
  %v341 = load float, ptr %v340, align 4
  %v342 = call float @llvm.fma.f32(float %v184, float %v202, float %v341)
  store float %v342, ptr %v340, align 4
  %v343 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 46
  %v344 = load float, ptr %v343, align 4
  %v345 = call float @llvm.fma.f32(float %v184, float %v203, float %v344)
  store float %v345, ptr %v343, align 4
  %v346 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 47
  %v347 = load float, ptr %v346, align 4
  %v348 = call float @llvm.fma.f32(float %v184, float %v204, float %v347)
  store float %v348, ptr %v346, align 4
  %v349 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 48
  %v350 = load float, ptr %v349, align 4
  %v351 = call float @llvm.fma.f32(float %v185, float %v194, float %v350)
  store float %v351, ptr %v349, align 4
  %v352 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 49
  %v353 = load float, ptr %v352, align 4
  %v354 = call float @llvm.fma.f32(float %v185, float %v195, float %v353)
  store float %v354, ptr %v352, align 4
  %v355 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 50
  %v356 = load float, ptr %v355, align 4
  %v357 = call float @llvm.fma.f32(float %v185, float %v196, float %v356)
  store float %v357, ptr %v355, align 4
  %v358 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 51
  %v359 = load float, ptr %v358, align 4
  %v360 = call float @llvm.fma.f32(float %v185, float %v197, float %v359)
  store float %v360, ptr %v358, align 4
  %v361 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 52
  %v362 = load float, ptr %v361, align 4
  %v363 = call float @llvm.fma.f32(float %v185, float %v201, float %v362)
  store float %v363, ptr %v361, align 4
  %v364 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 53
  %v365 = load float, ptr %v364, align 4
  %v366 = call float @llvm.fma.f32(float %v185, float %v202, float %v365)
  store float %v366, ptr %v364, align 4
  %v367 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 54
  %v368 = load float, ptr %v367, align 4
  %v369 = call float @llvm.fma.f32(float %v185, float %v203, float %v368)
  store float %v369, ptr %v367, align 4
  %v370 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 55
  %v371 = load float, ptr %v370, align 4
  %v372 = call float @llvm.fma.f32(float %v185, float %v204, float %v371)
  store float %v372, ptr %v370, align 4
  %v373 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 56
  %v374 = load float, ptr %v373, align 4
  %v375 = call float @llvm.fma.f32(float %v186, float %v194, float %v374)
  store float %v375, ptr %v373, align 4
  %v376 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 57
  %v377 = load float, ptr %v376, align 4
  %v378 = call float @llvm.fma.f32(float %v186, float %v195, float %v377)
  store float %v378, ptr %v376, align 4
  %v379 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 58
  %v380 = load float, ptr %v379, align 4
  %v381 = call float @llvm.fma.f32(float %v186, float %v196, float %v380)
  store float %v381, ptr %v379, align 4
  %v382 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 59
  %v383 = load float, ptr %v382, align 4
  %v384 = call float @llvm.fma.f32(float %v186, float %v197, float %v383)
  store float %v384, ptr %v382, align 4
  %v385 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 60
  %v386 = load float, ptr %v385, align 4
  %v387 = call float @llvm.fma.f32(float %v186, float %v201, float %v386)
  store float %v387, ptr %v385, align 4
  %v388 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 61
  %v389 = load float, ptr %v388, align 4
  %v390 = call float @llvm.fma.f32(float %v186, float %v202, float %v389)
  store float %v390, ptr %v388, align 4
  %v391 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 62
  %v392 = load float, ptr %v391, align 4
  %v393 = call float @llvm.fma.f32(float %v186, float %v203, float %v392)
  store float %v393, ptr %v391, align 4
  %v394 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 63
  %v395 = load float, ptr %v394, align 4
  %v396 = call float @llvm.fma.f32(float %v186, float %v204, float %v395)
  store float %v396, ptr %v394, align 4
  %v168 = add i64 %v167, 1
  %v397 = icmp eq i64 %v168, 8
  br i1 %v397, label %ktl, label %kk, !llvm.loop !0
ktl:
  call void @llvm.nvvm.barrier0()
  %v124 = add i64 %v123, 8
  %v398 = icmp eq i64 %v124, 1024
  br i1 %v398, label %done, label %kt
done:
  %v399 = add i64 %v9, %v110
  %v400 = add i64 %v399, 0
  %v401 = mul i64 %v400, 1024
  %v402 = add i64 %v401, %v10
  %v403 = add i64 %v402, %v111
  %v404 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 0
  %v405 = load float, ptr %v404, align 4
  %v406 = insertelement <4 x float> poison, float %v405, i64 0
  %v407 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 1
  %v408 = load float, ptr %v407, align 4
  %v409 = insertelement <4 x float> %v406, float %v408, i64 1
  %v410 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 2
  %v411 = load float, ptr %v410, align 4
  %v412 = insertelement <4 x float> %v409, float %v411, i64 2
  %v413 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 3
  %v414 = load float, ptr %v413, align 4
  %v415 = insertelement <4 x float> %v412, float %v414, i64 3
  %v416 = add i64 %v403, 0
  %v417 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v416
  store <4 x float> %v415, ptr addrspace(1) %v417, align 16
  %v418 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 4
  %v419 = load float, ptr %v418, align 4
  %v420 = insertelement <4 x float> poison, float %v419, i64 0
  %v421 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 5
  %v422 = load float, ptr %v421, align 4
  %v423 = insertelement <4 x float> %v420, float %v422, i64 1
  %v424 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 6
  %v425 = load float, ptr %v424, align 4
  %v426 = insertelement <4 x float> %v423, float %v425, i64 2
  %v427 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 7
  %v428 = load float, ptr %v427, align 4
  %v429 = insertelement <4 x float> %v426, float %v428, i64 3
  %v430 = add i64 %v403, 4
  %v431 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v430
  store <4 x float> %v429, ptr addrspace(1) %v431, align 16
  %v432 = add i64 %v9, %v110
  %v433 = add i64 %v432, 1
  %v434 = mul i64 %v433, 1024
  %v435 = add i64 %v434, %v10
  %v436 = add i64 %v435, %v111
  %v437 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 8
  %v438 = load float, ptr %v437, align 4
  %v439 = insertelement <4 x float> poison, float %v438, i64 0
  %v440 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 9
  %v441 = load float, ptr %v440, align 4
  %v442 = insertelement <4 x float> %v439, float %v441, i64 1
  %v443 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 10
  %v444 = load float, ptr %v443, align 4
  %v445 = insertelement <4 x float> %v442, float %v444, i64 2
  %v446 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 11
  %v447 = load float, ptr %v446, align 4
  %v448 = insertelement <4 x float> %v445, float %v447, i64 3
  %v449 = add i64 %v436, 0
  %v450 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v449
  store <4 x float> %v448, ptr addrspace(1) %v450, align 16
  %v451 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 12
  %v452 = load float, ptr %v451, align 4
  %v453 = insertelement <4 x float> poison, float %v452, i64 0
  %v454 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 13
  %v455 = load float, ptr %v454, align 4
  %v456 = insertelement <4 x float> %v453, float %v455, i64 1
  %v457 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 14
  %v458 = load float, ptr %v457, align 4
  %v459 = insertelement <4 x float> %v456, float %v458, i64 2
  %v460 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 15
  %v461 = load float, ptr %v460, align 4
  %v462 = insertelement <4 x float> %v459, float %v461, i64 3
  %v463 = add i64 %v436, 4
  %v464 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v463
  store <4 x float> %v462, ptr addrspace(1) %v464, align 16
  %v465 = add i64 %v9, %v110
  %v466 = add i64 %v465, 2
  %v467 = mul i64 %v466, 1024
  %v468 = add i64 %v467, %v10
  %v469 = add i64 %v468, %v111
  %v470 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 16
  %v471 = load float, ptr %v470, align 4
  %v472 = insertelement <4 x float> poison, float %v471, i64 0
  %v473 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 17
  %v474 = load float, ptr %v473, align 4
  %v475 = insertelement <4 x float> %v472, float %v474, i64 1
  %v476 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 18
  %v477 = load float, ptr %v476, align 4
  %v478 = insertelement <4 x float> %v475, float %v477, i64 2
  %v479 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 19
  %v480 = load float, ptr %v479, align 4
  %v481 = insertelement <4 x float> %v478, float %v480, i64 3
  %v482 = add i64 %v469, 0
  %v483 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v482
  store <4 x float> %v481, ptr addrspace(1) %v483, align 16
  %v484 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 20
  %v485 = load float, ptr %v484, align 4
  %v486 = insertelement <4 x float> poison, float %v485, i64 0
  %v487 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 21
  %v488 = load float, ptr %v487, align 4
  %v489 = insertelement <4 x float> %v486, float %v488, i64 1
  %v490 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 22
  %v491 = load float, ptr %v490, align 4
  %v492 = insertelement <4 x float> %v489, float %v491, i64 2
  %v493 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 23
  %v494 = load float, ptr %v493, align 4
  %v495 = insertelement <4 x float> %v492, float %v494, i64 3
  %v496 = add i64 %v469, 4
  %v497 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v496
  store <4 x float> %v495, ptr addrspace(1) %v497, align 16
  %v498 = add i64 %v9, %v110
  %v499 = add i64 %v498, 3
  %v500 = mul i64 %v499, 1024
  %v501 = add i64 %v500, %v10
  %v502 = add i64 %v501, %v111
  %v503 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 24
  %v504 = load float, ptr %v503, align 4
  %v505 = insertelement <4 x float> poison, float %v504, i64 0
  %v506 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 25
  %v507 = load float, ptr %v506, align 4
  %v508 = insertelement <4 x float> %v505, float %v507, i64 1
  %v509 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 26
  %v510 = load float, ptr %v509, align 4
  %v511 = insertelement <4 x float> %v508, float %v510, i64 2
  %v512 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 27
  %v513 = load float, ptr %v512, align 4
  %v514 = insertelement <4 x float> %v511, float %v513, i64 3
  %v515 = add i64 %v502, 0
  %v516 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v515
  store <4 x float> %v514, ptr addrspace(1) %v516, align 16
  %v517 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 28
  %v518 = load float, ptr %v517, align 4
  %v519 = insertelement <4 x float> poison, float %v518, i64 0
  %v520 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 29
  %v521 = load float, ptr %v520, align 4
  %v522 = insertelement <4 x float> %v519, float %v521, i64 1
  %v523 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 30
  %v524 = load float, ptr %v523, align 4
  %v525 = insertelement <4 x float> %v522, float %v524, i64 2
  %v526 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 31
  %v527 = load float, ptr %v526, align 4
  %v528 = insertelement <4 x float> %v525, float %v527, i64 3
  %v529 = add i64 %v502, 4
  %v530 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v529
  store <4 x float> %v528, ptr addrspace(1) %v530, align 16
  %v531 = add i64 %v9, %v110
  %v532 = add i64 %v531, 4
  %v533 = mul i64 %v532, 1024
  %v534 = add i64 %v533, %v10
  %v535 = add i64 %v534, %v111
  %v536 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 32
  %v537 = load float, ptr %v536, align 4
  %v538 = insertelement <4 x float> poison, float %v537, i64 0
  %v539 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 33
  %v540 = load float, ptr %v539, align 4
  %v541 = insertelement <4 x float> %v538, float %v540, i64 1
  %v542 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 34
  %v543 = load float, ptr %v542, align 4
  %v544 = insertelement <4 x float> %v541, float %v543, i64 2
  %v545 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 35
  %v546 = load float, ptr %v545, align 4
  %v547 = insertelement <4 x float> %v544, float %v546, i64 3
  %v548 = add i64 %v535, 0
  %v549 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v548
  store <4 x float> %v547, ptr addrspace(1) %v549, align 16
  %v550 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 36
  %v551 = load float, ptr %v550, align 4
  %v552 = insertelement <4 x float> poison, float %v551, i64 0
  %v553 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 37
  %v554 = load float, ptr %v553, align 4
  %v555 = insertelement <4 x float> %v552, float %v554, i64 1
  %v556 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 38
  %v557 = load float, ptr %v556, align 4
  %v558 = insertelement <4 x float> %v555, float %v557, i64 2
  %v559 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 39
  %v560 = load float, ptr %v559, align 4
  %v561 = insertelement <4 x float> %v558, float %v560, i64 3
  %v562 = add i64 %v535, 4
  %v563 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v562
  store <4 x float> %v561, ptr addrspace(1) %v563, align 16
  %v564 = add i64 %v9, %v110
  %v565 = add i64 %v564, 5
  %v566 = mul i64 %v565, 1024
  %v567 = add i64 %v566, %v10
  %v568 = add i64 %v567, %v111
  %v569 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 40
  %v570 = load float, ptr %v569, align 4
  %v571 = insertelement <4 x float> poison, float %v570, i64 0
  %v572 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 41
  %v573 = load float, ptr %v572, align 4
  %v574 = insertelement <4 x float> %v571, float %v573, i64 1
  %v575 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 42
  %v576 = load float, ptr %v575, align 4
  %v577 = insertelement <4 x float> %v574, float %v576, i64 2
  %v578 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 43
  %v579 = load float, ptr %v578, align 4
  %v580 = insertelement <4 x float> %v577, float %v579, i64 3
  %v581 = add i64 %v568, 0
  %v582 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v581
  store <4 x float> %v580, ptr addrspace(1) %v582, align 16
  %v583 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 44
  %v584 = load float, ptr %v583, align 4
  %v585 = insertelement <4 x float> poison, float %v584, i64 0
  %v586 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 45
  %v587 = load float, ptr %v586, align 4
  %v588 = insertelement <4 x float> %v585, float %v587, i64 1
  %v589 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 46
  %v590 = load float, ptr %v589, align 4
  %v591 = insertelement <4 x float> %v588, float %v590, i64 2
  %v592 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 47
  %v593 = load float, ptr %v592, align 4
  %v594 = insertelement <4 x float> %v591, float %v593, i64 3
  %v595 = add i64 %v568, 4
  %v596 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v595
  store <4 x float> %v594, ptr addrspace(1) %v596, align 16
  %v597 = add i64 %v9, %v110
  %v598 = add i64 %v597, 6
  %v599 = mul i64 %v598, 1024
  %v600 = add i64 %v599, %v10
  %v601 = add i64 %v600, %v111
  %v602 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 48
  %v603 = load float, ptr %v602, align 4
  %v604 = insertelement <4 x float> poison, float %v603, i64 0
  %v605 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 49
  %v606 = load float, ptr %v605, align 4
  %v607 = insertelement <4 x float> %v604, float %v606, i64 1
  %v608 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 50
  %v609 = load float, ptr %v608, align 4
  %v610 = insertelement <4 x float> %v607, float %v609, i64 2
  %v611 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 51
  %v612 = load float, ptr %v611, align 4
  %v613 = insertelement <4 x float> %v610, float %v612, i64 3
  %v614 = add i64 %v601, 0
  %v615 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v614
  store <4 x float> %v613, ptr addrspace(1) %v615, align 16
  %v616 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 52
  %v617 = load float, ptr %v616, align 4
  %v618 = insertelement <4 x float> poison, float %v617, i64 0
  %v619 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 53
  %v620 = load float, ptr %v619, align 4
  %v621 = insertelement <4 x float> %v618, float %v620, i64 1
  %v622 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 54
  %v623 = load float, ptr %v622, align 4
  %v624 = insertelement <4 x float> %v621, float %v623, i64 2
  %v625 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 55
  %v626 = load float, ptr %v625, align 4
  %v627 = insertelement <4 x float> %v624, float %v626, i64 3
  %v628 = add i64 %v601, 4
  %v629 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v628
  store <4 x float> %v627, ptr addrspace(1) %v629, align 16
  %v630 = add i64 %v9, %v110
  %v631 = add i64 %v630, 7
  %v632 = mul i64 %v631, 1024
  %v633 = add i64 %v632, %v10
  %v634 = add i64 %v633, %v111
  %v635 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 56
  %v636 = load float, ptr %v635, align 4
  %v637 = insertelement <4 x float> poison, float %v636, i64 0
  %v638 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 57
  %v639 = load float, ptr %v638, align 4
  %v640 = insertelement <4 x float> %v637, float %v639, i64 1
  %v641 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 58
  %v642 = load float, ptr %v641, align 4
  %v643 = insertelement <4 x float> %v640, float %v642, i64 2
  %v644 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 59
  %v645 = load float, ptr %v644, align 4
  %v646 = insertelement <4 x float> %v643, float %v645, i64 3
  %v647 = add i64 %v634, 0
  %v648 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v647
  store <4 x float> %v646, ptr addrspace(1) %v648, align 16
  %v649 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 60
  %v650 = load float, ptr %v649, align 4
  %v651 = insertelement <4 x float> poison, float %v650, i64 0
  %v652 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 61
  %v653 = load float, ptr %v652, align 4
  %v654 = insertelement <4 x float> %v651, float %v653, i64 1
  %v655 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 62
  %v656 = load float, ptr %v655, align 4
  %v657 = insertelement <4 x float> %v654, float %v656, i64 2
  %v658 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 63
  %v659 = load float, ptr %v658, align 4
  %v660 = insertelement <4 x float> %v657, float %v659, i64 3
  %v661 = add i64 %v634, 4
  %v662 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v661
  store <4 x float> %v660, ptr addrspace(1) %v662, align 16
  ret void
}

define internal float @fn1(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 7, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 13, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 101, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 50, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to float
  store float %t33, ptr %o1
  %t34 = load float, ptr %o1
  ret float %t34
}

define ptx_kernel void @mapal_gen_b0b006bfea5ed91e(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call float @fn1(i32 %x)
  %p = getelementptr inbounds float, ptr addrspace(1) %o, i64 %i
  store float %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

define internal float @fn2(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 7, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 57, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 101, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 50, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to float
  store float %t33, ptr %o1
  %t34 = load float, ptr %o1
  ret float %t34
}

define ptx_kernel void @mapal_gen_915bbd7a252e06e9(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call float @fn2(i32 %x)
  %p = getelementptr inbounds float, ptr addrspace(1) %o, i64 %i
  store float %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

!0 = distinct !{!0, !1}
!1 = !{!"llvm.loop.unroll.full"}
