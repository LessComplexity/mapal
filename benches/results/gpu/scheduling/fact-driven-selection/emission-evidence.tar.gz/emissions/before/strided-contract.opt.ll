; ModuleID = '/private/tmp/mapal-gpu-schedule-facts/emissions/before/strided-contract.device.ll'
source_filename = "/private/tmp/mapal-gpu-schedule-facts/emissions/before/strided-contract.device.ll"
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 2147483647) i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define ptx_kernel void @mapal_tile_d51aa3cbc2658d57(ptr addrspace(1) noalias readonly align 4 captures(none) %a, ptr addrspace(1) noalias readonly align 4 captures(none) %b, ptr addrspace(1) noalias writeonly align 4 captures(none) %o) local_unnamed_addr #1 {
entry:
  %v1 = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v3 = shl nuw nsw i32 %v2, 8
  %v4 = or disjoint i32 %v3, %v1
  %v5 = icmp eq i32 %v2, 0
  br i1 %v5, label %body, label %done

body:                                             ; preds = %entry
  %v13 = shl nuw nsw i32 %v1, 7
  br label %kloop

kloop:                                            ; preds = %kloop, %body
  %v16 = phi i32 [ 0, %body ], [ %v18.3, %kloop ]
  %v17 = phi float [ 2.000000e+00, %body ], [ %v29.3, %kloop ]
  %v21 = zext nneg i32 %v16 to i64
  %v22 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v21
  %v23 = load float, ptr addrspace(1) %v22, align 4
  %v25 = add nuw nsw i32 %v16, %v13
  %v26 = zext nneg i32 %v25 to i64
  %v27 = getelementptr inbounds nuw float, ptr addrspace(1) %b, i64 %v26
  %v28 = load float, ptr addrspace(1) %v27, align 4
  %v30 = fmul float %v23, %v28
  %v29 = fadd float %v17, %v30
  %v18 = or disjoint i32 %v16, 1
  %v21.1 = zext nneg i32 %v18 to i64
  %v22.1 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v21.1
  %v23.1 = load float, ptr addrspace(1) %v22.1, align 4
  %v25.1 = add nuw nsw i32 %v18, %v13
  %v26.1 = zext nneg i32 %v25.1 to i64
  %v27.1 = getelementptr inbounds nuw float, ptr addrspace(1) %b, i64 %v26.1
  %v28.1 = load float, ptr addrspace(1) %v27.1, align 4
  %v30.1 = fmul float %v23.1, %v28.1
  %v29.1 = fadd float %v29, %v30.1
  %v18.1 = or disjoint i32 %v16, 2
  %v21.2 = zext nneg i32 %v18.1 to i64
  %v22.2 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v21.2
  %v23.2 = load float, ptr addrspace(1) %v22.2, align 4
  %v25.2 = add nuw nsw i32 %v18.1, %v13
  %v26.2 = zext nneg i32 %v25.2 to i64
  %v27.2 = getelementptr inbounds nuw float, ptr addrspace(1) %b, i64 %v26.2
  %v28.2 = load float, ptr addrspace(1) %v27.2, align 4
  %v30.2 = fmul float %v23.2, %v28.2
  %v29.2 = fadd float %v29.1, %v30.2
  %v18.2 = or disjoint i32 %v16, 3
  %v21.3 = zext nneg i32 %v18.2 to i64
  %v22.3 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v21.3
  %v23.3 = load float, ptr addrspace(1) %v22.3, align 4
  %v25.3 = add nuw nsw i32 %v18.2, %v13
  %v26.3 = zext nneg i32 %v25.3 to i64
  %v27.3 = getelementptr inbounds nuw float, ptr addrspace(1) %b, i64 %v26.3
  %v28.3 = load float, ptr addrspace(1) %v27.3, align 4
  %v30.3 = fmul float %v23.3, %v28.3
  %v29.3 = fadd float %v29.2, %v30.3
  %v18.3 = add nuw nsw i32 %v16, 4
  %v31.3 = icmp eq i32 %v18.3, 128
  br i1 %v31.3, label %store, label %kloop

store:                                            ; preds = %kloop
  %v32 = zext nneg i32 %v4 to i64
  %v33 = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %v32
  store float %v29.3, ptr addrspace(1) %v33, align 4
  br label %done

done:                                             ; preds = %store, %entry
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_fe449f90d1eda582(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #2 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %p = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %i
  %x = trunc i64 %i to i32
  %t1.i = sitofp i32 %x to float
  store float %t1.i, ptr addrspace(1) %p, align 4
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_5cee44f9496d8476(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #2 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %p = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %i
  %x = trunc i64 %i to i32
  %t1.i = sitofp i32 %x to float
  store float %t1.i, ptr addrspace(1) %p, align 4
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

attributes #0 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nofree norecurse nosync nounwind memory(argmem: readwrite) "nvvm.maxntid"="256" }
attributes #2 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) "nvvm.maxntid"="256" }
