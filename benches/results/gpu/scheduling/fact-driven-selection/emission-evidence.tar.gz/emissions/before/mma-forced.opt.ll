; ModuleID = '/private/tmp/mapal-gpu-schedule-facts/emissions/before/mma-forced.device.ll'
source_filename = "/private/tmp/mapal-gpu-schedule-facts/emissions/before/mma-forced.device.ll"
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@mapal_smem = external addrspace(3) global [0 x i8], align 16

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 2147483647) i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #0

; Function Attrs: nocallback nounwind memory(argmem: readwrite)
declare void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) noalias writeonly, ptr addrspace(1) noalias readonly) #1

; Function Attrs: nounwind
declare void @llvm.nvvm.cp.async.commit.group() #2

; Function Attrs: nounwind
declare void @llvm.nvvm.cp.async.wait.group(i32 immarg) #2

; Function Attrs: nounwind
define ptx_kernel void @mapal_tile_d0cfb9881535775e(ptr addrspace(1) noalias readonly align 16 %a, ptr addrspace(1) noalias readonly align 16 %b, ptr addrspace(1) noalias writeonly align 16 captures(none) %o) local_unnamed_addr #3 {
entry:
  %v1 = tail call range(i32 0, 128) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = zext nneg i32 %v1 to i64
  %v3 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v4 = zext nneg i32 %v3 to i64
  %v5 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v10 = and i64 %v2, 32
  %v8 = lshr i64 %v2, 2
  %v1110 = and i64 %v8, 7
  %v12 = and i64 %v2, 3
  %0 = shl nuw nsw i32 %v5, 6
  %v13 = zext nneg i32 %0 to i64
  %v14 = shl nuw nsw i64 %v4, 6
  %v4911 = lshr i64 %v2, 3
  %v50 = shl nuw nsw i64 %v2, 2
  %v51 = and i64 %v50, 28
  %v52 = or disjoint i64 %v4911, %v13
  %v58 = or disjoint i64 %v2, 128
  %v5912 = lshr i64 %v58, 3
  %v62 = or disjoint i64 %v5912, %v13
  %v68 = or disjoint i64 %v2, 256
  %v6913 = lshr i64 %v68, 3
  %v72 = or disjoint i64 %v6913, %v13
  %v78 = or disjoint i64 %v2, 384
  %v7914 = lshr i64 %v78, 3
  %v82 = or disjoint i64 %v7914, %v13
  %v8915 = lshr i64 %v2, 4
  %v91 = and i64 %v50, 60
  %v93 = or disjoint i64 %v91, %v14
  %v10016 = lshr i64 %v58, 4
  %v11117 = lshr i64 %v68, 4
  %v12218 = lshr i64 %v78, 4
  %.idx = shl nuw nsw i64 %v52, 12
  %1 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx
  %v137 = getelementptr inbounds nuw float, ptr addrspace(1) %1, i64 %v51
  %.idx21 = mul nuw nsw i64 %v4911, 144
  %2 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx21
  %v139 = getelementptr inbounds nuw float, ptr addrspace(3) %2, i64 %v51
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v139, ptr addrspace(1) %v137)
  %.idx22 = shl nuw nsw i64 %v62, 12
  %3 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx22
  %v141 = getelementptr inbounds nuw float, ptr addrspace(1) %3, i64 %v51
  %.idx23 = mul nuw nsw i64 %v5912, 144
  %4 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx23
  %v143 = getelementptr inbounds nuw float, ptr addrspace(3) %4, i64 %v51
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v143, ptr addrspace(1) %v141)
  %.idx24 = shl nuw nsw i64 %v72, 12
  %5 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx24
  %v145 = getelementptr inbounds nuw float, ptr addrspace(1) %5, i64 %v51
  %.idx25 = mul nuw nsw i64 %v6913, 144
  %6 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx25
  %v147 = getelementptr inbounds nuw float, ptr addrspace(3) %6, i64 %v51
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v147, ptr addrspace(1) %v145)
  %.idx26 = shl nuw nsw i64 %v82, 12
  %7 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx26
  %v149 = getelementptr inbounds nuw float, ptr addrspace(1) %7, i64 %v51
  %.idx27 = mul nuw nsw i64 %v7914, 144
  %8 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx27
  %v151 = getelementptr inbounds nuw float, ptr addrspace(3) %8, i64 %v51
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v151, ptr addrspace(1) %v149)
  %.idx28 = shl nuw nsw i64 %v8915, 12
  %9 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx28
  %v153 = getelementptr inbounds nuw float, ptr addrspace(1) %9, i64 %v93
  %.idx29 = mul nuw nsw i64 %v8915, 288
  %10 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx29
  %11 = getelementptr inbounds nuw float, ptr addrspace(3) %10, i64 %v91
  %v155 = getelementptr inbounds nuw i8, ptr addrspace(3) %11, i64 9216
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v155, ptr addrspace(1) %v153)
  %.idx30 = shl nuw nsw i64 %v10016, 12
  %12 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx30
  %v157 = getelementptr inbounds nuw float, ptr addrspace(1) %12, i64 %v93
  %.idx31 = mul nuw nsw i64 %v10016, 288
  %13 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx31
  %14 = getelementptr inbounds nuw float, ptr addrspace(3) %13, i64 %v91
  %v159 = getelementptr inbounds nuw i8, ptr addrspace(3) %14, i64 9216
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v159, ptr addrspace(1) nonnull %v157)
  %.idx32 = shl nuw nsw i64 %v11117, 12
  %15 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx32
  %v161 = getelementptr inbounds nuw float, ptr addrspace(1) %15, i64 %v93
  %.idx33 = mul nuw nsw i64 %v11117, 288
  %16 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx33
  %17 = getelementptr inbounds nuw float, ptr addrspace(3) %16, i64 %v91
  %v163 = getelementptr inbounds nuw i8, ptr addrspace(3) %17, i64 9216
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v163, ptr addrspace(1) nonnull %v161)
  %.idx34 = shl nuw nsw i64 %v12218, 12
  %18 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx34
  %v165 = getelementptr inbounds nuw float, ptr addrspace(1) %18, i64 %v93
  %.idx35 = mul nuw nsw i64 %v12218, 288
  %19 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx35
  %20 = getelementptr inbounds nuw float, ptr addrspace(3) %19, i64 %v91
  %v167 = getelementptr inbounds nuw i8, ptr addrspace(3) %20, i64 9216
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v167, ptr addrspace(1) nonnull %v165)
  tail call void @llvm.nvvm.cp.async.commit.group()
  %21 = lshr i64 %v2, 1
  %v168 = and i64 %21, 32
  %v227 = and i64 %v2, 15
  %v229 = or disjoint i64 %v168, %v227
  %v231 = and i64 %v8, 4
  %.idx36 = mul nuw nsw i64 %v229, 144
  %invariant.gep = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx36
  %invariant.gep38 = getelementptr inbounds nuw float, ptr addrspace(3) %invariant.gep, i64 %v231
  %.idx37 = mul nuw nsw i64 %v12, 288
  %invariant.gep40 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx37
  %invariant.gep41 = getelementptr inbounds nuw float, ptr addrspace(3) %invariant.gep40, i64 %v10
  %invariant.gep43 = getelementptr inbounds nuw float, ptr addrspace(3) %invariant.gep41, i64 %v1110
  br label %kt

kt:                                               ; preds = %issued, %entry
  %v15.sroa.310.0 = phi float [ 0.000000e+00, %entry ], [ %v873, %issued ]
  %v15.sroa.300.0 = phi float [ 0.000000e+00, %entry ], [ %v872, %issued ]
  %v15.sroa.290.0 = phi float [ 0.000000e+00, %entry ], [ %v871, %issued ]
  %v15.sroa.280.0 = phi float [ 0.000000e+00, %entry ], [ %v870, %issued ]
  %v15.sroa.270.0 = phi float [ 0.000000e+00, %entry ], [ %v860, %issued ]
  %v15.sroa.260.0 = phi float [ 0.000000e+00, %entry ], [ %v859, %issued ]
  %v15.sroa.250.0 = phi float [ 0.000000e+00, %entry ], [ %v858, %issued ]
  %v15.sroa.240.0 = phi float [ 0.000000e+00, %entry ], [ %v857, %issued ]
  %v15.sroa.230.0 = phi float [ 0.000000e+00, %entry ], [ %v847, %issued ]
  %v15.sroa.220.0 = phi float [ 0.000000e+00, %entry ], [ %v846, %issued ]
  %v15.sroa.210.0 = phi float [ 0.000000e+00, %entry ], [ %v845, %issued ]
  %v15.sroa.200.0 = phi float [ 0.000000e+00, %entry ], [ %v844, %issued ]
  %v15.sroa.190.0 = phi float [ 0.000000e+00, %entry ], [ %v834, %issued ]
  %v15.sroa.180.0 = phi float [ 0.000000e+00, %entry ], [ %v833, %issued ]
  %v15.sroa.170.0 = phi float [ 0.000000e+00, %entry ], [ %v832, %issued ]
  %v15.sroa.160.0 = phi float [ 0.000000e+00, %entry ], [ %v831, %issued ]
  %v15.sroa.150.0 = phi float [ 0.000000e+00, %entry ], [ %v821, %issued ]
  %v15.sroa.140.0 = phi float [ 0.000000e+00, %entry ], [ %v820, %issued ]
  %v15.sroa.130.0 = phi float [ 0.000000e+00, %entry ], [ %v819, %issued ]
  %v15.sroa.120.0 = phi float [ 0.000000e+00, %entry ], [ %v818, %issued ]
  %v15.sroa.110.0 = phi float [ 0.000000e+00, %entry ], [ %v808, %issued ]
  %v15.sroa.100.0 = phi float [ 0.000000e+00, %entry ], [ %v807, %issued ]
  %v15.sroa.90.0 = phi float [ 0.000000e+00, %entry ], [ %v806, %issued ]
  %v15.sroa.80.0 = phi float [ 0.000000e+00, %entry ], [ %v805, %issued ]
  %v15.sroa.70.0 = phi float [ 0.000000e+00, %entry ], [ %v795, %issued ]
  %v15.sroa.60.0 = phi float [ 0.000000e+00, %entry ], [ %v794, %issued ]
  %v15.sroa.50.0 = phi float [ 0.000000e+00, %entry ], [ %v793, %issued ]
  %v15.sroa.40.0 = phi float [ 0.000000e+00, %entry ], [ %v792, %issued ]
  %v15.sroa.30.0 = phi float [ 0.000000e+00, %entry ], [ %v782, %issued ]
  %v15.sroa.20.0 = phi float [ 0.000000e+00, %entry ], [ %v781, %issued ]
  %v15.sroa.10.0 = phi float [ 0.000000e+00, %entry ], [ %v780, %issued ]
  %v15.sroa.0.0 = phi float [ 0.000000e+00, %entry ], [ %v779, %issued ]
  %v177 = phi i64 [ 0, %entry ], [ %v179, %issued ]
  tail call void @llvm.nvvm.cp.async.wait.group(i32 0)
  tail call void @llvm.nvvm.barrier.cta.sync.aligned.all(i32 0)
  %v179 = add nuw nsw i64 %v177, 1
  %v180 = icmp samesign ult i64 %v177, 31
  br i1 %v180, label %issue, label %issued

issue:                                            ; preds = %kt
  %v182 = shl nuw nsw i64 %v179, 5
  %v184 = shl nuw nsw i64 %v179, 15
  %22 = trunc i64 %v179 to i1
  %v185 = select i1 %22, i64 4608, i64 0
  %v187 = getelementptr inbounds nuw float, ptr addrspace(1) %v137, i64 %v182
  %v189 = getelementptr inbounds nuw float, ptr addrspace(3) %v139, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v189, ptr addrspace(1) nonnull %v187)
  %v191 = getelementptr inbounds nuw float, ptr addrspace(1) %v141, i64 %v182
  %v193 = getelementptr inbounds nuw float, ptr addrspace(3) %v143, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v193, ptr addrspace(1) nonnull %v191)
  %v195 = getelementptr inbounds nuw float, ptr addrspace(1) %v145, i64 %v182
  %v197 = getelementptr inbounds nuw float, ptr addrspace(3) %v147, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v197, ptr addrspace(1) nonnull %v195)
  %v199 = getelementptr inbounds nuw float, ptr addrspace(1) %v149, i64 %v182
  %v201 = getelementptr inbounds nuw float, ptr addrspace(3) %v151, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v201, ptr addrspace(1) nonnull %v199)
  %v203 = getelementptr inbounds nuw float, ptr addrspace(1) %v153, i64 %v184
  %v205 = getelementptr inbounds nuw float, ptr addrspace(3) %v155, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v205, ptr addrspace(1) nonnull %v203)
  %v207 = getelementptr inbounds nuw float, ptr addrspace(1) %v157, i64 %v184
  %v209 = getelementptr inbounds nuw float, ptr addrspace(3) %v159, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v209, ptr addrspace(1) nonnull %v207)
  %v211 = getelementptr inbounds nuw float, ptr addrspace(1) %v161, i64 %v184
  %v213 = getelementptr inbounds nuw float, ptr addrspace(3) %v163, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v213, ptr addrspace(1) nonnull %v211)
  %v215 = getelementptr inbounds nuw float, ptr addrspace(1) %v165, i64 %v184
  %v217 = getelementptr inbounds nuw float, ptr addrspace(3) %v167, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v217, ptr addrspace(1) nonnull %v215)
  br label %issued

issued:                                           ; preds = %issue, %kt
  tail call void @llvm.nvvm.cp.async.commit.group()
  %23 = trunc i64 %v177 to i1
  %v219 = select i1 %23, i64 4608, i64 0
  %gep39 = getelementptr inbounds nuw float, ptr addrspace(3) %invariant.gep38, i64 %v219
  %24 = ptrtoint ptr addrspace(3) %gep39 to i64
  %v236 = trunc i64 %24 to i32
  %v237 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v236) #2
  %v238 = extractvalue { i32, i32, i32, i32 } %v237, 0
  %v239 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v238) #2
  %v240 = extractvalue { i32, i32, i32, i32 } %v237, 1
  %v241 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v240) #2
  %v242 = extractvalue { i32, i32, i32, i32 } %v237, 2
  %v243 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v242) #2
  %v244 = extractvalue { i32, i32, i32, i32 } %v237, 3
  %v245 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v244) #2
  %v247 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep39, i64 2304
  %25 = ptrtoint ptr addrspace(3) %v247 to i64
  %v248 = trunc i64 %25 to i32
  %v249 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v248) #2
  %v250 = extractvalue { i32, i32, i32, i32 } %v249, 0
  %v251 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v250) #2
  %v252 = extractvalue { i32, i32, i32, i32 } %v249, 1
  %v253 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v252) #2
  %v254 = extractvalue { i32, i32, i32, i32 } %v249, 2
  %v255 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v254) #2
  %v256 = extractvalue { i32, i32, i32, i32 } %v249, 3
  %v257 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v256) #2
  %gep = getelementptr inbounds nuw float, ptr addrspace(3) %invariant.gep43, i64 %v219
  %v259 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 9216
  %v260 = load float, ptr addrspace(3) %v259, align 4
  %v261 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v260) #2
  %v263 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 10368
  %v264 = load float, ptr addrspace(3) %v263, align 4
  %v265 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v264) #2
  %v267 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 9248
  %v268 = load float, ptr addrspace(3) %v267, align 4
  %v269 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v268) #2
  %v271 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 10400
  %v272 = load float, ptr addrspace(3) %v271, align 4
  %v273 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v272) #2
  %v275 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 9280
  %v276 = load float, ptr addrspace(3) %v275, align 4
  %v277 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v276) #2
  %v279 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 10432
  %v280 = load float, ptr addrspace(3) %v279, align 4
  %v281 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v280) #2
  %v283 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 9312
  %v284 = load float, ptr addrspace(3) %v283, align 4
  %v285 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v284) #2
  %v287 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 10464
  %v288 = load float, ptr addrspace(3) %v287, align 4
  %v289 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v288) #2
  %v298 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v239, i32 %v241, i32 %v243, i32 %v245, i32 %v261, i32 %v265, float %v15.sroa.0.0, float %v15.sroa.10.0, float %v15.sroa.20.0, float %v15.sroa.30.0) #2
  %v299 = extractvalue { float, float, float, float } %v298, 0
  %v300 = extractvalue { float, float, float, float } %v298, 1
  %v301 = extractvalue { float, float, float, float } %v298, 2
  %v302 = extractvalue { float, float, float, float } %v298, 3
  %v311 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v239, i32 %v241, i32 %v243, i32 %v245, i32 %v269, i32 %v273, float %v15.sroa.40.0, float %v15.sroa.50.0, float %v15.sroa.60.0, float %v15.sroa.70.0) #2
  %v312 = extractvalue { float, float, float, float } %v311, 0
  %v313 = extractvalue { float, float, float, float } %v311, 1
  %v314 = extractvalue { float, float, float, float } %v311, 2
  %v315 = extractvalue { float, float, float, float } %v311, 3
  %v324 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v239, i32 %v241, i32 %v243, i32 %v245, i32 %v277, i32 %v281, float %v15.sroa.80.0, float %v15.sroa.90.0, float %v15.sroa.100.0, float %v15.sroa.110.0) #2
  %v325 = extractvalue { float, float, float, float } %v324, 0
  %v326 = extractvalue { float, float, float, float } %v324, 1
  %v327 = extractvalue { float, float, float, float } %v324, 2
  %v328 = extractvalue { float, float, float, float } %v324, 3
  %v337 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v239, i32 %v241, i32 %v243, i32 %v245, i32 %v285, i32 %v289, float %v15.sroa.120.0, float %v15.sroa.130.0, float %v15.sroa.140.0, float %v15.sroa.150.0) #2
  %v338 = extractvalue { float, float, float, float } %v337, 0
  %v339 = extractvalue { float, float, float, float } %v337, 1
  %v340 = extractvalue { float, float, float, float } %v337, 2
  %v341 = extractvalue { float, float, float, float } %v337, 3
  %v350 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v251, i32 %v253, i32 %v255, i32 %v257, i32 %v261, i32 %v265, float %v15.sroa.160.0, float %v15.sroa.170.0, float %v15.sroa.180.0, float %v15.sroa.190.0) #2
  %v351 = extractvalue { float, float, float, float } %v350, 0
  %v352 = extractvalue { float, float, float, float } %v350, 1
  %v353 = extractvalue { float, float, float, float } %v350, 2
  %v354 = extractvalue { float, float, float, float } %v350, 3
  %v363 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v251, i32 %v253, i32 %v255, i32 %v257, i32 %v269, i32 %v273, float %v15.sroa.200.0, float %v15.sroa.210.0, float %v15.sroa.220.0, float %v15.sroa.230.0) #2
  %v364 = extractvalue { float, float, float, float } %v363, 0
  %v365 = extractvalue { float, float, float, float } %v363, 1
  %v366 = extractvalue { float, float, float, float } %v363, 2
  %v367 = extractvalue { float, float, float, float } %v363, 3
  %v376 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v251, i32 %v253, i32 %v255, i32 %v257, i32 %v277, i32 %v281, float %v15.sroa.240.0, float %v15.sroa.250.0, float %v15.sroa.260.0, float %v15.sroa.270.0) #2
  %v377 = extractvalue { float, float, float, float } %v376, 0
  %v378 = extractvalue { float, float, float, float } %v376, 1
  %v379 = extractvalue { float, float, float, float } %v376, 2
  %v380 = extractvalue { float, float, float, float } %v376, 3
  %v389 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v251, i32 %v253, i32 %v255, i32 %v257, i32 %v285, i32 %v289, float %v15.sroa.280.0, float %v15.sroa.290.0, float %v15.sroa.300.0, float %v15.sroa.310.0) #2
  %v390 = extractvalue { float, float, float, float } %v389, 0
  %v391 = extractvalue { float, float, float, float } %v389, 1
  %v392 = extractvalue { float, float, float, float } %v389, 2
  %v393 = extractvalue { float, float, float, float } %v389, 3
  %v395 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep39, i64 32
  %26 = ptrtoint ptr addrspace(3) %v395 to i64
  %v396 = trunc i64 %26 to i32
  %v397 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v396) #2
  %v398 = extractvalue { i32, i32, i32, i32 } %v397, 0
  %v399 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v398) #2
  %v400 = extractvalue { i32, i32, i32, i32 } %v397, 1
  %v401 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v400) #2
  %v402 = extractvalue { i32, i32, i32, i32 } %v397, 2
  %v403 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v402) #2
  %v404 = extractvalue { i32, i32, i32, i32 } %v397, 3
  %v405 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v404) #2
  %v407 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep39, i64 2336
  %27 = ptrtoint ptr addrspace(3) %v407 to i64
  %v408 = trunc i64 %27 to i32
  %v409 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v408) #2
  %v410 = extractvalue { i32, i32, i32, i32 } %v409, 0
  %v411 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v410) #2
  %v412 = extractvalue { i32, i32, i32, i32 } %v409, 1
  %v413 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v412) #2
  %v414 = extractvalue { i32, i32, i32, i32 } %v409, 2
  %v415 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v414) #2
  %v416 = extractvalue { i32, i32, i32, i32 } %v409, 3
  %v417 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v416) #2
  %v419 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 11520
  %v420 = load float, ptr addrspace(3) %v419, align 4
  %v421 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v420) #2
  %v423 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 12672
  %v424 = load float, ptr addrspace(3) %v423, align 4
  %v425 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v424) #2
  %v427 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 11552
  %v428 = load float, ptr addrspace(3) %v427, align 4
  %v429 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v428) #2
  %v431 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 12704
  %v432 = load float, ptr addrspace(3) %v431, align 4
  %v433 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v432) #2
  %v435 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 11584
  %v436 = load float, ptr addrspace(3) %v435, align 4
  %v437 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v436) #2
  %v439 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 12736
  %v440 = load float, ptr addrspace(3) %v439, align 4
  %v441 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v440) #2
  %v443 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 11616
  %v444 = load float, ptr addrspace(3) %v443, align 4
  %v445 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v444) #2
  %v447 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 12768
  %v448 = load float, ptr addrspace(3) %v447, align 4
  %v449 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v448) #2
  %v458 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v399, i32 %v401, i32 %v403, i32 %v405, i32 %v421, i32 %v425, float %v299, float %v300, float %v301, float %v302) #2
  %v459 = extractvalue { float, float, float, float } %v458, 0
  %v460 = extractvalue { float, float, float, float } %v458, 1
  %v461 = extractvalue { float, float, float, float } %v458, 2
  %v462 = extractvalue { float, float, float, float } %v458, 3
  %v471 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v399, i32 %v401, i32 %v403, i32 %v405, i32 %v429, i32 %v433, float %v312, float %v313, float %v314, float %v315) #2
  %v472 = extractvalue { float, float, float, float } %v471, 0
  %v473 = extractvalue { float, float, float, float } %v471, 1
  %v474 = extractvalue { float, float, float, float } %v471, 2
  %v475 = extractvalue { float, float, float, float } %v471, 3
  %v484 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v399, i32 %v401, i32 %v403, i32 %v405, i32 %v437, i32 %v441, float %v325, float %v326, float %v327, float %v328) #2
  %v485 = extractvalue { float, float, float, float } %v484, 0
  %v486 = extractvalue { float, float, float, float } %v484, 1
  %v487 = extractvalue { float, float, float, float } %v484, 2
  %v488 = extractvalue { float, float, float, float } %v484, 3
  %v497 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v399, i32 %v401, i32 %v403, i32 %v405, i32 %v445, i32 %v449, float %v338, float %v339, float %v340, float %v341) #2
  %v498 = extractvalue { float, float, float, float } %v497, 0
  %v499 = extractvalue { float, float, float, float } %v497, 1
  %v500 = extractvalue { float, float, float, float } %v497, 2
  %v501 = extractvalue { float, float, float, float } %v497, 3
  %v510 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v411, i32 %v413, i32 %v415, i32 %v417, i32 %v421, i32 %v425, float %v351, float %v352, float %v353, float %v354) #2
  %v511 = extractvalue { float, float, float, float } %v510, 0
  %v512 = extractvalue { float, float, float, float } %v510, 1
  %v513 = extractvalue { float, float, float, float } %v510, 2
  %v514 = extractvalue { float, float, float, float } %v510, 3
  %v523 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v411, i32 %v413, i32 %v415, i32 %v417, i32 %v429, i32 %v433, float %v364, float %v365, float %v366, float %v367) #2
  %v524 = extractvalue { float, float, float, float } %v523, 0
  %v525 = extractvalue { float, float, float, float } %v523, 1
  %v526 = extractvalue { float, float, float, float } %v523, 2
  %v527 = extractvalue { float, float, float, float } %v523, 3
  %v536 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v411, i32 %v413, i32 %v415, i32 %v417, i32 %v437, i32 %v441, float %v377, float %v378, float %v379, float %v380) #2
  %v537 = extractvalue { float, float, float, float } %v536, 0
  %v538 = extractvalue { float, float, float, float } %v536, 1
  %v539 = extractvalue { float, float, float, float } %v536, 2
  %v540 = extractvalue { float, float, float, float } %v536, 3
  %v549 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v411, i32 %v413, i32 %v415, i32 %v417, i32 %v445, i32 %v449, float %v390, float %v391, float %v392, float %v393) #2
  %v550 = extractvalue { float, float, float, float } %v549, 0
  %v551 = extractvalue { float, float, float, float } %v549, 1
  %v552 = extractvalue { float, float, float, float } %v549, 2
  %v553 = extractvalue { float, float, float, float } %v549, 3
  %v555 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep39, i64 64
  %28 = ptrtoint ptr addrspace(3) %v555 to i64
  %v556 = trunc i64 %28 to i32
  %v557 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v556) #2
  %v558 = extractvalue { i32, i32, i32, i32 } %v557, 0
  %v559 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v558) #2
  %v560 = extractvalue { i32, i32, i32, i32 } %v557, 1
  %v561 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v560) #2
  %v562 = extractvalue { i32, i32, i32, i32 } %v557, 2
  %v563 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v562) #2
  %v564 = extractvalue { i32, i32, i32, i32 } %v557, 3
  %v565 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v564) #2
  %v567 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep39, i64 2368
  %29 = ptrtoint ptr addrspace(3) %v567 to i64
  %v568 = trunc i64 %29 to i32
  %v569 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v568) #2
  %v570 = extractvalue { i32, i32, i32, i32 } %v569, 0
  %v571 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v570) #2
  %v572 = extractvalue { i32, i32, i32, i32 } %v569, 1
  %v573 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v572) #2
  %v574 = extractvalue { i32, i32, i32, i32 } %v569, 2
  %v575 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v574) #2
  %v576 = extractvalue { i32, i32, i32, i32 } %v569, 3
  %v577 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v576) #2
  %v579 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 13824
  %v580 = load float, ptr addrspace(3) %v579, align 4
  %v581 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v580) #2
  %v583 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 14976
  %v584 = load float, ptr addrspace(3) %v583, align 4
  %v585 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v584) #2
  %v587 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 13856
  %v588 = load float, ptr addrspace(3) %v587, align 4
  %v589 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v588) #2
  %v591 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 15008
  %v592 = load float, ptr addrspace(3) %v591, align 4
  %v593 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v592) #2
  %v595 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 13888
  %v596 = load float, ptr addrspace(3) %v595, align 4
  %v597 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v596) #2
  %v599 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 15040
  %v600 = load float, ptr addrspace(3) %v599, align 4
  %v601 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v600) #2
  %v603 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 13920
  %v604 = load float, ptr addrspace(3) %v603, align 4
  %v605 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v604) #2
  %v607 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 15072
  %v608 = load float, ptr addrspace(3) %v607, align 4
  %v609 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v608) #2
  %v618 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v559, i32 %v561, i32 %v563, i32 %v565, i32 %v581, i32 %v585, float %v459, float %v460, float %v461, float %v462) #2
  %v619 = extractvalue { float, float, float, float } %v618, 0
  %v620 = extractvalue { float, float, float, float } %v618, 1
  %v621 = extractvalue { float, float, float, float } %v618, 2
  %v622 = extractvalue { float, float, float, float } %v618, 3
  %v631 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v559, i32 %v561, i32 %v563, i32 %v565, i32 %v589, i32 %v593, float %v472, float %v473, float %v474, float %v475) #2
  %v632 = extractvalue { float, float, float, float } %v631, 0
  %v633 = extractvalue { float, float, float, float } %v631, 1
  %v634 = extractvalue { float, float, float, float } %v631, 2
  %v635 = extractvalue { float, float, float, float } %v631, 3
  %v644 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v559, i32 %v561, i32 %v563, i32 %v565, i32 %v597, i32 %v601, float %v485, float %v486, float %v487, float %v488) #2
  %v645 = extractvalue { float, float, float, float } %v644, 0
  %v646 = extractvalue { float, float, float, float } %v644, 1
  %v647 = extractvalue { float, float, float, float } %v644, 2
  %v648 = extractvalue { float, float, float, float } %v644, 3
  %v657 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v559, i32 %v561, i32 %v563, i32 %v565, i32 %v605, i32 %v609, float %v498, float %v499, float %v500, float %v501) #2
  %v658 = extractvalue { float, float, float, float } %v657, 0
  %v659 = extractvalue { float, float, float, float } %v657, 1
  %v660 = extractvalue { float, float, float, float } %v657, 2
  %v661 = extractvalue { float, float, float, float } %v657, 3
  %v670 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v571, i32 %v573, i32 %v575, i32 %v577, i32 %v581, i32 %v585, float %v511, float %v512, float %v513, float %v514) #2
  %v671 = extractvalue { float, float, float, float } %v670, 0
  %v672 = extractvalue { float, float, float, float } %v670, 1
  %v673 = extractvalue { float, float, float, float } %v670, 2
  %v674 = extractvalue { float, float, float, float } %v670, 3
  %v683 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v571, i32 %v573, i32 %v575, i32 %v577, i32 %v589, i32 %v593, float %v524, float %v525, float %v526, float %v527) #2
  %v684 = extractvalue { float, float, float, float } %v683, 0
  %v685 = extractvalue { float, float, float, float } %v683, 1
  %v686 = extractvalue { float, float, float, float } %v683, 2
  %v687 = extractvalue { float, float, float, float } %v683, 3
  %v696 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v571, i32 %v573, i32 %v575, i32 %v577, i32 %v597, i32 %v601, float %v537, float %v538, float %v539, float %v540) #2
  %v697 = extractvalue { float, float, float, float } %v696, 0
  %v698 = extractvalue { float, float, float, float } %v696, 1
  %v699 = extractvalue { float, float, float, float } %v696, 2
  %v700 = extractvalue { float, float, float, float } %v696, 3
  %v709 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v571, i32 %v573, i32 %v575, i32 %v577, i32 %v605, i32 %v609, float %v550, float %v551, float %v552, float %v553) #2
  %v710 = extractvalue { float, float, float, float } %v709, 0
  %v711 = extractvalue { float, float, float, float } %v709, 1
  %v712 = extractvalue { float, float, float, float } %v709, 2
  %v713 = extractvalue { float, float, float, float } %v709, 3
  %v715 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep39, i64 96
  %30 = ptrtoint ptr addrspace(3) %v715 to i64
  %v716 = trunc i64 %30 to i32
  %v717 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v716) #2
  %v718 = extractvalue { i32, i32, i32, i32 } %v717, 0
  %v719 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v718) #2
  %v720 = extractvalue { i32, i32, i32, i32 } %v717, 1
  %v721 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v720) #2
  %v722 = extractvalue { i32, i32, i32, i32 } %v717, 2
  %v723 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v722) #2
  %v724 = extractvalue { i32, i32, i32, i32 } %v717, 3
  %v725 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v724) #2
  %v727 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep39, i64 2400
  %31 = ptrtoint ptr addrspace(3) %v727 to i64
  %v728 = trunc i64 %31 to i32
  %v729 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v728) #2
  %v730 = extractvalue { i32, i32, i32, i32 } %v729, 0
  %v731 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v730) #2
  %v732 = extractvalue { i32, i32, i32, i32 } %v729, 1
  %v733 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v732) #2
  %v734 = extractvalue { i32, i32, i32, i32 } %v729, 2
  %v735 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v734) #2
  %v736 = extractvalue { i32, i32, i32, i32 } %v729, 3
  %v737 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v736) #2
  %v739 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 16128
  %v740 = load float, ptr addrspace(3) %v739, align 4
  %v741 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v740) #2
  %v743 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 17280
  %v744 = load float, ptr addrspace(3) %v743, align 4
  %v745 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v744) #2
  %v747 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 16160
  %v748 = load float, ptr addrspace(3) %v747, align 4
  %v749 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v748) #2
  %v751 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 17312
  %v752 = load float, ptr addrspace(3) %v751, align 4
  %v753 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v752) #2
  %v755 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 16192
  %v756 = load float, ptr addrspace(3) %v755, align 4
  %v757 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v756) #2
  %v759 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 17344
  %v760 = load float, ptr addrspace(3) %v759, align 4
  %v761 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v760) #2
  %v763 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 16224
  %v764 = load float, ptr addrspace(3) %v763, align 4
  %v765 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v764) #2
  %v767 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 17376
  %v768 = load float, ptr addrspace(3) %v767, align 4
  %v769 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v768) #2
  %v778 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v719, i32 %v721, i32 %v723, i32 %v725, i32 %v741, i32 %v745, float %v619, float %v620, float %v621, float %v622) #2
  %v779 = extractvalue { float, float, float, float } %v778, 0
  %v780 = extractvalue { float, float, float, float } %v778, 1
  %v781 = extractvalue { float, float, float, float } %v778, 2
  %v782 = extractvalue { float, float, float, float } %v778, 3
  %v791 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v719, i32 %v721, i32 %v723, i32 %v725, i32 %v749, i32 %v753, float %v632, float %v633, float %v634, float %v635) #2
  %v792 = extractvalue { float, float, float, float } %v791, 0
  %v793 = extractvalue { float, float, float, float } %v791, 1
  %v794 = extractvalue { float, float, float, float } %v791, 2
  %v795 = extractvalue { float, float, float, float } %v791, 3
  %v804 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v719, i32 %v721, i32 %v723, i32 %v725, i32 %v757, i32 %v761, float %v645, float %v646, float %v647, float %v648) #2
  %v805 = extractvalue { float, float, float, float } %v804, 0
  %v806 = extractvalue { float, float, float, float } %v804, 1
  %v807 = extractvalue { float, float, float, float } %v804, 2
  %v808 = extractvalue { float, float, float, float } %v804, 3
  %v817 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v719, i32 %v721, i32 %v723, i32 %v725, i32 %v765, i32 %v769, float %v658, float %v659, float %v660, float %v661) #2
  %v818 = extractvalue { float, float, float, float } %v817, 0
  %v819 = extractvalue { float, float, float, float } %v817, 1
  %v820 = extractvalue { float, float, float, float } %v817, 2
  %v821 = extractvalue { float, float, float, float } %v817, 3
  %v830 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v731, i32 %v733, i32 %v735, i32 %v737, i32 %v741, i32 %v745, float %v671, float %v672, float %v673, float %v674) #2
  %v831 = extractvalue { float, float, float, float } %v830, 0
  %v832 = extractvalue { float, float, float, float } %v830, 1
  %v833 = extractvalue { float, float, float, float } %v830, 2
  %v834 = extractvalue { float, float, float, float } %v830, 3
  %v843 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v731, i32 %v733, i32 %v735, i32 %v737, i32 %v749, i32 %v753, float %v684, float %v685, float %v686, float %v687) #2
  %v844 = extractvalue { float, float, float, float } %v843, 0
  %v845 = extractvalue { float, float, float, float } %v843, 1
  %v846 = extractvalue { float, float, float, float } %v843, 2
  %v847 = extractvalue { float, float, float, float } %v843, 3
  %v856 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v731, i32 %v733, i32 %v735, i32 %v737, i32 %v757, i32 %v761, float %v697, float %v698, float %v699, float %v700) #2
  %v857 = extractvalue { float, float, float, float } %v856, 0
  %v858 = extractvalue { float, float, float, float } %v856, 1
  %v859 = extractvalue { float, float, float, float } %v856, 2
  %v860 = extractvalue { float, float, float, float } %v856, 3
  %v869 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v731, i32 %v733, i32 %v735, i32 %v737, i32 %v765, i32 %v769, float %v710, float %v711, float %v712, float %v713) #2
  %v870 = extractvalue { float, float, float, float } %v869, 0
  %v871 = extractvalue { float, float, float, float } %v869, 1
  %v872 = extractvalue { float, float, float, float } %v869, 2
  %v873 = extractvalue { float, float, float, float } %v869, 3
  %v874 = icmp eq i64 %v179, 32
  br i1 %v874, label %done, label %kt

done:                                             ; preds = %issued
  %v876 = or disjoint i64 %v168, %v13
  %v877 = or disjoint i64 %v876, %v1110
  %v880 = shl nuw nsw i64 %v12, 1
  %32 = or disjoint i64 %v880, %v14
  %v881 = or disjoint i64 %32, %v10
  %v887 = insertelement <2 x float> poison, float %v779, i64 0
  %v890 = insertelement <2 x float> %v887, float %v780, i64 1
  %.idx44 = shl nuw nsw i64 %v877, 12
  %33 = getelementptr inbounds nuw i8, ptr addrspace(1) %o, i64 %.idx44
  %v892 = getelementptr inbounds nuw float, ptr addrspace(1) %33, i64 %v881
  store <2 x float> %v890, ptr addrspace(1) %v892, align 8
  %v895 = insertelement <2 x float> poison, float %v792, i64 0
  %v898 = insertelement <2 x float> %v895, float %v793, i64 1
  %v900 = getelementptr inbounds nuw i8, ptr addrspace(1) %v892, i64 32
  store <2 x float> %v898, ptr addrspace(1) %v900, align 8
  %v903 = insertelement <2 x float> poison, float %v805, i64 0
  %v906 = insertelement <2 x float> %v903, float %v806, i64 1
  %v908 = getelementptr inbounds nuw i8, ptr addrspace(1) %v892, i64 64
  store <2 x float> %v906, ptr addrspace(1) %v908, align 8
  %v911 = insertelement <2 x float> poison, float %v818, i64 0
  %v914 = insertelement <2 x float> %v911, float %v819, i64 1
  %v916 = getelementptr inbounds nuw i8, ptr addrspace(1) %v892, i64 96
  store <2 x float> %v914, ptr addrspace(1) %v916, align 8
  %v922 = insertelement <2 x float> poison, float %v781, i64 0
  %v925 = insertelement <2 x float> %v922, float %v782, i64 1
  %34 = getelementptr inbounds nuw i8, ptr addrspace(1) %33, i64 32768
  %v927 = getelementptr inbounds nuw float, ptr addrspace(1) %34, i64 %v881
  store <2 x float> %v925, ptr addrspace(1) %v927, align 8
  %v930 = insertelement <2 x float> poison, float %v794, i64 0
  %v933 = insertelement <2 x float> %v930, float %v795, i64 1
  %v935 = getelementptr inbounds nuw i8, ptr addrspace(1) %v927, i64 32
  store <2 x float> %v933, ptr addrspace(1) %v935, align 8
  %v938 = insertelement <2 x float> poison, float %v807, i64 0
  %v941 = insertelement <2 x float> %v938, float %v808, i64 1
  %v943 = getelementptr inbounds nuw i8, ptr addrspace(1) %v927, i64 64
  store <2 x float> %v941, ptr addrspace(1) %v943, align 8
  %v946 = insertelement <2 x float> poison, float %v820, i64 0
  %v949 = insertelement <2 x float> %v946, float %v821, i64 1
  %v951 = getelementptr inbounds nuw i8, ptr addrspace(1) %v927, i64 96
  store <2 x float> %v949, ptr addrspace(1) %v951, align 8
  %v957 = insertelement <2 x float> poison, float %v831, i64 0
  %v960 = insertelement <2 x float> %v957, float %v832, i64 1
  %35 = getelementptr inbounds nuw i8, ptr addrspace(1) %33, i64 65536
  %v962 = getelementptr inbounds nuw float, ptr addrspace(1) %35, i64 %v881
  store <2 x float> %v960, ptr addrspace(1) %v962, align 8
  %v965 = insertelement <2 x float> poison, float %v844, i64 0
  %v968 = insertelement <2 x float> %v965, float %v845, i64 1
  %v970 = getelementptr inbounds nuw i8, ptr addrspace(1) %v962, i64 32
  store <2 x float> %v968, ptr addrspace(1) %v970, align 8
  %v973 = insertelement <2 x float> poison, float %v857, i64 0
  %v976 = insertelement <2 x float> %v973, float %v858, i64 1
  %v978 = getelementptr inbounds nuw i8, ptr addrspace(1) %v962, i64 64
  store <2 x float> %v976, ptr addrspace(1) %v978, align 8
  %v981 = insertelement <2 x float> poison, float %v870, i64 0
  %v984 = insertelement <2 x float> %v981, float %v871, i64 1
  %v986 = getelementptr inbounds nuw i8, ptr addrspace(1) %v962, i64 96
  store <2 x float> %v984, ptr addrspace(1) %v986, align 8
  %v992 = insertelement <2 x float> poison, float %v833, i64 0
  %v995 = insertelement <2 x float> %v992, float %v834, i64 1
  %36 = getelementptr inbounds nuw i8, ptr addrspace(1) %33, i64 98304
  %v997 = getelementptr inbounds nuw float, ptr addrspace(1) %36, i64 %v881
  store <2 x float> %v995, ptr addrspace(1) %v997, align 8
  %v1000 = insertelement <2 x float> poison, float %v846, i64 0
  %v1003 = insertelement <2 x float> %v1000, float %v847, i64 1
  %v1005 = getelementptr inbounds nuw i8, ptr addrspace(1) %v997, i64 32
  store <2 x float> %v1003, ptr addrspace(1) %v1005, align 8
  %v1008 = insertelement <2 x float> poison, float %v859, i64 0
  %v1011 = insertelement <2 x float> %v1008, float %v860, i64 1
  %v1013 = getelementptr inbounds nuw i8, ptr addrspace(1) %v997, i64 64
  store <2 x float> %v1011, ptr addrspace(1) %v1013, align 8
  %v1016 = insertelement <2 x float> poison, float %v872, i64 0
  %v1019 = insertelement <2 x float> %v1016, float %v873, i64 1
  %v1021 = getelementptr inbounds nuw i8, ptr addrspace(1) %v997, i64 96
  store <2 x float> %v1019, ptr addrspace(1) %v1021, align 8
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_7a2ade86c804ef09(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #4 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %p = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %i
  %x = trunc i64 %i to i32
  %t7.i = mul i32 %x, 7
  %t15.i = add i32 %t7.i, 13
  %t23.i = srem i32 %t15.i, 101
  %t31.i = add nsw i32 %t23.i, -50
  %t33.i = sitofp i32 %t31.i to float
  store float %t33.i, ptr addrspace(1) %p, align 4
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_1aeae5b5ba14d87e(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #4 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %p = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %i
  %x = trunc i64 %i to i32
  %t7.i = mul i32 %x, 7
  %t15.i = add i32 %t7.i, 57
  %t23.i = srem i32 %t15.i, 101
  %t31.i = add nsw i32 %t23.i, -50
  %t33.i = sitofp i32 %t31.i to float
  store float %t33.i, ptr addrspace(1) %p, align 4
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.barrier.cta.sync.aligned.all(i32) #5

attributes #0 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nounwind memory(argmem: readwrite) }
attributes #2 = { nounwind }
attributes #3 = { nounwind "nvvm.maxntid"="128" "nvvm.minctasm"="2" }
attributes #4 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) "nvvm.maxntid"="256" }
attributes #5 = { convergent nocallback nounwind }
