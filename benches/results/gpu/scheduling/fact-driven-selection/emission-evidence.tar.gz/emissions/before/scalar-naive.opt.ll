; ModuleID = '/private/tmp/mapal-gpu-schedule-facts/emissions/before/scalar-naive.device.ll'
source_filename = "/private/tmp/mapal-gpu-schedule-facts/emissions/before/scalar-naive.device.ll"
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 2147483647) i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define ptx_kernel void @mapal_tile_2afdc9f1d235b869(ptr addrspace(1) noalias readonly align 4 captures(none) %a, ptr addrspace(1) noalias readonly align 4 captures(none) %b, ptr addrspace(1) noalias writeonly align 4 captures(none) %o) local_unnamed_addr #1 {
entry:
  %v1 = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v3 = shl nuw nsw i32 %v2, 8
  %v4 = or disjoint i32 %v3, %v1
  %v5 = icmp samesign ult i32 %v4, 10000
  br i1 %v5, label %body, label %done

body:                                             ; preds = %entry
  %v7.lhs.trunc = trunc nuw nsw i32 %v4 to i16
  %v71 = urem i16 %v7.lhs.trunc, 100
  %v7.zext = zext nneg i16 %v71 to i32
  %v8 = sub nsw i32 %v4, %v7.zext
  br label %kloop

kloop:                                            ; preds = %kloop, %body
  %v16 = phi i32 [ 0, %body ], [ %v18.4, %kloop ]
  %v17 = phi float [ 0.000000e+00, %body ], [ %v29.4, %kloop ]
  %v20 = add nuw nsw i32 %v8, %v16
  %v21 = zext nneg i32 %v20 to i64
  %v22 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v21
  %v23 = load float, ptr addrspace(1) %v22, align 4
  %v24 = mul nuw nsw i32 %v16, 100
  %v25 = add nuw nsw i32 %v24, %v7.zext
  %v26 = zext nneg i32 %v25 to i64
  %v27 = getelementptr inbounds nuw float, ptr addrspace(1) %b, i64 %v26
  %v28 = load float, ptr addrspace(1) %v27, align 4
  %v30 = fmul float %v23, %v28
  %v29 = fadd float %v17, %v30
  %v18 = add nuw nsw i32 %v16, 1
  %v20.1 = add nuw nsw i32 %v8, %v18
  %v21.1 = zext nneg i32 %v20.1 to i64
  %v22.1 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v21.1
  %v23.1 = load float, ptr addrspace(1) %v22.1, align 4
  %v24.1 = mul nuw nsw i32 %v18, 100
  %v25.1 = add nuw nsw i32 %v24.1, %v7.zext
  %v26.1 = zext nneg i32 %v25.1 to i64
  %v27.1 = getelementptr inbounds nuw float, ptr addrspace(1) %b, i64 %v26.1
  %v28.1 = load float, ptr addrspace(1) %v27.1, align 4
  %v30.1 = fmul float %v23.1, %v28.1
  %v29.1 = fadd float %v29, %v30.1
  %v18.1 = add nuw nsw i32 %v16, 2
  %v20.2 = add nuw nsw i32 %v8, %v18.1
  %v21.2 = zext nneg i32 %v20.2 to i64
  %v22.2 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v21.2
  %v23.2 = load float, ptr addrspace(1) %v22.2, align 4
  %v24.2 = mul nuw nsw i32 %v18.1, 100
  %v25.2 = add nuw nsw i32 %v24.2, %v7.zext
  %v26.2 = zext nneg i32 %v25.2 to i64
  %v27.2 = getelementptr inbounds nuw float, ptr addrspace(1) %b, i64 %v26.2
  %v28.2 = load float, ptr addrspace(1) %v27.2, align 4
  %v30.2 = fmul float %v23.2, %v28.2
  %v29.2 = fadd float %v29.1, %v30.2
  %v18.2 = add nuw nsw i32 %v16, 3
  %v20.3 = add nuw nsw i32 %v8, %v18.2
  %v21.3 = zext nneg i32 %v20.3 to i64
  %v22.3 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v21.3
  %v23.3 = load float, ptr addrspace(1) %v22.3, align 4
  %v24.3 = mul nuw nsw i32 %v18.2, 100
  %v25.3 = add nuw nsw i32 %v24.3, %v7.zext
  %v26.3 = zext nneg i32 %v25.3 to i64
  %v27.3 = getelementptr inbounds nuw float, ptr addrspace(1) %b, i64 %v26.3
  %v28.3 = load float, ptr addrspace(1) %v27.3, align 4
  %v30.3 = fmul float %v23.3, %v28.3
  %v29.3 = fadd float %v29.2, %v30.3
  %v18.3 = add nuw nsw i32 %v16, 4
  %v20.4 = add nuw nsw i32 %v8, %v18.3
  %v21.4 = zext nneg i32 %v20.4 to i64
  %v22.4 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v21.4
  %v23.4 = load float, ptr addrspace(1) %v22.4, align 4
  %v24.4 = mul nuw nsw i32 %v18.3, 100
  %v25.4 = add nuw nsw i32 %v24.4, %v7.zext
  %v26.4 = zext nneg i32 %v25.4 to i64
  %v27.4 = getelementptr inbounds nuw float, ptr addrspace(1) %b, i64 %v26.4
  %v28.4 = load float, ptr addrspace(1) %v27.4, align 4
  %v30.4 = fmul float %v23.4, %v28.4
  %v29.4 = fadd float %v29.3, %v30.4
  %v18.4 = add nuw nsw i32 %v16, 5
  %v31.4 = icmp eq i32 %v18.4, 100
  br i1 %v31.4, label %store, label %kloop

store:                                            ; preds = %kloop
  %v32 = zext nneg i32 %v4 to i64
  %v33 = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %v32
  store float %v29.4, ptr addrspace(1) %v33, align 4
  br label %done

done:                                             ; preds = %store, %entry
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_eca9109563f90933(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #2 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %x = trunc i64 %i to i32
  %t7.i = mul i32 %x, 7
  %t15.i = add i32 %t7.i, 13
  %t23.i = srem i32 %t15.i, 101
  %t31.i = add nsw i32 %t23.i, -50
  %t33.i = sitofp i32 %t31.i to float
  %t41.i = fdiv float %t33.i, 7.000000e+00
  %p = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %i
  store float %t41.i, ptr addrspace(1) %p, align 4
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_0fc1d9d22d098f80(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #2 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %x = trunc i64 %i to i32
  %t7.i = mul i32 %x, 11
  %t15.i = add i32 %t7.i, 57
  %t23.i = srem i32 %t15.i, 103
  %t31.i = add nsw i32 %t23.i, -51
  %t33.i = sitofp i32 %t31.i to float
  %t41.i = fdiv float %t33.i, 9.000000e+00
  %p = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %i
  store float %t41.i, ptr addrspace(1) %p, align 4
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

attributes #0 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nofree norecurse nosync nounwind memory(argmem: readwrite) "nvvm.maxntid"="256" }
attributes #2 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) "nvvm.maxntid"="256" }
