; ModuleID = '/private/tmp/mapal-gpu-schedule-facts/emissions/before/mma-default.device.ll'
source_filename = "/private/tmp/mapal-gpu-schedule-facts/emissions/before/mma-default.device.ll"
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@mapal_smem = external addrspace(3) global [0 x i8], align 16

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 2147483647) i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #0

; Function Attrs: nocallback nounwind memory(argmem: readwrite)
declare void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) noalias writeonly, ptr addrspace(1) noalias readonly) #1

; Function Attrs: nounwind
declare void @llvm.nvvm.cp.async.commit.group() #2

; Function Attrs: nounwind
declare void @llvm.nvvm.cp.async.wait.group(i32 immarg) #2

; Function Attrs: nounwind
define ptx_kernel void @mapal_tile_d0cfb9881535775e(ptr addrspace(1) noalias readonly align 16 %a, ptr addrspace(1) noalias readonly align 16 %b, ptr addrspace(1) noalias writeonly align 16 captures(none) %o) local_unnamed_addr #3 {
entry:
  %v1 = tail call range(i32 0, 128) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = zext nneg i32 %v1 to i64
  %v3 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v4 = zext nneg i32 %v3 to i64
  %v5 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v10 = and i64 %v2, 32
  %v8 = lshr i64 %v2, 2
  %v1110 = and i64 %v8, 7
  %v12 = and i64 %v2, 3
  %0 = shl nuw nsw i32 %v5, 6
  %v13 = zext nneg i32 %0 to i64
  %v14 = shl nuw nsw i64 %v4, 6
  %v4911 = lshr i64 %v2, 3
  %v50 = shl nuw nsw i64 %v2, 2
  %v51 = and i64 %v50, 28
  %v52 = or disjoint i64 %v4911, %v13
  %v58 = or disjoint i64 %v2, 128
  %v5912 = lshr i64 %v58, 3
  %v62 = or disjoint i64 %v5912, %v13
  %v68 = or disjoint i64 %v2, 256
  %v6913 = lshr i64 %v68, 3
  %v72 = or disjoint i64 %v6913, %v13
  %v78 = or disjoint i64 %v2, 384
  %v7914 = lshr i64 %v78, 3
  %v82 = or disjoint i64 %v7914, %v13
  %v8915 = lshr i64 %v2, 4
  %v91 = and i64 %v50, 60
  %v93 = or disjoint i64 %v91, %v14
  %v10016 = lshr i64 %v58, 4
  %v11117 = lshr i64 %v68, 4
  %v12218 = lshr i64 %v78, 4
  %.idx = shl nuw nsw i64 %v52, 12
  %1 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx
  %v137 = getelementptr inbounds nuw float, ptr addrspace(1) %1, i64 %v51
  %.idx19 = mul nuw nsw i64 %v4911, 144
  %2 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx19
  %v139 = getelementptr inbounds nuw float, ptr addrspace(3) %2, i64 %v51
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v139, ptr addrspace(1) %v137)
  %.idx20 = shl nuw nsw i64 %v62, 12
  %3 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx20
  %v141 = getelementptr inbounds nuw float, ptr addrspace(1) %3, i64 %v51
  %.idx21 = mul nuw nsw i64 %v5912, 144
  %4 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx21
  %v143 = getelementptr inbounds nuw float, ptr addrspace(3) %4, i64 %v51
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v143, ptr addrspace(1) %v141)
  %.idx22 = shl nuw nsw i64 %v72, 12
  %5 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx22
  %v145 = getelementptr inbounds nuw float, ptr addrspace(1) %5, i64 %v51
  %.idx23 = mul nuw nsw i64 %v6913, 144
  %6 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx23
  %v147 = getelementptr inbounds nuw float, ptr addrspace(3) %6, i64 %v51
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v147, ptr addrspace(1) %v145)
  %.idx24 = shl nuw nsw i64 %v82, 12
  %7 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx24
  %v149 = getelementptr inbounds nuw float, ptr addrspace(1) %7, i64 %v51
  %.idx25 = mul nuw nsw i64 %v7914, 144
  %8 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx25
  %v151 = getelementptr inbounds nuw float, ptr addrspace(3) %8, i64 %v51
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v151, ptr addrspace(1) %v149)
  %.idx26 = shl nuw nsw i64 %v8915, 12
  %9 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx26
  %v153 = getelementptr inbounds nuw float, ptr addrspace(1) %9, i64 %v93
  %.idx27 = mul nuw nsw i64 %v8915, 288
  %10 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx27
  %11 = getelementptr inbounds nuw float, ptr addrspace(3) %10, i64 %v91
  %v155 = getelementptr inbounds nuw i8, ptr addrspace(3) %11, i64 9216
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v155, ptr addrspace(1) %v153)
  %.idx28 = shl nuw nsw i64 %v10016, 12
  %12 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx28
  %v157 = getelementptr inbounds nuw float, ptr addrspace(1) %12, i64 %v93
  %.idx29 = mul nuw nsw i64 %v10016, 288
  %13 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx29
  %14 = getelementptr inbounds nuw float, ptr addrspace(3) %13, i64 %v91
  %v159 = getelementptr inbounds nuw i8, ptr addrspace(3) %14, i64 9216
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v159, ptr addrspace(1) nonnull %v157)
  %.idx30 = shl nuw nsw i64 %v11117, 12
  %15 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx30
  %v161 = getelementptr inbounds nuw float, ptr addrspace(1) %15, i64 %v93
  %.idx31 = mul nuw nsw i64 %v11117, 288
  %16 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx31
  %17 = getelementptr inbounds nuw float, ptr addrspace(3) %16, i64 %v91
  %v163 = getelementptr inbounds nuw i8, ptr addrspace(3) %17, i64 9216
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v163, ptr addrspace(1) nonnull %v161)
  %.idx32 = shl nuw nsw i64 %v12218, 12
  %18 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx32
  %v165 = getelementptr inbounds nuw float, ptr addrspace(1) %18, i64 %v93
  %.idx33 = mul nuw nsw i64 %v12218, 288
  %19 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx33
  %20 = getelementptr inbounds nuw float, ptr addrspace(3) %19, i64 %v91
  %v167 = getelementptr inbounds nuw i8, ptr addrspace(3) %20, i64 9216
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v167, ptr addrspace(1) nonnull %v165)
  tail call void @llvm.nvvm.cp.async.commit.group()
  %21 = lshr i64 %v2, 1
  %v168 = and i64 %21, 32
  %v169 = or disjoint i64 %v168, %v1110
  %.idx34 = mul nuw nsw i64 %v169, 144
  %invariant.gep = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx34
  %invariant.gep36 = getelementptr inbounds nuw float, ptr addrspace(3) %invariant.gep, i64 %v12
  %.idx35 = mul nuw nsw i64 %v12, 288
  %invariant.gep38 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx35
  %invariant.gep39 = getelementptr inbounds nuw float, ptr addrspace(3) %invariant.gep38, i64 %v10
  %invariant.gep41 = getelementptr inbounds nuw float, ptr addrspace(3) %invariant.gep39, i64 %v1110
  br label %kt

kt:                                               ; preds = %issued, %entry
  %v15.sroa.310.0 = phi float [ 0.000000e+00, %entry ], [ %v893, %issued ]
  %v15.sroa.300.0 = phi float [ 0.000000e+00, %entry ], [ %v892, %issued ]
  %v15.sroa.290.0 = phi float [ 0.000000e+00, %entry ], [ %v891, %issued ]
  %v15.sroa.280.0 = phi float [ 0.000000e+00, %entry ], [ %v890, %issued ]
  %v15.sroa.270.0 = phi float [ 0.000000e+00, %entry ], [ %v880, %issued ]
  %v15.sroa.260.0 = phi float [ 0.000000e+00, %entry ], [ %v879, %issued ]
  %v15.sroa.250.0 = phi float [ 0.000000e+00, %entry ], [ %v878, %issued ]
  %v15.sroa.240.0 = phi float [ 0.000000e+00, %entry ], [ %v877, %issued ]
  %v15.sroa.230.0 = phi float [ 0.000000e+00, %entry ], [ %v867, %issued ]
  %v15.sroa.220.0 = phi float [ 0.000000e+00, %entry ], [ %v866, %issued ]
  %v15.sroa.210.0 = phi float [ 0.000000e+00, %entry ], [ %v865, %issued ]
  %v15.sroa.200.0 = phi float [ 0.000000e+00, %entry ], [ %v864, %issued ]
  %v15.sroa.190.0 = phi float [ 0.000000e+00, %entry ], [ %v854, %issued ]
  %v15.sroa.180.0 = phi float [ 0.000000e+00, %entry ], [ %v853, %issued ]
  %v15.sroa.170.0 = phi float [ 0.000000e+00, %entry ], [ %v852, %issued ]
  %v15.sroa.160.0 = phi float [ 0.000000e+00, %entry ], [ %v851, %issued ]
  %v15.sroa.150.0 = phi float [ 0.000000e+00, %entry ], [ %v841, %issued ]
  %v15.sroa.140.0 = phi float [ 0.000000e+00, %entry ], [ %v840, %issued ]
  %v15.sroa.130.0 = phi float [ 0.000000e+00, %entry ], [ %v839, %issued ]
  %v15.sroa.120.0 = phi float [ 0.000000e+00, %entry ], [ %v838, %issued ]
  %v15.sroa.110.0 = phi float [ 0.000000e+00, %entry ], [ %v828, %issued ]
  %v15.sroa.100.0 = phi float [ 0.000000e+00, %entry ], [ %v827, %issued ]
  %v15.sroa.90.0 = phi float [ 0.000000e+00, %entry ], [ %v826, %issued ]
  %v15.sroa.80.0 = phi float [ 0.000000e+00, %entry ], [ %v825, %issued ]
  %v15.sroa.70.0 = phi float [ 0.000000e+00, %entry ], [ %v815, %issued ]
  %v15.sroa.60.0 = phi float [ 0.000000e+00, %entry ], [ %v814, %issued ]
  %v15.sroa.50.0 = phi float [ 0.000000e+00, %entry ], [ %v813, %issued ]
  %v15.sroa.40.0 = phi float [ 0.000000e+00, %entry ], [ %v812, %issued ]
  %v15.sroa.30.0 = phi float [ 0.000000e+00, %entry ], [ %v802, %issued ]
  %v15.sroa.20.0 = phi float [ 0.000000e+00, %entry ], [ %v801, %issued ]
  %v15.sroa.10.0 = phi float [ 0.000000e+00, %entry ], [ %v800, %issued ]
  %v15.sroa.0.0 = phi float [ 0.000000e+00, %entry ], [ %v799, %issued ]
  %v177 = phi i64 [ 0, %entry ], [ %v179, %issued ]
  tail call void @llvm.nvvm.cp.async.wait.group(i32 0)
  tail call void @llvm.nvvm.barrier.cta.sync.aligned.all(i32 0)
  %v179 = add nuw nsw i64 %v177, 1
  %v180 = icmp samesign ult i64 %v177, 31
  br i1 %v180, label %issue, label %issued

issue:                                            ; preds = %kt
  %v182 = shl nuw nsw i64 %v179, 5
  %v184 = shl nuw nsw i64 %v179, 15
  %22 = trunc i64 %v179 to i1
  %v185 = select i1 %22, i64 4608, i64 0
  %v187 = getelementptr inbounds nuw float, ptr addrspace(1) %v137, i64 %v182
  %v189 = getelementptr inbounds nuw float, ptr addrspace(3) %v139, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v189, ptr addrspace(1) nonnull %v187)
  %v191 = getelementptr inbounds nuw float, ptr addrspace(1) %v141, i64 %v182
  %v193 = getelementptr inbounds nuw float, ptr addrspace(3) %v143, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v193, ptr addrspace(1) nonnull %v191)
  %v195 = getelementptr inbounds nuw float, ptr addrspace(1) %v145, i64 %v182
  %v197 = getelementptr inbounds nuw float, ptr addrspace(3) %v147, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v197, ptr addrspace(1) nonnull %v195)
  %v199 = getelementptr inbounds nuw float, ptr addrspace(1) %v149, i64 %v182
  %v201 = getelementptr inbounds nuw float, ptr addrspace(3) %v151, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v201, ptr addrspace(1) nonnull %v199)
  %v203 = getelementptr inbounds nuw float, ptr addrspace(1) %v153, i64 %v184
  %v205 = getelementptr inbounds nuw float, ptr addrspace(3) %v155, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v205, ptr addrspace(1) nonnull %v203)
  %v207 = getelementptr inbounds nuw float, ptr addrspace(1) %v157, i64 %v184
  %v209 = getelementptr inbounds nuw float, ptr addrspace(3) %v159, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v209, ptr addrspace(1) nonnull %v207)
  %v211 = getelementptr inbounds nuw float, ptr addrspace(1) %v161, i64 %v184
  %v213 = getelementptr inbounds nuw float, ptr addrspace(3) %v163, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v213, ptr addrspace(1) nonnull %v211)
  %v215 = getelementptr inbounds nuw float, ptr addrspace(1) %v165, i64 %v184
  %v217 = getelementptr inbounds nuw float, ptr addrspace(3) %v167, i64 %v185
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v217, ptr addrspace(1) nonnull %v215)
  br label %issued

issued:                                           ; preds = %issue, %kt
  tail call void @llvm.nvvm.cp.async.commit.group()
  %23 = trunc i64 %v177 to i1
  %v219 = select i1 %23, i64 4608, i64 0
  %gep37 = getelementptr inbounds nuw float, ptr addrspace(3) %invariant.gep36, i64 %v219
  %v224 = load float, ptr addrspace(3) %gep37, align 4
  %v225 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v224) #2
  %v227 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 1152
  %v228 = load float, ptr addrspace(3) %v227, align 4
  %v229 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v228) #2
  %v231 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 16
  %v232 = load float, ptr addrspace(3) %v231, align 4
  %v233 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v232) #2
  %v235 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 1168
  %v236 = load float, ptr addrspace(3) %v235, align 4
  %v237 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v236) #2
  %v239 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 2304
  %v240 = load float, ptr addrspace(3) %v239, align 4
  %v241 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v240) #2
  %v243 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 3456
  %v244 = load float, ptr addrspace(3) %v243, align 4
  %v245 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v244) #2
  %v247 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 2320
  %v248 = load float, ptr addrspace(3) %v247, align 4
  %v249 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v248) #2
  %v251 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 3472
  %v252 = load float, ptr addrspace(3) %v251, align 4
  %v253 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v252) #2
  %gep = getelementptr inbounds nuw float, ptr addrspace(3) %invariant.gep41, i64 %v219
  %v255 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 9216
  %v256 = load float, ptr addrspace(3) %v255, align 4
  %v257 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v256) #2
  %v259 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 10368
  %v260 = load float, ptr addrspace(3) %v259, align 4
  %v261 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v260) #2
  %v263 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 9248
  %v264 = load float, ptr addrspace(3) %v263, align 4
  %v265 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v264) #2
  %v267 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 10400
  %v268 = load float, ptr addrspace(3) %v267, align 4
  %v269 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v268) #2
  %v271 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 9280
  %v272 = load float, ptr addrspace(3) %v271, align 4
  %v273 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v272) #2
  %v275 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 10432
  %v276 = load float, ptr addrspace(3) %v275, align 4
  %v277 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v276) #2
  %v279 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 9312
  %v280 = load float, ptr addrspace(3) %v279, align 4
  %v281 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v280) #2
  %v283 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 10464
  %v284 = load float, ptr addrspace(3) %v283, align 4
  %v285 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v284) #2
  %v294 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v225, i32 %v229, i32 %v233, i32 %v237, i32 %v257, i32 %v261, float %v15.sroa.0.0, float %v15.sroa.10.0, float %v15.sroa.20.0, float %v15.sroa.30.0) #2
  %v295 = extractvalue { float, float, float, float } %v294, 0
  %v296 = extractvalue { float, float, float, float } %v294, 1
  %v297 = extractvalue { float, float, float, float } %v294, 2
  %v298 = extractvalue { float, float, float, float } %v294, 3
  %v307 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v225, i32 %v229, i32 %v233, i32 %v237, i32 %v265, i32 %v269, float %v15.sroa.40.0, float %v15.sroa.50.0, float %v15.sroa.60.0, float %v15.sroa.70.0) #2
  %v308 = extractvalue { float, float, float, float } %v307, 0
  %v309 = extractvalue { float, float, float, float } %v307, 1
  %v310 = extractvalue { float, float, float, float } %v307, 2
  %v311 = extractvalue { float, float, float, float } %v307, 3
  %v320 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v225, i32 %v229, i32 %v233, i32 %v237, i32 %v273, i32 %v277, float %v15.sroa.80.0, float %v15.sroa.90.0, float %v15.sroa.100.0, float %v15.sroa.110.0) #2
  %v321 = extractvalue { float, float, float, float } %v320, 0
  %v322 = extractvalue { float, float, float, float } %v320, 1
  %v323 = extractvalue { float, float, float, float } %v320, 2
  %v324 = extractvalue { float, float, float, float } %v320, 3
  %v333 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v225, i32 %v229, i32 %v233, i32 %v237, i32 %v281, i32 %v285, float %v15.sroa.120.0, float %v15.sroa.130.0, float %v15.sroa.140.0, float %v15.sroa.150.0) #2
  %v334 = extractvalue { float, float, float, float } %v333, 0
  %v335 = extractvalue { float, float, float, float } %v333, 1
  %v336 = extractvalue { float, float, float, float } %v333, 2
  %v337 = extractvalue { float, float, float, float } %v333, 3
  %v346 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v241, i32 %v245, i32 %v249, i32 %v253, i32 %v257, i32 %v261, float %v15.sroa.160.0, float %v15.sroa.170.0, float %v15.sroa.180.0, float %v15.sroa.190.0) #2
  %v347 = extractvalue { float, float, float, float } %v346, 0
  %v348 = extractvalue { float, float, float, float } %v346, 1
  %v349 = extractvalue { float, float, float, float } %v346, 2
  %v350 = extractvalue { float, float, float, float } %v346, 3
  %v359 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v241, i32 %v245, i32 %v249, i32 %v253, i32 %v265, i32 %v269, float %v15.sroa.200.0, float %v15.sroa.210.0, float %v15.sroa.220.0, float %v15.sroa.230.0) #2
  %v360 = extractvalue { float, float, float, float } %v359, 0
  %v361 = extractvalue { float, float, float, float } %v359, 1
  %v362 = extractvalue { float, float, float, float } %v359, 2
  %v363 = extractvalue { float, float, float, float } %v359, 3
  %v372 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v241, i32 %v245, i32 %v249, i32 %v253, i32 %v273, i32 %v277, float %v15.sroa.240.0, float %v15.sroa.250.0, float %v15.sroa.260.0, float %v15.sroa.270.0) #2
  %v373 = extractvalue { float, float, float, float } %v372, 0
  %v374 = extractvalue { float, float, float, float } %v372, 1
  %v375 = extractvalue { float, float, float, float } %v372, 2
  %v376 = extractvalue { float, float, float, float } %v372, 3
  %v385 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v241, i32 %v245, i32 %v249, i32 %v253, i32 %v281, i32 %v285, float %v15.sroa.280.0, float %v15.sroa.290.0, float %v15.sroa.300.0, float %v15.sroa.310.0) #2
  %v386 = extractvalue { float, float, float, float } %v385, 0
  %v387 = extractvalue { float, float, float, float } %v385, 1
  %v388 = extractvalue { float, float, float, float } %v385, 2
  %v389 = extractvalue { float, float, float, float } %v385, 3
  %v391 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 32
  %v392 = load float, ptr addrspace(3) %v391, align 4
  %v393 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v392) #2
  %v395 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 1184
  %v396 = load float, ptr addrspace(3) %v395, align 4
  %v397 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v396) #2
  %v399 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 48
  %v400 = load float, ptr addrspace(3) %v399, align 4
  %v401 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v400) #2
  %v403 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 1200
  %v404 = load float, ptr addrspace(3) %v403, align 4
  %v405 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v404) #2
  %v407 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 2336
  %v408 = load float, ptr addrspace(3) %v407, align 4
  %v409 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v408) #2
  %v411 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 3488
  %v412 = load float, ptr addrspace(3) %v411, align 4
  %v413 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v412) #2
  %v415 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 2352
  %v416 = load float, ptr addrspace(3) %v415, align 4
  %v417 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v416) #2
  %v419 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 3504
  %v420 = load float, ptr addrspace(3) %v419, align 4
  %v421 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v420) #2
  %v423 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 11520
  %v424 = load float, ptr addrspace(3) %v423, align 4
  %v425 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v424) #2
  %v427 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 12672
  %v428 = load float, ptr addrspace(3) %v427, align 4
  %v429 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v428) #2
  %v431 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 11552
  %v432 = load float, ptr addrspace(3) %v431, align 4
  %v433 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v432) #2
  %v435 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 12704
  %v436 = load float, ptr addrspace(3) %v435, align 4
  %v437 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v436) #2
  %v439 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 11584
  %v440 = load float, ptr addrspace(3) %v439, align 4
  %v441 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v440) #2
  %v443 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 12736
  %v444 = load float, ptr addrspace(3) %v443, align 4
  %v445 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v444) #2
  %v447 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 11616
  %v448 = load float, ptr addrspace(3) %v447, align 4
  %v449 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v448) #2
  %v451 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 12768
  %v452 = load float, ptr addrspace(3) %v451, align 4
  %v453 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v452) #2
  %v462 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v393, i32 %v397, i32 %v401, i32 %v405, i32 %v425, i32 %v429, float %v295, float %v296, float %v297, float %v298) #2
  %v463 = extractvalue { float, float, float, float } %v462, 0
  %v464 = extractvalue { float, float, float, float } %v462, 1
  %v465 = extractvalue { float, float, float, float } %v462, 2
  %v466 = extractvalue { float, float, float, float } %v462, 3
  %v475 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v393, i32 %v397, i32 %v401, i32 %v405, i32 %v433, i32 %v437, float %v308, float %v309, float %v310, float %v311) #2
  %v476 = extractvalue { float, float, float, float } %v475, 0
  %v477 = extractvalue { float, float, float, float } %v475, 1
  %v478 = extractvalue { float, float, float, float } %v475, 2
  %v479 = extractvalue { float, float, float, float } %v475, 3
  %v488 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v393, i32 %v397, i32 %v401, i32 %v405, i32 %v441, i32 %v445, float %v321, float %v322, float %v323, float %v324) #2
  %v489 = extractvalue { float, float, float, float } %v488, 0
  %v490 = extractvalue { float, float, float, float } %v488, 1
  %v491 = extractvalue { float, float, float, float } %v488, 2
  %v492 = extractvalue { float, float, float, float } %v488, 3
  %v501 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v393, i32 %v397, i32 %v401, i32 %v405, i32 %v449, i32 %v453, float %v334, float %v335, float %v336, float %v337) #2
  %v502 = extractvalue { float, float, float, float } %v501, 0
  %v503 = extractvalue { float, float, float, float } %v501, 1
  %v504 = extractvalue { float, float, float, float } %v501, 2
  %v505 = extractvalue { float, float, float, float } %v501, 3
  %v514 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v409, i32 %v413, i32 %v417, i32 %v421, i32 %v425, i32 %v429, float %v347, float %v348, float %v349, float %v350) #2
  %v515 = extractvalue { float, float, float, float } %v514, 0
  %v516 = extractvalue { float, float, float, float } %v514, 1
  %v517 = extractvalue { float, float, float, float } %v514, 2
  %v518 = extractvalue { float, float, float, float } %v514, 3
  %v527 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v409, i32 %v413, i32 %v417, i32 %v421, i32 %v433, i32 %v437, float %v360, float %v361, float %v362, float %v363) #2
  %v528 = extractvalue { float, float, float, float } %v527, 0
  %v529 = extractvalue { float, float, float, float } %v527, 1
  %v530 = extractvalue { float, float, float, float } %v527, 2
  %v531 = extractvalue { float, float, float, float } %v527, 3
  %v540 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v409, i32 %v413, i32 %v417, i32 %v421, i32 %v441, i32 %v445, float %v373, float %v374, float %v375, float %v376) #2
  %v541 = extractvalue { float, float, float, float } %v540, 0
  %v542 = extractvalue { float, float, float, float } %v540, 1
  %v543 = extractvalue { float, float, float, float } %v540, 2
  %v544 = extractvalue { float, float, float, float } %v540, 3
  %v553 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v409, i32 %v413, i32 %v417, i32 %v421, i32 %v449, i32 %v453, float %v386, float %v387, float %v388, float %v389) #2
  %v554 = extractvalue { float, float, float, float } %v553, 0
  %v555 = extractvalue { float, float, float, float } %v553, 1
  %v556 = extractvalue { float, float, float, float } %v553, 2
  %v557 = extractvalue { float, float, float, float } %v553, 3
  %v559 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 64
  %v560 = load float, ptr addrspace(3) %v559, align 4
  %v561 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v560) #2
  %v563 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 1216
  %v564 = load float, ptr addrspace(3) %v563, align 4
  %v565 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v564) #2
  %v567 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 80
  %v568 = load float, ptr addrspace(3) %v567, align 4
  %v569 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v568) #2
  %v571 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 1232
  %v572 = load float, ptr addrspace(3) %v571, align 4
  %v573 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v572) #2
  %v575 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 2368
  %v576 = load float, ptr addrspace(3) %v575, align 4
  %v577 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v576) #2
  %v579 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 3520
  %v580 = load float, ptr addrspace(3) %v579, align 4
  %v581 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v580) #2
  %v583 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 2384
  %v584 = load float, ptr addrspace(3) %v583, align 4
  %v585 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v584) #2
  %v587 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 3536
  %v588 = load float, ptr addrspace(3) %v587, align 4
  %v589 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v588) #2
  %v591 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 13824
  %v592 = load float, ptr addrspace(3) %v591, align 4
  %v593 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v592) #2
  %v595 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 14976
  %v596 = load float, ptr addrspace(3) %v595, align 4
  %v597 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v596) #2
  %v599 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 13856
  %v600 = load float, ptr addrspace(3) %v599, align 4
  %v601 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v600) #2
  %v603 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 15008
  %v604 = load float, ptr addrspace(3) %v603, align 4
  %v605 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v604) #2
  %v607 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 13888
  %v608 = load float, ptr addrspace(3) %v607, align 4
  %v609 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v608) #2
  %v611 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 15040
  %v612 = load float, ptr addrspace(3) %v611, align 4
  %v613 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v612) #2
  %v615 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 13920
  %v616 = load float, ptr addrspace(3) %v615, align 4
  %v617 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v616) #2
  %v619 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 15072
  %v620 = load float, ptr addrspace(3) %v619, align 4
  %v621 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v620) #2
  %v630 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v561, i32 %v565, i32 %v569, i32 %v573, i32 %v593, i32 %v597, float %v463, float %v464, float %v465, float %v466) #2
  %v631 = extractvalue { float, float, float, float } %v630, 0
  %v632 = extractvalue { float, float, float, float } %v630, 1
  %v633 = extractvalue { float, float, float, float } %v630, 2
  %v634 = extractvalue { float, float, float, float } %v630, 3
  %v643 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v561, i32 %v565, i32 %v569, i32 %v573, i32 %v601, i32 %v605, float %v476, float %v477, float %v478, float %v479) #2
  %v644 = extractvalue { float, float, float, float } %v643, 0
  %v645 = extractvalue { float, float, float, float } %v643, 1
  %v646 = extractvalue { float, float, float, float } %v643, 2
  %v647 = extractvalue { float, float, float, float } %v643, 3
  %v656 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v561, i32 %v565, i32 %v569, i32 %v573, i32 %v609, i32 %v613, float %v489, float %v490, float %v491, float %v492) #2
  %v657 = extractvalue { float, float, float, float } %v656, 0
  %v658 = extractvalue { float, float, float, float } %v656, 1
  %v659 = extractvalue { float, float, float, float } %v656, 2
  %v660 = extractvalue { float, float, float, float } %v656, 3
  %v669 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v561, i32 %v565, i32 %v569, i32 %v573, i32 %v617, i32 %v621, float %v502, float %v503, float %v504, float %v505) #2
  %v670 = extractvalue { float, float, float, float } %v669, 0
  %v671 = extractvalue { float, float, float, float } %v669, 1
  %v672 = extractvalue { float, float, float, float } %v669, 2
  %v673 = extractvalue { float, float, float, float } %v669, 3
  %v682 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v577, i32 %v581, i32 %v585, i32 %v589, i32 %v593, i32 %v597, float %v515, float %v516, float %v517, float %v518) #2
  %v683 = extractvalue { float, float, float, float } %v682, 0
  %v684 = extractvalue { float, float, float, float } %v682, 1
  %v685 = extractvalue { float, float, float, float } %v682, 2
  %v686 = extractvalue { float, float, float, float } %v682, 3
  %v695 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v577, i32 %v581, i32 %v585, i32 %v589, i32 %v601, i32 %v605, float %v528, float %v529, float %v530, float %v531) #2
  %v696 = extractvalue { float, float, float, float } %v695, 0
  %v697 = extractvalue { float, float, float, float } %v695, 1
  %v698 = extractvalue { float, float, float, float } %v695, 2
  %v699 = extractvalue { float, float, float, float } %v695, 3
  %v708 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v577, i32 %v581, i32 %v585, i32 %v589, i32 %v609, i32 %v613, float %v541, float %v542, float %v543, float %v544) #2
  %v709 = extractvalue { float, float, float, float } %v708, 0
  %v710 = extractvalue { float, float, float, float } %v708, 1
  %v711 = extractvalue { float, float, float, float } %v708, 2
  %v712 = extractvalue { float, float, float, float } %v708, 3
  %v721 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v577, i32 %v581, i32 %v585, i32 %v589, i32 %v617, i32 %v621, float %v554, float %v555, float %v556, float %v557) #2
  %v722 = extractvalue { float, float, float, float } %v721, 0
  %v723 = extractvalue { float, float, float, float } %v721, 1
  %v724 = extractvalue { float, float, float, float } %v721, 2
  %v725 = extractvalue { float, float, float, float } %v721, 3
  %v727 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 96
  %v728 = load float, ptr addrspace(3) %v727, align 4
  %v729 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v728) #2
  %v731 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 1248
  %v732 = load float, ptr addrspace(3) %v731, align 4
  %v733 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v732) #2
  %v735 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 112
  %v736 = load float, ptr addrspace(3) %v735, align 4
  %v737 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v736) #2
  %v739 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 1264
  %v740 = load float, ptr addrspace(3) %v739, align 4
  %v741 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v740) #2
  %v743 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 2400
  %v744 = load float, ptr addrspace(3) %v743, align 4
  %v745 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v744) #2
  %v747 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 3552
  %v748 = load float, ptr addrspace(3) %v747, align 4
  %v749 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v748) #2
  %v751 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 2416
  %v752 = load float, ptr addrspace(3) %v751, align 4
  %v753 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v752) #2
  %v755 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep37, i64 3568
  %v756 = load float, ptr addrspace(3) %v755, align 4
  %v757 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v756) #2
  %v759 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 16128
  %v760 = load float, ptr addrspace(3) %v759, align 4
  %v761 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v760) #2
  %v763 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 17280
  %v764 = load float, ptr addrspace(3) %v763, align 4
  %v765 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v764) #2
  %v767 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 16160
  %v768 = load float, ptr addrspace(3) %v767, align 4
  %v769 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v768) #2
  %v771 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 17312
  %v772 = load float, ptr addrspace(3) %v771, align 4
  %v773 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v772) #2
  %v775 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 16192
  %v776 = load float, ptr addrspace(3) %v775, align 4
  %v777 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v776) #2
  %v779 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 17344
  %v780 = load float, ptr addrspace(3) %v779, align 4
  %v781 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v780) #2
  %v783 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 16224
  %v784 = load float, ptr addrspace(3) %v783, align 4
  %v785 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v784) #2
  %v787 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep, i64 17376
  %v788 = load float, ptr addrspace(3) %v787, align 4
  %v789 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v788) #2
  %v798 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v729, i32 %v733, i32 %v737, i32 %v741, i32 %v761, i32 %v765, float %v631, float %v632, float %v633, float %v634) #2
  %v799 = extractvalue { float, float, float, float } %v798, 0
  %v800 = extractvalue { float, float, float, float } %v798, 1
  %v801 = extractvalue { float, float, float, float } %v798, 2
  %v802 = extractvalue { float, float, float, float } %v798, 3
  %v811 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v729, i32 %v733, i32 %v737, i32 %v741, i32 %v769, i32 %v773, float %v644, float %v645, float %v646, float %v647) #2
  %v812 = extractvalue { float, float, float, float } %v811, 0
  %v813 = extractvalue { float, float, float, float } %v811, 1
  %v814 = extractvalue { float, float, float, float } %v811, 2
  %v815 = extractvalue { float, float, float, float } %v811, 3
  %v824 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v729, i32 %v733, i32 %v737, i32 %v741, i32 %v777, i32 %v781, float %v657, float %v658, float %v659, float %v660) #2
  %v825 = extractvalue { float, float, float, float } %v824, 0
  %v826 = extractvalue { float, float, float, float } %v824, 1
  %v827 = extractvalue { float, float, float, float } %v824, 2
  %v828 = extractvalue { float, float, float, float } %v824, 3
  %v837 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v729, i32 %v733, i32 %v737, i32 %v741, i32 %v785, i32 %v789, float %v670, float %v671, float %v672, float %v673) #2
  %v838 = extractvalue { float, float, float, float } %v837, 0
  %v839 = extractvalue { float, float, float, float } %v837, 1
  %v840 = extractvalue { float, float, float, float } %v837, 2
  %v841 = extractvalue { float, float, float, float } %v837, 3
  %v850 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v745, i32 %v749, i32 %v753, i32 %v757, i32 %v761, i32 %v765, float %v683, float %v684, float %v685, float %v686) #2
  %v851 = extractvalue { float, float, float, float } %v850, 0
  %v852 = extractvalue { float, float, float, float } %v850, 1
  %v853 = extractvalue { float, float, float, float } %v850, 2
  %v854 = extractvalue { float, float, float, float } %v850, 3
  %v863 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v745, i32 %v749, i32 %v753, i32 %v757, i32 %v769, i32 %v773, float %v696, float %v697, float %v698, float %v699) #2
  %v864 = extractvalue { float, float, float, float } %v863, 0
  %v865 = extractvalue { float, float, float, float } %v863, 1
  %v866 = extractvalue { float, float, float, float } %v863, 2
  %v867 = extractvalue { float, float, float, float } %v863, 3
  %v876 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v745, i32 %v749, i32 %v753, i32 %v757, i32 %v777, i32 %v781, float %v709, float %v710, float %v711, float %v712) #2
  %v877 = extractvalue { float, float, float, float } %v876, 0
  %v878 = extractvalue { float, float, float, float } %v876, 1
  %v879 = extractvalue { float, float, float, float } %v876, 2
  %v880 = extractvalue { float, float, float, float } %v876, 3
  %v889 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v745, i32 %v749, i32 %v753, i32 %v757, i32 %v785, i32 %v789, float %v722, float %v723, float %v724, float %v725) #2
  %v890 = extractvalue { float, float, float, float } %v889, 0
  %v891 = extractvalue { float, float, float, float } %v889, 1
  %v892 = extractvalue { float, float, float, float } %v889, 2
  %v893 = extractvalue { float, float, float, float } %v889, 3
  %v894 = icmp eq i64 %v179, 32
  br i1 %v894, label %done, label %kt

done:                                             ; preds = %issued
  %v897 = or disjoint i64 %v169, %v13
  %v900 = shl nuw nsw i64 %v12, 1
  %24 = or disjoint i64 %v900, %v14
  %v901 = or disjoint i64 %24, %v10
  %v907 = insertelement <2 x float> poison, float %v799, i64 0
  %v910 = insertelement <2 x float> %v907, float %v800, i64 1
  %.idx42 = shl nuw nsw i64 %v897, 12
  %25 = getelementptr inbounds nuw i8, ptr addrspace(1) %o, i64 %.idx42
  %v912 = getelementptr inbounds nuw float, ptr addrspace(1) %25, i64 %v901
  store <2 x float> %v910, ptr addrspace(1) %v912, align 8
  %v915 = insertelement <2 x float> poison, float %v812, i64 0
  %v918 = insertelement <2 x float> %v915, float %v813, i64 1
  %v920 = getelementptr inbounds nuw i8, ptr addrspace(1) %v912, i64 32
  store <2 x float> %v918, ptr addrspace(1) %v920, align 8
  %v923 = insertelement <2 x float> poison, float %v825, i64 0
  %v926 = insertelement <2 x float> %v923, float %v826, i64 1
  %v928 = getelementptr inbounds nuw i8, ptr addrspace(1) %v912, i64 64
  store <2 x float> %v926, ptr addrspace(1) %v928, align 8
  %v931 = insertelement <2 x float> poison, float %v838, i64 0
  %v934 = insertelement <2 x float> %v931, float %v839, i64 1
  %v936 = getelementptr inbounds nuw i8, ptr addrspace(1) %v912, i64 96
  store <2 x float> %v934, ptr addrspace(1) %v936, align 8
  %v942 = insertelement <2 x float> poison, float %v801, i64 0
  %v945 = insertelement <2 x float> %v942, float %v802, i64 1
  %26 = getelementptr inbounds nuw i8, ptr addrspace(1) %25, i64 32768
  %v947 = getelementptr inbounds nuw float, ptr addrspace(1) %26, i64 %v901
  store <2 x float> %v945, ptr addrspace(1) %v947, align 8
  %v950 = insertelement <2 x float> poison, float %v814, i64 0
  %v953 = insertelement <2 x float> %v950, float %v815, i64 1
  %v955 = getelementptr inbounds nuw i8, ptr addrspace(1) %v947, i64 32
  store <2 x float> %v953, ptr addrspace(1) %v955, align 8
  %v958 = insertelement <2 x float> poison, float %v827, i64 0
  %v961 = insertelement <2 x float> %v958, float %v828, i64 1
  %v963 = getelementptr inbounds nuw i8, ptr addrspace(1) %v947, i64 64
  store <2 x float> %v961, ptr addrspace(1) %v963, align 8
  %v966 = insertelement <2 x float> poison, float %v840, i64 0
  %v969 = insertelement <2 x float> %v966, float %v841, i64 1
  %v971 = getelementptr inbounds nuw i8, ptr addrspace(1) %v947, i64 96
  store <2 x float> %v969, ptr addrspace(1) %v971, align 8
  %v977 = insertelement <2 x float> poison, float %v851, i64 0
  %v980 = insertelement <2 x float> %v977, float %v852, i64 1
  %27 = getelementptr inbounds nuw i8, ptr addrspace(1) %25, i64 65536
  %v982 = getelementptr inbounds nuw float, ptr addrspace(1) %27, i64 %v901
  store <2 x float> %v980, ptr addrspace(1) %v982, align 8
  %v985 = insertelement <2 x float> poison, float %v864, i64 0
  %v988 = insertelement <2 x float> %v985, float %v865, i64 1
  %v990 = getelementptr inbounds nuw i8, ptr addrspace(1) %v982, i64 32
  store <2 x float> %v988, ptr addrspace(1) %v990, align 8
  %v993 = insertelement <2 x float> poison, float %v877, i64 0
  %v996 = insertelement <2 x float> %v993, float %v878, i64 1
  %v998 = getelementptr inbounds nuw i8, ptr addrspace(1) %v982, i64 64
  store <2 x float> %v996, ptr addrspace(1) %v998, align 8
  %v1001 = insertelement <2 x float> poison, float %v890, i64 0
  %v1004 = insertelement <2 x float> %v1001, float %v891, i64 1
  %v1006 = getelementptr inbounds nuw i8, ptr addrspace(1) %v982, i64 96
  store <2 x float> %v1004, ptr addrspace(1) %v1006, align 8
  %v1012 = insertelement <2 x float> poison, float %v853, i64 0
  %v1015 = insertelement <2 x float> %v1012, float %v854, i64 1
  %28 = getelementptr inbounds nuw i8, ptr addrspace(1) %25, i64 98304
  %v1017 = getelementptr inbounds nuw float, ptr addrspace(1) %28, i64 %v901
  store <2 x float> %v1015, ptr addrspace(1) %v1017, align 8
  %v1020 = insertelement <2 x float> poison, float %v866, i64 0
  %v1023 = insertelement <2 x float> %v1020, float %v867, i64 1
  %v1025 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1017, i64 32
  store <2 x float> %v1023, ptr addrspace(1) %v1025, align 8
  %v1028 = insertelement <2 x float> poison, float %v879, i64 0
  %v1031 = insertelement <2 x float> %v1028, float %v880, i64 1
  %v1033 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1017, i64 64
  store <2 x float> %v1031, ptr addrspace(1) %v1033, align 8
  %v1036 = insertelement <2 x float> poison, float %v892, i64 0
  %v1039 = insertelement <2 x float> %v1036, float %v893, i64 1
  %v1041 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1017, i64 96
  store <2 x float> %v1039, ptr addrspace(1) %v1041, align 8
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_7a2ade86c804ef09(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #4 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %p = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %i
  %x = trunc i64 %i to i32
  %t7.i = mul i32 %x, 7
  %t15.i = add i32 %t7.i, 13
  %t23.i = srem i32 %t15.i, 101
  %t31.i = add nsw i32 %t23.i, -50
  %t33.i = sitofp i32 %t31.i to float
  store float %t33.i, ptr addrspace(1) %p, align 4
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_1aeae5b5ba14d87e(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #4 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %p = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %i
  %x = trunc i64 %i to i32
  %t7.i = mul i32 %x, 7
  %t15.i = add i32 %t7.i, 57
  %t23.i = srem i32 %t15.i, 101
  %t31.i = add nsw i32 %t23.i, -50
  %t33.i = sitofp i32 %t31.i to float
  store float %t33.i, ptr addrspace(1) %p, align 4
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.barrier.cta.sync.aligned.all(i32) #5

attributes #0 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nounwind memory(argmem: readwrite) }
attributes #2 = { nounwind }
attributes #3 = { nounwind "nvvm.maxntid"="128" "nvvm.minctasm"="2" }
attributes #4 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) "nvvm.maxntid"="256" }
attributes #5 = { convergent nocallback nounwind }
