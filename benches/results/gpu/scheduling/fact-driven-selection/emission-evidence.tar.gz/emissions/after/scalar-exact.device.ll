; mapal-backend-llvm device module
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@mapal_smem = external addrspace(3) global [0 x i8], align 16
declare i32 @llvm.nvvm.read.ptx.sreg.tid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
declare void @llvm.nvvm.barrier0()
declare void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.8(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.commit.group()
declare void @llvm.nvvm.cp.async.wait.group(i32 immarg)
declare float @llvm.fma.f32(float, float, float)
declare double @llvm.fma.f64(double, double, double)

define ptx_kernel void @mapal_tile_ab59f5e5845b59bb(ptr addrspace(1) noalias readonly align 16 %a, ptr addrspace(1) noalias readonly align 16 %b, ptr addrspace(1) noalias align 16 %o) "nvvm.maxntid"="256" "nvvm.minctasm"="2" {
entry:
  %v1 = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v3 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v4 = udiv i32 %v1, 32
  %v5 = urem i32 %v1, 32
  %v6 = udiv i32 %v4, 2
  %v7 = urem i32 %v4, 2
  %v8 = udiv i32 %v5, 8
  %v9 = urem i32 %v5, 8
  %v10 = mul nuw nsw i32 %v6, 4
  %v11 = mul nuw nsw i32 %v7, 8
  %v12 = add nuw nsw i32 %v10, %v8
  %v13 = add nuw nsw i32 %v11, %v9
  %v14 = mul nuw nsw i32 %v3, 128
  %v15 = mul nuw nsw i32 %v2, 64
  %v16 = alloca [32 x float], align 16
  %v17 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 0
  store float 0x0000000000000000, ptr %v17, align 4
  %v18 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 1
  store float 0x0000000000000000, ptr %v18, align 4
  %v19 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 2
  store float 0x0000000000000000, ptr %v19, align 4
  %v20 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 3
  store float 0x0000000000000000, ptr %v20, align 4
  %v21 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 4
  store float 0x0000000000000000, ptr %v21, align 4
  %v22 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 5
  store float 0x0000000000000000, ptr %v22, align 4
  %v23 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 6
  store float 0x0000000000000000, ptr %v23, align 4
  %v24 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 7
  store float 0x0000000000000000, ptr %v24, align 4
  %v25 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 8
  store float 0x0000000000000000, ptr %v25, align 4
  %v26 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 9
  store float 0x0000000000000000, ptr %v26, align 4
  %v27 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 10
  store float 0x0000000000000000, ptr %v27, align 4
  %v28 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 11
  store float 0x0000000000000000, ptr %v28, align 4
  %v29 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 12
  store float 0x0000000000000000, ptr %v29, align 4
  %v30 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 13
  store float 0x0000000000000000, ptr %v30, align 4
  %v31 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 14
  store float 0x0000000000000000, ptr %v31, align 4
  %v32 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 15
  store float 0x0000000000000000, ptr %v32, align 4
  %v33 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 16
  store float 0x0000000000000000, ptr %v33, align 4
  %v34 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 17
  store float 0x0000000000000000, ptr %v34, align 4
  %v35 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 18
  store float 0x0000000000000000, ptr %v35, align 4
  %v36 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 19
  store float 0x0000000000000000, ptr %v36, align 4
  %v37 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 20
  store float 0x0000000000000000, ptr %v37, align 4
  %v38 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 21
  store float 0x0000000000000000, ptr %v38, align 4
  %v39 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 22
  store float 0x0000000000000000, ptr %v39, align 4
  %v40 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 23
  store float 0x0000000000000000, ptr %v40, align 4
  %v41 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 24
  store float 0x0000000000000000, ptr %v41, align 4
  %v42 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 25
  store float 0x0000000000000000, ptr %v42, align 4
  %v43 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 26
  store float 0x0000000000000000, ptr %v43, align 4
  %v44 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 27
  store float 0x0000000000000000, ptr %v44, align 4
  %v45 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 28
  store float 0x0000000000000000, ptr %v45, align 4
  %v46 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 29
  store float 0x0000000000000000, ptr %v46, align 4
  %v47 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 30
  store float 0x0000000000000000, ptr %v47, align 4
  %v48 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 31
  store float 0x0000000000000000, ptr %v48, align 4
  %v49 = urem i32 %v1, 4
  %v50 = udiv i32 %v1, 4
  %v51 = urem i32 %v50, 128
  %v52 = udiv i32 %v50, 128
  %v53 = mul nuw nsw i32 %v52, 4
  %v54 = add nuw nsw i32 %v53, %v49
  %v55 = add nuw nsw i32 %v14, %v51
  %v56 = mul nuw nsw i32 %v55, 1024
  %v57 = mul nuw nsw i32 %v54, 1
  %v58 = add nuw nsw i32 %v56, %v57
  %v59 = add nuw nsw i32 %v58, 0
  %v60 = mul nuw nsw i32 %v54, 136
  %v61 = add nuw nsw i32 %v60, %v51
  %v62 = udiv i32 %v1, 16
  %v63 = urem i32 %v1, 16
  %v64 = mul nuw nsw i32 %v63, 4
  %v65 = mul nuw nsw i32 %v62, 1024
  %v66 = add nuw nsw i32 %v15, %v64
  %v67 = mul nuw nsw i32 %v66, 1
  %v68 = add nuw nsw i32 %v65, %v67
  %v69 = add nuw nsw i32 %v68, 0
  %v70 = mul nuw nsw i32 %v62, 64
  %v71 = add nuw nsw i32 %v70, %v64
  %v72 = add nuw nsw i32 %v71, 2176
  %v73 = mul nuw nsw i32 %v12, 4
  %v74 = mul nuw nsw i32 %v13, 4
  %v75 = mul nuw nsw i32 0, 16
  %v76 = mul nuw nsw i32 %v75, 1
  %v77 = mul nuw nsw i32 %v75, 1024
  %v78 = mul nuw nsw i32 0, 3200
  %v79 = add nuw nsw i32 %v59, %v76
  %v80 = zext nneg i32 %v79 to i64
  %v81 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v80
  %v82 = add nuw nsw i32 %v61, %v78
  %v83 = zext nneg i32 %v82 to i64
  %v84 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v83
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v84, ptr addrspace(1) %v81)
  %v85 = add nuw nsw i32 %v59, %v76
  %v86 = add nuw nsw i32 %v85, 65536
  %v87 = zext nneg i32 %v86 to i64
  %v88 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v87
  %v89 = add nuw nsw i32 %v61, %v78
  %v90 = add nuw nsw i32 %v89, 64
  %v91 = zext nneg i32 %v90 to i64
  %v92 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v91
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v92, ptr addrspace(1) %v88)
  %v93 = add nuw nsw i32 %v59, %v76
  %v94 = add nuw nsw i32 %v93, 4
  %v95 = zext nneg i32 %v94 to i64
  %v96 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v95
  %v97 = add nuw nsw i32 %v61, %v78
  %v98 = add nuw nsw i32 %v97, 544
  %v99 = zext nneg i32 %v98 to i64
  %v100 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v99
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v100, ptr addrspace(1) %v96)
  %v101 = add nuw nsw i32 %v59, %v76
  %v102 = add nuw nsw i32 %v101, 65540
  %v103 = zext nneg i32 %v102 to i64
  %v104 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v103
  %v105 = add nuw nsw i32 %v61, %v78
  %v106 = add nuw nsw i32 %v105, 608
  %v107 = zext nneg i32 %v106 to i64
  %v108 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v107
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v108, ptr addrspace(1) %v104)
  %v109 = add nuw nsw i32 %v59, %v76
  %v110 = add nuw nsw i32 %v109, 8
  %v111 = zext nneg i32 %v110 to i64
  %v112 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v111
  %v113 = add nuw nsw i32 %v61, %v78
  %v114 = add nuw nsw i32 %v113, 1088
  %v115 = zext nneg i32 %v114 to i64
  %v116 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v115
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v116, ptr addrspace(1) %v112)
  %v117 = add nuw nsw i32 %v59, %v76
  %v118 = add nuw nsw i32 %v117, 65544
  %v119 = zext nneg i32 %v118 to i64
  %v120 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v119
  %v121 = add nuw nsw i32 %v61, %v78
  %v122 = add nuw nsw i32 %v121, 1152
  %v123 = zext nneg i32 %v122 to i64
  %v124 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v123
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v124, ptr addrspace(1) %v120)
  %v125 = add nuw nsw i32 %v59, %v76
  %v126 = add nuw nsw i32 %v125, 12
  %v127 = zext nneg i32 %v126 to i64
  %v128 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v127
  %v129 = add nuw nsw i32 %v61, %v78
  %v130 = add nuw nsw i32 %v129, 1632
  %v131 = zext nneg i32 %v130 to i64
  %v132 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v131
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v132, ptr addrspace(1) %v128)
  %v133 = add nuw nsw i32 %v59, %v76
  %v134 = add nuw nsw i32 %v133, 65548
  %v135 = zext nneg i32 %v134 to i64
  %v136 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v135
  %v137 = add nuw nsw i32 %v61, %v78
  %v138 = add nuw nsw i32 %v137, 1696
  %v139 = zext nneg i32 %v138 to i64
  %v140 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v139
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v140, ptr addrspace(1) %v136)
  %v141 = add nuw nsw i32 %v69, %v77
  %v142 = zext nneg i32 %v141 to i64
  %v143 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v142
  %v144 = add nuw nsw i32 %v72, %v78
  %v145 = zext nneg i32 %v144 to i64
  %v146 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v145
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v146, ptr addrspace(1) %v143)
  call void @llvm.nvvm.cp.async.commit.group()
  %v147 = mul nuw nsw i32 1, 16
  %v148 = mul nuw nsw i32 %v147, 1
  %v149 = mul nuw nsw i32 %v147, 1024
  %v150 = mul nuw nsw i32 1, 3200
  %v151 = add nuw nsw i32 %v59, %v148
  %v152 = zext nneg i32 %v151 to i64
  %v153 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v152
  %v154 = add nuw nsw i32 %v61, %v150
  %v155 = zext nneg i32 %v154 to i64
  %v156 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v155
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v156, ptr addrspace(1) %v153)
  %v157 = add nuw nsw i32 %v59, %v148
  %v158 = add nuw nsw i32 %v157, 65536
  %v159 = zext nneg i32 %v158 to i64
  %v160 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v159
  %v161 = add nuw nsw i32 %v61, %v150
  %v162 = add nuw nsw i32 %v161, 64
  %v163 = zext nneg i32 %v162 to i64
  %v164 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v163
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v164, ptr addrspace(1) %v160)
  %v165 = add nuw nsw i32 %v59, %v148
  %v166 = add nuw nsw i32 %v165, 4
  %v167 = zext nneg i32 %v166 to i64
  %v168 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v167
  %v169 = add nuw nsw i32 %v61, %v150
  %v170 = add nuw nsw i32 %v169, 544
  %v171 = zext nneg i32 %v170 to i64
  %v172 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v171
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v172, ptr addrspace(1) %v168)
  %v173 = add nuw nsw i32 %v59, %v148
  %v174 = add nuw nsw i32 %v173, 65540
  %v175 = zext nneg i32 %v174 to i64
  %v176 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v175
  %v177 = add nuw nsw i32 %v61, %v150
  %v178 = add nuw nsw i32 %v177, 608
  %v179 = zext nneg i32 %v178 to i64
  %v180 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v179
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v180, ptr addrspace(1) %v176)
  %v181 = add nuw nsw i32 %v59, %v148
  %v182 = add nuw nsw i32 %v181, 8
  %v183 = zext nneg i32 %v182 to i64
  %v184 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v183
  %v185 = add nuw nsw i32 %v61, %v150
  %v186 = add nuw nsw i32 %v185, 1088
  %v187 = zext nneg i32 %v186 to i64
  %v188 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v187
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v188, ptr addrspace(1) %v184)
  %v189 = add nuw nsw i32 %v59, %v148
  %v190 = add nuw nsw i32 %v189, 65544
  %v191 = zext nneg i32 %v190 to i64
  %v192 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v191
  %v193 = add nuw nsw i32 %v61, %v150
  %v194 = add nuw nsw i32 %v193, 1152
  %v195 = zext nneg i32 %v194 to i64
  %v196 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v195
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v196, ptr addrspace(1) %v192)
  %v197 = add nuw nsw i32 %v59, %v148
  %v198 = add nuw nsw i32 %v197, 12
  %v199 = zext nneg i32 %v198 to i64
  %v200 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v199
  %v201 = add nuw nsw i32 %v61, %v150
  %v202 = add nuw nsw i32 %v201, 1632
  %v203 = zext nneg i32 %v202 to i64
  %v204 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v203
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v204, ptr addrspace(1) %v200)
  %v205 = add nuw nsw i32 %v59, %v148
  %v206 = add nuw nsw i32 %v205, 65548
  %v207 = zext nneg i32 %v206 to i64
  %v208 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v207
  %v209 = add nuw nsw i32 %v61, %v150
  %v210 = add nuw nsw i32 %v209, 1696
  %v211 = zext nneg i32 %v210 to i64
  %v212 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v211
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v212, ptr addrspace(1) %v208)
  %v213 = add nuw nsw i32 %v69, %v149
  %v214 = zext nneg i32 %v213 to i64
  %v215 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v214
  %v216 = add nuw nsw i32 %v72, %v150
  %v217 = zext nneg i32 %v216 to i64
  %v218 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v217
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v218, ptr addrspace(1) %v215)
  call void @llvm.nvvm.cp.async.commit.group()
  br label %kt
kt:
  %v219 = phi i32 [0, %entry], [%v220, %ktl]
  call void @llvm.nvvm.cp.async.wait.group(i32 1)
  call void @llvm.nvvm.barrier0()
  %v221 = add nuw nsw i32 %v219, 2
  %v222 = icmp ult i32 %v221, 64
  br i1 %v222, label %issue, label %issued
issue:
  %v223 = urem i32 %v221, 3
  %v224 = mul nuw nsw i32 %v221, 16
  %v225 = mul nuw nsw i32 %v224, 1
  %v226 = mul nuw nsw i32 %v224, 1024
  %v227 = mul nuw nsw i32 %v223, 3200
  %v228 = add nuw nsw i32 %v59, %v225
  %v229 = zext nneg i32 %v228 to i64
  %v230 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v229
  %v231 = add nuw nsw i32 %v61, %v227
  %v232 = zext nneg i32 %v231 to i64
  %v233 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v232
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v233, ptr addrspace(1) %v230)
  %v234 = add nuw nsw i32 %v59, %v225
  %v235 = add nuw nsw i32 %v234, 65536
  %v236 = zext nneg i32 %v235 to i64
  %v237 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v236
  %v238 = add nuw nsw i32 %v61, %v227
  %v239 = add nuw nsw i32 %v238, 64
  %v240 = zext nneg i32 %v239 to i64
  %v241 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v240
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v241, ptr addrspace(1) %v237)
  %v242 = add nuw nsw i32 %v59, %v225
  %v243 = add nuw nsw i32 %v242, 4
  %v244 = zext nneg i32 %v243 to i64
  %v245 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v244
  %v246 = add nuw nsw i32 %v61, %v227
  %v247 = add nuw nsw i32 %v246, 544
  %v248 = zext nneg i32 %v247 to i64
  %v249 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v248
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v249, ptr addrspace(1) %v245)
  %v250 = add nuw nsw i32 %v59, %v225
  %v251 = add nuw nsw i32 %v250, 65540
  %v252 = zext nneg i32 %v251 to i64
  %v253 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v252
  %v254 = add nuw nsw i32 %v61, %v227
  %v255 = add nuw nsw i32 %v254, 608
  %v256 = zext nneg i32 %v255 to i64
  %v257 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v256
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v257, ptr addrspace(1) %v253)
  %v258 = add nuw nsw i32 %v59, %v225
  %v259 = add nuw nsw i32 %v258, 8
  %v260 = zext nneg i32 %v259 to i64
  %v261 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v260
  %v262 = add nuw nsw i32 %v61, %v227
  %v263 = add nuw nsw i32 %v262, 1088
  %v264 = zext nneg i32 %v263 to i64
  %v265 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v264
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v265, ptr addrspace(1) %v261)
  %v266 = add nuw nsw i32 %v59, %v225
  %v267 = add nuw nsw i32 %v266, 65544
  %v268 = zext nneg i32 %v267 to i64
  %v269 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v268
  %v270 = add nuw nsw i32 %v61, %v227
  %v271 = add nuw nsw i32 %v270, 1152
  %v272 = zext nneg i32 %v271 to i64
  %v273 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v272
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v273, ptr addrspace(1) %v269)
  %v274 = add nuw nsw i32 %v59, %v225
  %v275 = add nuw nsw i32 %v274, 12
  %v276 = zext nneg i32 %v275 to i64
  %v277 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v276
  %v278 = add nuw nsw i32 %v61, %v227
  %v279 = add nuw nsw i32 %v278, 1632
  %v280 = zext nneg i32 %v279 to i64
  %v281 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v280
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v281, ptr addrspace(1) %v277)
  %v282 = add nuw nsw i32 %v59, %v225
  %v283 = add nuw nsw i32 %v282, 65548
  %v284 = zext nneg i32 %v283 to i64
  %v285 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v284
  %v286 = add nuw nsw i32 %v61, %v227
  %v287 = add nuw nsw i32 %v286, 1696
  %v288 = zext nneg i32 %v287 to i64
  %v289 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v288
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v289, ptr addrspace(1) %v285)
  %v290 = add nuw nsw i32 %v69, %v226
  %v291 = zext nneg i32 %v290 to i64
  %v292 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v291
  %v293 = add nuw nsw i32 %v72, %v227
  %v294 = zext nneg i32 %v293 to i64
  %v295 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v294
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v295, ptr addrspace(1) %v292)
  br label %issued
issued:
  call void @llvm.nvvm.cp.async.commit.group()
  %v296 = urem i32 %v219, 3
  %v297 = mul nuw nsw i32 %v296, 3200
  br label %kk
kk:
  %v298 = phi i32 [0, %issued], [%v299, %kk]
  %v300 = mul nuw nsw i32 %v298, 136
  %v301 = add nuw nsw i32 %v300, %v73
  %v302 = add nuw nsw i32 %v301, 0
  %v303 = add nuw nsw i32 %v302, %v297
  %v304 = add nuw nsw i32 %v303, 0
  %v305 = zext nneg i32 %v304 to i64
  %v306 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v305
  %v307 = load <4 x float>, ptr addrspace(3) %v306, align 16
  %v308 = extractelement <4 x float> %v307, i64 0
  %v309 = extractelement <4 x float> %v307, i64 1
  %v310 = extractelement <4 x float> %v307, i64 2
  %v311 = extractelement <4 x float> %v307, i64 3
  %v312 = add nuw nsw i32 %v303, 64
  %v313 = zext nneg i32 %v312 to i64
  %v314 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v313
  %v315 = load <4 x float>, ptr addrspace(3) %v314, align 16
  %v316 = extractelement <4 x float> %v315, i64 0
  %v317 = extractelement <4 x float> %v315, i64 1
  %v318 = extractelement <4 x float> %v315, i64 2
  %v319 = extractelement <4 x float> %v315, i64 3
  %v320 = mul nuw nsw i32 %v298, 64
  %v321 = add nuw nsw i32 %v320, %v74
  %v322 = add nuw nsw i32 %v321, 2176
  %v323 = add nuw nsw i32 %v322, %v297
  %v324 = add nuw nsw i32 %v323, 0
  %v325 = zext nneg i32 %v324 to i64
  %v326 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v325
  %v327 = load <4 x float>, ptr addrspace(3) %v326, align 16
  %v328 = extractelement <4 x float> %v327, i64 0
  %v329 = extractelement <4 x float> %v327, i64 1
  %v330 = extractelement <4 x float> %v327, i64 2
  %v331 = extractelement <4 x float> %v327, i64 3
  %v332 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 0
  %v333 = load float, ptr %v332, align 4
  %v335 = fmul float %v308, %v328
  %v334 = fadd float %v333, %v335
  store float %v334, ptr %v332, align 4
  %v336 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 1
  %v337 = load float, ptr %v336, align 4
  %v339 = fmul float %v308, %v329
  %v338 = fadd float %v337, %v339
  store float %v338, ptr %v336, align 4
  %v340 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 2
  %v341 = load float, ptr %v340, align 4
  %v343 = fmul float %v308, %v330
  %v342 = fadd float %v341, %v343
  store float %v342, ptr %v340, align 4
  %v344 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 3
  %v345 = load float, ptr %v344, align 4
  %v347 = fmul float %v308, %v331
  %v346 = fadd float %v345, %v347
  store float %v346, ptr %v344, align 4
  %v348 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 4
  %v349 = load float, ptr %v348, align 4
  %v351 = fmul float %v309, %v328
  %v350 = fadd float %v349, %v351
  store float %v350, ptr %v348, align 4
  %v352 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 5
  %v353 = load float, ptr %v352, align 4
  %v355 = fmul float %v309, %v329
  %v354 = fadd float %v353, %v355
  store float %v354, ptr %v352, align 4
  %v356 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 6
  %v357 = load float, ptr %v356, align 4
  %v359 = fmul float %v309, %v330
  %v358 = fadd float %v357, %v359
  store float %v358, ptr %v356, align 4
  %v360 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 7
  %v361 = load float, ptr %v360, align 4
  %v363 = fmul float %v309, %v331
  %v362 = fadd float %v361, %v363
  store float %v362, ptr %v360, align 4
  %v364 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 8
  %v365 = load float, ptr %v364, align 4
  %v367 = fmul float %v310, %v328
  %v366 = fadd float %v365, %v367
  store float %v366, ptr %v364, align 4
  %v368 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 9
  %v369 = load float, ptr %v368, align 4
  %v371 = fmul float %v310, %v329
  %v370 = fadd float %v369, %v371
  store float %v370, ptr %v368, align 4
  %v372 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 10
  %v373 = load float, ptr %v372, align 4
  %v375 = fmul float %v310, %v330
  %v374 = fadd float %v373, %v375
  store float %v374, ptr %v372, align 4
  %v376 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 11
  %v377 = load float, ptr %v376, align 4
  %v379 = fmul float %v310, %v331
  %v378 = fadd float %v377, %v379
  store float %v378, ptr %v376, align 4
  %v380 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 12
  %v381 = load float, ptr %v380, align 4
  %v383 = fmul float %v311, %v328
  %v382 = fadd float %v381, %v383
  store float %v382, ptr %v380, align 4
  %v384 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 13
  %v385 = load float, ptr %v384, align 4
  %v387 = fmul float %v311, %v329
  %v386 = fadd float %v385, %v387
  store float %v386, ptr %v384, align 4
  %v388 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 14
  %v389 = load float, ptr %v388, align 4
  %v391 = fmul float %v311, %v330
  %v390 = fadd float %v389, %v391
  store float %v390, ptr %v388, align 4
  %v392 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 15
  %v393 = load float, ptr %v392, align 4
  %v395 = fmul float %v311, %v331
  %v394 = fadd float %v393, %v395
  store float %v394, ptr %v392, align 4
  %v396 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 16
  %v397 = load float, ptr %v396, align 4
  %v399 = fmul float %v316, %v328
  %v398 = fadd float %v397, %v399
  store float %v398, ptr %v396, align 4
  %v400 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 17
  %v401 = load float, ptr %v400, align 4
  %v403 = fmul float %v316, %v329
  %v402 = fadd float %v401, %v403
  store float %v402, ptr %v400, align 4
  %v404 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 18
  %v405 = load float, ptr %v404, align 4
  %v407 = fmul float %v316, %v330
  %v406 = fadd float %v405, %v407
  store float %v406, ptr %v404, align 4
  %v408 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 19
  %v409 = load float, ptr %v408, align 4
  %v411 = fmul float %v316, %v331
  %v410 = fadd float %v409, %v411
  store float %v410, ptr %v408, align 4
  %v412 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 20
  %v413 = load float, ptr %v412, align 4
  %v415 = fmul float %v317, %v328
  %v414 = fadd float %v413, %v415
  store float %v414, ptr %v412, align 4
  %v416 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 21
  %v417 = load float, ptr %v416, align 4
  %v419 = fmul float %v317, %v329
  %v418 = fadd float %v417, %v419
  store float %v418, ptr %v416, align 4
  %v420 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 22
  %v421 = load float, ptr %v420, align 4
  %v423 = fmul float %v317, %v330
  %v422 = fadd float %v421, %v423
  store float %v422, ptr %v420, align 4
  %v424 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 23
  %v425 = load float, ptr %v424, align 4
  %v427 = fmul float %v317, %v331
  %v426 = fadd float %v425, %v427
  store float %v426, ptr %v424, align 4
  %v428 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 24
  %v429 = load float, ptr %v428, align 4
  %v431 = fmul float %v318, %v328
  %v430 = fadd float %v429, %v431
  store float %v430, ptr %v428, align 4
  %v432 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 25
  %v433 = load float, ptr %v432, align 4
  %v435 = fmul float %v318, %v329
  %v434 = fadd float %v433, %v435
  store float %v434, ptr %v432, align 4
  %v436 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 26
  %v437 = load float, ptr %v436, align 4
  %v439 = fmul float %v318, %v330
  %v438 = fadd float %v437, %v439
  store float %v438, ptr %v436, align 4
  %v440 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 27
  %v441 = load float, ptr %v440, align 4
  %v443 = fmul float %v318, %v331
  %v442 = fadd float %v441, %v443
  store float %v442, ptr %v440, align 4
  %v444 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 28
  %v445 = load float, ptr %v444, align 4
  %v447 = fmul float %v319, %v328
  %v446 = fadd float %v445, %v447
  store float %v446, ptr %v444, align 4
  %v448 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 29
  %v449 = load float, ptr %v448, align 4
  %v451 = fmul float %v319, %v329
  %v450 = fadd float %v449, %v451
  store float %v450, ptr %v448, align 4
  %v452 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 30
  %v453 = load float, ptr %v452, align 4
  %v455 = fmul float %v319, %v330
  %v454 = fadd float %v453, %v455
  store float %v454, ptr %v452, align 4
  %v456 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 31
  %v457 = load float, ptr %v456, align 4
  %v459 = fmul float %v319, %v331
  %v458 = fadd float %v457, %v459
  store float %v458, ptr %v456, align 4
  %v299 = add i32 %v298, 1
  %v460 = icmp eq i32 %v299, 16
  br i1 %v460, label %ktl, label %kk, !llvm.loop !0
ktl:
  %v220 = add i32 %v219, 1
  %v461 = icmp eq i32 %v220, 64
  br i1 %v461, label %done, label %kt
done:
  %v462 = add nuw nsw i32 %v14, %v73
  %v463 = add nuw nsw i32 %v462, 0
  %v464 = mul nuw nsw i32 %v463, 1024
  %v465 = add nuw nsw i32 %v464, %v15
  %v466 = add nuw nsw i32 %v465, %v74
  %v467 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 0
  %v468 = load float, ptr %v467, align 4
  %v469 = insertelement <4 x float> poison, float %v468, i64 0
  %v470 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 1
  %v471 = load float, ptr %v470, align 4
  %v472 = insertelement <4 x float> %v469, float %v471, i64 1
  %v473 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 2
  %v474 = load float, ptr %v473, align 4
  %v475 = insertelement <4 x float> %v472, float %v474, i64 2
  %v476 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 3
  %v477 = load float, ptr %v476, align 4
  %v478 = insertelement <4 x float> %v475, float %v477, i64 3
  %v479 = add nuw nsw i32 %v466, 0
  %v480 = zext nneg i32 %v479 to i64
  %v481 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v480
  store <4 x float> %v478, ptr addrspace(1) %v481, align 16
  %v482 = add nuw nsw i32 %v14, %v73
  %v483 = add nuw nsw i32 %v482, 1
  %v484 = mul nuw nsw i32 %v483, 1024
  %v485 = add nuw nsw i32 %v484, %v15
  %v486 = add nuw nsw i32 %v485, %v74
  %v487 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 4
  %v488 = load float, ptr %v487, align 4
  %v489 = insertelement <4 x float> poison, float %v488, i64 0
  %v490 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 5
  %v491 = load float, ptr %v490, align 4
  %v492 = insertelement <4 x float> %v489, float %v491, i64 1
  %v493 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 6
  %v494 = load float, ptr %v493, align 4
  %v495 = insertelement <4 x float> %v492, float %v494, i64 2
  %v496 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 7
  %v497 = load float, ptr %v496, align 4
  %v498 = insertelement <4 x float> %v495, float %v497, i64 3
  %v499 = add nuw nsw i32 %v486, 0
  %v500 = zext nneg i32 %v499 to i64
  %v501 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v500
  store <4 x float> %v498, ptr addrspace(1) %v501, align 16
  %v502 = add nuw nsw i32 %v14, %v73
  %v503 = add nuw nsw i32 %v502, 2
  %v504 = mul nuw nsw i32 %v503, 1024
  %v505 = add nuw nsw i32 %v504, %v15
  %v506 = add nuw nsw i32 %v505, %v74
  %v507 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 8
  %v508 = load float, ptr %v507, align 4
  %v509 = insertelement <4 x float> poison, float %v508, i64 0
  %v510 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 9
  %v511 = load float, ptr %v510, align 4
  %v512 = insertelement <4 x float> %v509, float %v511, i64 1
  %v513 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 10
  %v514 = load float, ptr %v513, align 4
  %v515 = insertelement <4 x float> %v512, float %v514, i64 2
  %v516 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 11
  %v517 = load float, ptr %v516, align 4
  %v518 = insertelement <4 x float> %v515, float %v517, i64 3
  %v519 = add nuw nsw i32 %v506, 0
  %v520 = zext nneg i32 %v519 to i64
  %v521 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v520
  store <4 x float> %v518, ptr addrspace(1) %v521, align 16
  %v522 = add nuw nsw i32 %v14, %v73
  %v523 = add nuw nsw i32 %v522, 3
  %v524 = mul nuw nsw i32 %v523, 1024
  %v525 = add nuw nsw i32 %v524, %v15
  %v526 = add nuw nsw i32 %v525, %v74
  %v527 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 12
  %v528 = load float, ptr %v527, align 4
  %v529 = insertelement <4 x float> poison, float %v528, i64 0
  %v530 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 13
  %v531 = load float, ptr %v530, align 4
  %v532 = insertelement <4 x float> %v529, float %v531, i64 1
  %v533 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 14
  %v534 = load float, ptr %v533, align 4
  %v535 = insertelement <4 x float> %v532, float %v534, i64 2
  %v536 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 15
  %v537 = load float, ptr %v536, align 4
  %v538 = insertelement <4 x float> %v535, float %v537, i64 3
  %v539 = add nuw nsw i32 %v526, 0
  %v540 = zext nneg i32 %v539 to i64
  %v541 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v540
  store <4 x float> %v538, ptr addrspace(1) %v541, align 16
  %v542 = add nuw nsw i32 %v14, %v73
  %v543 = add nuw nsw i32 %v542, 64
  %v544 = mul nuw nsw i32 %v543, 1024
  %v545 = add nuw nsw i32 %v544, %v15
  %v546 = add nuw nsw i32 %v545, %v74
  %v547 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 16
  %v548 = load float, ptr %v547, align 4
  %v549 = insertelement <4 x float> poison, float %v548, i64 0
  %v550 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 17
  %v551 = load float, ptr %v550, align 4
  %v552 = insertelement <4 x float> %v549, float %v551, i64 1
  %v553 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 18
  %v554 = load float, ptr %v553, align 4
  %v555 = insertelement <4 x float> %v552, float %v554, i64 2
  %v556 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 19
  %v557 = load float, ptr %v556, align 4
  %v558 = insertelement <4 x float> %v555, float %v557, i64 3
  %v559 = add nuw nsw i32 %v546, 0
  %v560 = zext nneg i32 %v559 to i64
  %v561 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v560
  store <4 x float> %v558, ptr addrspace(1) %v561, align 16
  %v562 = add nuw nsw i32 %v14, %v73
  %v563 = add nuw nsw i32 %v562, 65
  %v564 = mul nuw nsw i32 %v563, 1024
  %v565 = add nuw nsw i32 %v564, %v15
  %v566 = add nuw nsw i32 %v565, %v74
  %v567 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 20
  %v568 = load float, ptr %v567, align 4
  %v569 = insertelement <4 x float> poison, float %v568, i64 0
  %v570 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 21
  %v571 = load float, ptr %v570, align 4
  %v572 = insertelement <4 x float> %v569, float %v571, i64 1
  %v573 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 22
  %v574 = load float, ptr %v573, align 4
  %v575 = insertelement <4 x float> %v572, float %v574, i64 2
  %v576 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 23
  %v577 = load float, ptr %v576, align 4
  %v578 = insertelement <4 x float> %v575, float %v577, i64 3
  %v579 = add nuw nsw i32 %v566, 0
  %v580 = zext nneg i32 %v579 to i64
  %v581 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v580
  store <4 x float> %v578, ptr addrspace(1) %v581, align 16
  %v582 = add nuw nsw i32 %v14, %v73
  %v583 = add nuw nsw i32 %v582, 66
  %v584 = mul nuw nsw i32 %v583, 1024
  %v585 = add nuw nsw i32 %v584, %v15
  %v586 = add nuw nsw i32 %v585, %v74
  %v587 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 24
  %v588 = load float, ptr %v587, align 4
  %v589 = insertelement <4 x float> poison, float %v588, i64 0
  %v590 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 25
  %v591 = load float, ptr %v590, align 4
  %v592 = insertelement <4 x float> %v589, float %v591, i64 1
  %v593 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 26
  %v594 = load float, ptr %v593, align 4
  %v595 = insertelement <4 x float> %v592, float %v594, i64 2
  %v596 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 27
  %v597 = load float, ptr %v596, align 4
  %v598 = insertelement <4 x float> %v595, float %v597, i64 3
  %v599 = add nuw nsw i32 %v586, 0
  %v600 = zext nneg i32 %v599 to i64
  %v601 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v600
  store <4 x float> %v598, ptr addrspace(1) %v601, align 16
  %v602 = add nuw nsw i32 %v14, %v73
  %v603 = add nuw nsw i32 %v602, 67
  %v604 = mul nuw nsw i32 %v603, 1024
  %v605 = add nuw nsw i32 %v604, %v15
  %v606 = add nuw nsw i32 %v605, %v74
  %v607 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 28
  %v608 = load float, ptr %v607, align 4
  %v609 = insertelement <4 x float> poison, float %v608, i64 0
  %v610 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 29
  %v611 = load float, ptr %v610, align 4
  %v612 = insertelement <4 x float> %v609, float %v611, i64 1
  %v613 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 30
  %v614 = load float, ptr %v613, align 4
  %v615 = insertelement <4 x float> %v612, float %v614, i64 2
  %v616 = getelementptr inbounds [32 x float], ptr %v16, i64 0, i64 31
  %v617 = load float, ptr %v616, align 4
  %v618 = insertelement <4 x float> %v615, float %v617, i64 3
  %v619 = add nuw nsw i32 %v606, 0
  %v620 = zext nneg i32 %v619 to i64
  %v621 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v620
  store <4 x float> %v618, ptr addrspace(1) %v621, align 16
  ret void
}

define internal float @fn1(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 7, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 13, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 101, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 50, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to float
  store float %t33, ptr %o1
  %t34 = load float, ptr %o1
  ret float %t34
}

define ptx_kernel void @mapal_gen_7a2ade86c804ef09(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call float @fn1(i32 %x)
  %p = getelementptr inbounds float, ptr addrspace(1) %o, i64 %i
  store float %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

define internal float @fn2(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 7, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 57, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 101, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 50, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to float
  store float %t33, ptr %o1
  %t34 = load float, ptr %o1
  ret float %t34
}

define ptx_kernel void @mapal_gen_1aeae5b5ba14d87e(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call float @fn2(i32 %x)
  %p = getelementptr inbounds float, ptr addrspace(1) %o, i64 %i
  store float %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

!0 = distinct !{!0, !1}
!1 = !{!"llvm.loop.unroll.full"}
