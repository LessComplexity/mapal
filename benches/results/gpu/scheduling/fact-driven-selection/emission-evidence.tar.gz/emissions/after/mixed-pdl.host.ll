; mapal-backend-llvm emitted module
declare void @mapal_print_i32(i32, i1 zeroext)
declare void @mapal_print_i64(i64, i1 zeroext)
declare void @mapal_print_u8(i8 zeroext, i1 zeroext)
declare void @mapal_print_bool(i1 zeroext, i1 zeroext)
declare void @mapal_print_f32(float, i1 zeroext)
declare void @mapal_print_f64(double, i1 zeroext)
declare void @mapal_print_str(ptr, i64, i1 zeroext)
declare double @mapal_time_ms()
declare void @mapal_trap(i32) noreturn
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @mapal_gpu_init(i32)
declare i64 @mapal_gpu_alloc(ptr, i64)
declare void @mapal_gpu_h2d(i64, ptr, i64)
declare void @mapal_gpu_d2h(ptr, i64, i64, i64)
declare void @mapal_gpu_launch(i64, i64, i64, i64, i32, i32, i32, i32)
declare void @mapal_gpu_gen(i64, i64, i64)
declare void @mapal_gpu_free(ptr)
declare i64 @mapal_gpu_arena(ptr, i64)

define internal void @mapal_main() {
entry:
  %darena = alloca i64
  store i64 0, ptr %darena
  %o7 = alloca { ptr, ptr, ptr, ptr }
  %o10 = alloca { ptr, ptr, ptr, ptr }
  %o12 = alloca { ptr, i32 }
  %o13 = alloca float
  %o14 = alloca float
  %o16 = alloca { ptr, i32 }
  %o17 = alloca float
  %o18 = alloca float
  %d0 = alloca i64
  store i64 0, ptr %d0
  %d3 = alloca i64
  store i64 0, ptr %d3
  %d15 = alloca i64
  store i64 0, ptr %d15
  %d22 = alloca i64
  store i64 0, ptr %d22
  %s30 = alloca float
  %s40 = alloca float
  %t2 = call i64 @mapal_gpu_arena(ptr %darena, i64 394240)
  %t1 = add i64 %t2, 0
  store i64 %t1, ptr %d0
  call void @mapal_gpu_gen(i64 3141524110586144771, i64 %t1, i64 32768)
  %t5 = call i64 @mapal_gpu_arena(ptr %darena, i64 394240)
  %t4 = add i64 %t5, 131072
  store i64 %t4, ptr %d3
  call void @mapal_gpu_gen(i64 6696365533415965814, i64 %t4, i64 32768)
  %t6 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o7, i32 0, i32 1
  store ptr null, ptr %t6
  %t7 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o10, i32 0, i32 1
  store ptr null, ptr %t7
  %t8 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o7, i32 0, i32 2
  store ptr null, ptr %t8
  %t9 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o10, i32 0, i32 2
  store ptr null, ptr %t9
  %t10 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o7, i32 0, i32 0
  store ptr null, ptr %t10
  %t11 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o10, i32 0, i32 0
  store ptr null, ptr %t11
  %t12 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o7, i32 0, i32 3
  store ptr null, ptr %t12
  %t13 = load i64, ptr %d0
  %t14 = load i64, ptr %d3
  %t17 = call i64 @mapal_gpu_arena(ptr %darena, i64 394240)
  %t16 = add i64 %t17, 262144
  store i64 %t16, ptr %d15
  call void @mapal_gpu_launch(i64 5713454502959414211, i64 %t13, i64 %t14, i64 %t16, i32 1, i32 1, i32 256, i32 0)
  %t18 = getelementptr { ptr, i32 }, ptr %o12, i32 0, i32 0
  store ptr null, ptr %t18
  %t19 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o10, i32 0, i32 3
  store ptr null, ptr %t19
  %t20 = load i64, ptr %d0
  %t21 = load i64, ptr %d3
  %t24 = call i64 @mapal_gpu_arena(ptr %darena, i64 394240)
  %t23 = add i64 %t24, 263168
  store i64 %t23, ptr %d22
  call void @mapal_gpu_launch(i64 -7784794042878734893, i64 %t20, i64 %t21, i64 %t23, i32 4, i32 2, i32 32, i32 19456)
  %t25 = getelementptr { ptr, i32 }, ptr %o16, i32 0, i32 0
  store ptr null, ptr %t25
  %t26 = getelementptr { ptr, i32 }, ptr %o12, i32 0, i32 1
  store i32 0, ptr %t26
  %t27 = getelementptr { ptr, i32 }, ptr %o12, i32 0, i32 1
  %t28 = load i32, ptr %t27
  %t29 = sext i32 %t28 to i64
  %t31 = load i64, ptr %d15
  %t32 = mul i64 %t29, 4
  call void @mapal_gpu_d2h(ptr %s30, i64 %t31, i64 %t32, i64 4)
  %t33 = load float, ptr %s30
  store float %t33, ptr %o13
  %t34 = load float, ptr %o13
  store float %t34, ptr %o14
  %t35 = load float, ptr %o14
  call void @mapal_print_f32(float %t35, i1 zeroext true)
  %t36 = getelementptr { ptr, i32 }, ptr %o16, i32 0, i32 1
  store i32 0, ptr %t36
  %t37 = getelementptr { ptr, i32 }, ptr %o16, i32 0, i32 1
  %t38 = load i32, ptr %t37
  %t39 = sext i32 %t38 to i64
  %t41 = load i64, ptr %d22
  %t42 = mul i64 %t39, 4
  call void @mapal_gpu_d2h(ptr %s40, i64 %t41, i64 %t42, i64 4)
  %t43 = load float, ptr %s40
  store float %t43, ptr %o17
  %t44 = load float, ptr %o17
  store float %t44, ptr %o18
  %t45 = load float, ptr %o18
  call void @mapal_print_f32(float %t45, i1 zeroext true)
  call void @mapal_gpu_free(ptr %darena)
  ret void
}

define internal float @fn1(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 31, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = srem i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = sitofp i32 %t8 to float
  store float %t9, ptr %o1
  %t10 = load float, ptr %o1
  ret float %t10
}

define internal float @fn2(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 23, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = srem i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = sitofp i32 %t8 to float
  store float %t9, ptr %o1
  %t10 = load float, ptr %o1
  ret float %t10
}

define internal float @fn3({ ptr, ptr, i32, float, i32 } %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca { ptr, ptr, i32, float, i32 }
  %o1 = alloca float
  %o2 = alloca ptr
  %o3 = alloca ptr
  %o4 = alloca i32
  %o5 = alloca float
  %o6 = alloca i32
  %o7 = alloca { ptr, i32 }
  %o8 = alloca float
  %o9 = alloca { i32, i32 }
  %o10 = alloca i32
  %o11 = alloca { i32, i32 }
  %o12 = alloca i32
  %o13 = alloca { ptr, i32 }
  %o14 = alloca float
  %o15 = alloca { float, float }
  %o16 = alloca float
  %o17 = alloca { float, float }
  store { ptr, ptr, i32, float, i32 } %arg, ptr %o0
  %t0 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 0
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %o2
  %t2 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 1
  %t3 = load ptr, ptr %t2
  store ptr %t3, ptr %o3
  %t4 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 2
  %t5 = load i32, ptr %t4
  store i32 %t5, ptr %o4
  %t6 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 3
  %t7 = load float, ptr %t6
  store float %t7, ptr %o5
  %t8 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 4
  %t9 = load i32, ptr %t8
  store i32 %t9, ptr %o6
  %t10 = load ptr, ptr %o2
  %t11 = getelementptr { ptr, i32 }, ptr %o7, i32 0, i32 0
  store ptr %t10, ptr %t11
  %t12 = load ptr, ptr %o3
  %t13 = getelementptr { ptr, i32 }, ptr %o13, i32 0, i32 0
  store ptr %t12, ptr %t13
  %t14 = load i32, ptr %o4
  %t15 = getelementptr { i32, i32 }, ptr %o9, i32 0, i32 0
  store i32 %t14, ptr %t15
  %t16 = load float, ptr %o5
  %t17 = getelementptr { float, float }, ptr %o17, i32 0, i32 1
  store float %t16, ptr %t17
  %t18 = load i32, ptr %o6
  %t19 = getelementptr { ptr, i32 }, ptr %o7, i32 0, i32 1
  store i32 %t18, ptr %t19
  %t20 = load i32, ptr %o6
  %t21 = getelementptr { i32, i32 }, ptr %o11, i32 0, i32 1
  store i32 %t20, ptr %t21
  %t22 = load ptr, ptr %o2
  %t23 = getelementptr { ptr, i32 }, ptr %o7, i32 0, i32 1
  %t24 = load i32, ptr %t23
  %t25 = sext i32 %t24 to i64
  %t26 = getelementptr [32768 x float], ptr %t22, i64 0, i64 %t25
  %t27 = load float, ptr %t26
  store float %t27, ptr %o8
  %t28 = load float, ptr %o8
  %t29 = getelementptr { float, float }, ptr %o15, i32 0, i32 0
  store float %t28, ptr %t29
  %t30 = getelementptr { i32, i32 }, ptr %o9, i32 0, i32 1
  store i32 128, ptr %t30
  %t31 = getelementptr { i32, i32 }, ptr %o9, i32 0, i32 0
  %t32 = load i32, ptr %t31
  %t33 = getelementptr { i32, i32 }, ptr %o9, i32 0, i32 1
  %t34 = load i32, ptr %t33
  %t35 = mul i32 %t32, %t34
  store i32 %t35, ptr %o10
  %t36 = load i32, ptr %o10
  %t37 = getelementptr { i32, i32 }, ptr %o11, i32 0, i32 0
  store i32 %t36, ptr %t37
  %t38 = getelementptr { i32, i32 }, ptr %o11, i32 0, i32 0
  %t39 = load i32, ptr %t38
  %t40 = getelementptr { i32, i32 }, ptr %o11, i32 0, i32 1
  %t41 = load i32, ptr %t40
  %t42 = add i32 %t39, %t41
  store i32 %t42, ptr %o12
  %t43 = load i32, ptr %o12
  %t44 = getelementptr { ptr, i32 }, ptr %o13, i32 0, i32 1
  store i32 %t43, ptr %t44
  %t45 = load ptr, ptr %o3
  %t46 = getelementptr { ptr, i32 }, ptr %o13, i32 0, i32 1
  %t47 = load i32, ptr %t46
  %t48 = sext i32 %t47 to i64
  %t49 = getelementptr [32768 x float], ptr %t45, i64 0, i64 %t48
  %t50 = load float, ptr %t49
  store float %t50, ptr %o14
  %t51 = load float, ptr %o14
  %t52 = getelementptr { float, float }, ptr %o15, i32 0, i32 1
  store float %t51, ptr %t52
  %t53 = getelementptr { float, float }, ptr %o15, i32 0, i32 0
  %t54 = load float, ptr %t53
  %t55 = getelementptr { float, float }, ptr %o15, i32 0, i32 1
  %t56 = load float, ptr %t55
  %t57 = fmul float %t54, %t56
  store float %t57, ptr %o16
  %t58 = load float, ptr %o16
  %t59 = getelementptr { float, float }, ptr %o17, i32 0, i32 0
  store float %t58, ptr %t59
  %t60 = getelementptr { float, float }, ptr %o17, i32 0, i32 0
  %t61 = load float, ptr %t60
  %t62 = getelementptr { float, float }, ptr %o17, i32 0, i32 1
  %t63 = load float, ptr %t62
  %t64 = fadd float %t61, %t63
  store float %t64, ptr %o1
  %t65 = load float, ptr %o1
  ret float %t65
}

define internal float @fn4({ ptr, ptr, ptr, i32 } %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca { ptr, ptr, ptr, i32 }
  %o1 = alloca float
  %o2 = alloca ptr
  %o3 = alloca ptr
  %o4 = alloca ptr
  %o5 = alloca i32
  %o6 = alloca { ptr, ptr, i32, float, ptr }
  %s20 = alloca float
  %s21 = alloca i64
  %s30 = alloca { ptr, ptr, i32, float, i32 }
  store { ptr, ptr, ptr, i32 } %arg, ptr %o0
  %t0 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 0
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %o2
  %t2 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 1
  %t3 = load ptr, ptr %t2
  store ptr %t3, ptr %o3
  %t4 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 2
  %t5 = load ptr, ptr %t4
  store ptr %t5, ptr %o4
  %t6 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 3
  %t7 = load i32, ptr %t6
  store i32 %t7, ptr %o5
  %t8 = load ptr, ptr %o2
  %t9 = getelementptr { ptr, ptr, i32, float, ptr }, ptr %o6, i32 0, i32 4
  store ptr %t8, ptr %t9
  %t10 = load ptr, ptr %o3
  %t11 = getelementptr { ptr, ptr, i32, float, ptr }, ptr %o6, i32 0, i32 0
  store ptr %t10, ptr %t11
  %t12 = load ptr, ptr %o4
  %t13 = getelementptr { ptr, ptr, i32, float, ptr }, ptr %o6, i32 0, i32 1
  store ptr %t12, ptr %t13
  %t14 = load i32, ptr %o5
  %t15 = getelementptr { ptr, ptr, i32, float, ptr }, ptr %o6, i32 0, i32 2
  store i32 %t14, ptr %t15
  %t16 = getelementptr { ptr, ptr, i32, float, ptr }, ptr %o6, i32 0, i32 3
  store float 0x4000000000000000, ptr %t16
  %t17 = getelementptr { ptr, ptr, i32, float, ptr }, ptr %o6, i32 0, i32 3
  %t18 = load float, ptr %t17
  %t19 = load ptr, ptr %o2
  store float %t18, ptr %s20
  store i64 0, ptr %s21
  br label %bb22
bb22:
  %t25 = load i64, ptr %s21
  %t26 = icmp uge i64 %t25, 128
  br i1 %t26, label %bb24, label %bb23
bb23:
  %t27 = getelementptr [128 x i32], ptr %t19, i64 0, i64 %t25
  %t28 = load i32, ptr %t27
  %t29 = load float, ptr %s20
  %t31 = load ptr, ptr %o3
  %t32 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %s30, i32 0, i32 0
  store ptr %t31, ptr %t32
  %t33 = load ptr, ptr %o4
  %t34 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %s30, i32 0, i32 1
  store ptr %t33, ptr %t34
  %t35 = getelementptr { ptr, ptr, i32, float, ptr }, ptr %o6, i32 0, i32 2
  %t36 = load i32, ptr %t35
  %t37 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %s30, i32 0, i32 2
  store i32 %t36, ptr %t37
  %t38 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %s30, i32 0, i32 3
  store float %t29, ptr %t38
  %t39 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %s30, i32 0, i32 4
  store i32 %t28, ptr %t39
  %t40 = load { ptr, ptr, i32, float, i32 }, ptr %s30
  %t41 = call float @fn3({ ptr, ptr, i32, float, i32 } %t40)
  store float %t41, ptr %s20
  %t42 = add i64 %t25, 1
  store i64 %t42, ptr %s21
  br label %bb22
bb24:
  %t43 = load float, ptr %s20
  store float %t43, ptr %o1
  %t44 = load float, ptr %o1
  ret float %t44
}

define internal float @fn5({ ptr, i32, ptr, i32, float, i32 } %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca { ptr, i32, ptr, i32, float, i32 }
  %o1 = alloca float
  %o2 = alloca ptr
  %o3 = alloca i32
  %o4 = alloca ptr
  %o5 = alloca i32
  %o6 = alloca float
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  %o10 = alloca { i32, i32 }
  %o11 = alloca i32
  %o12 = alloca { ptr, i32 }
  %o13 = alloca float
  %o14 = alloca { i32, i32 }
  %o15 = alloca i32
  %o16 = alloca { i32, i32 }
  %o17 = alloca i32
  %o18 = alloca { ptr, i32 }
  %o19 = alloca float
  %o20 = alloca { float, float }
  %o21 = alloca float
  %o22 = alloca { float, float }
  store { ptr, i32, ptr, i32, float, i32 } %arg, ptr %o0
  %t0 = getelementptr { ptr, i32, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 0
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %o2
  %t2 = getelementptr { ptr, i32, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 1
  %t3 = load i32, ptr %t2
  store i32 %t3, ptr %o3
  %t4 = getelementptr { ptr, i32, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 2
  %t5 = load ptr, ptr %t4
  store ptr %t5, ptr %o4
  %t6 = getelementptr { ptr, i32, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 3
  %t7 = load i32, ptr %t6
  store i32 %t7, ptr %o5
  %t8 = getelementptr { ptr, i32, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 4
  %t9 = load float, ptr %t8
  store float %t9, ptr %o6
  %t10 = getelementptr { ptr, i32, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 5
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %o7
  %t12 = load ptr, ptr %o2
  %t13 = getelementptr { ptr, i32 }, ptr %o12, i32 0, i32 0
  store ptr %t12, ptr %t13
  %t14 = load i32, ptr %o3
  %t15 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t14, ptr %t15
  %t16 = load ptr, ptr %o4
  %t17 = getelementptr { ptr, i32 }, ptr %o18, i32 0, i32 0
  store ptr %t16, ptr %t17
  %t18 = load i32, ptr %o5
  %t19 = getelementptr { i32, i32 }, ptr %o16, i32 0, i32 1
  store i32 %t18, ptr %t19
  %t20 = load float, ptr %o6
  %t21 = getelementptr { float, float }, ptr %o22, i32 0, i32 0
  store float %t20, ptr %t21
  %t22 = load i32, ptr %o7
  %t23 = getelementptr { i32, i32 }, ptr %o10, i32 0, i32 1
  store i32 %t22, ptr %t23
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o14, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 128, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = mul i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = getelementptr { i32, i32 }, ptr %o10, i32 0, i32 0
  store i32 %t32, ptr %t33
  %t34 = getelementptr { i32, i32 }, ptr %o10, i32 0, i32 0
  %t35 = load i32, ptr %t34
  %t36 = getelementptr { i32, i32 }, ptr %o10, i32 0, i32 1
  %t37 = load i32, ptr %t36
  %t38 = add i32 %t35, %t37
  store i32 %t38, ptr %o11
  %t39 = load i32, ptr %o11
  %t40 = getelementptr { ptr, i32 }, ptr %o12, i32 0, i32 1
  store i32 %t39, ptr %t40
  %t41 = load ptr, ptr %o2
  %t42 = getelementptr { ptr, i32 }, ptr %o12, i32 0, i32 1
  %t43 = load i32, ptr %t42
  %t44 = sext i32 %t43 to i64
  %t45 = getelementptr [32768 x float], ptr %t41, i64 0, i64 %t44
  %t46 = load float, ptr %t45
  store float %t46, ptr %o13
  %t47 = load float, ptr %o13
  %t48 = getelementptr { float, float }, ptr %o20, i32 0, i32 0
  store float %t47, ptr %t48
  %t49 = getelementptr { i32, i32 }, ptr %o14, i32 0, i32 1
  store i32 256, ptr %t49
  %t50 = getelementptr { i32, i32 }, ptr %o14, i32 0, i32 0
  %t51 = load i32, ptr %t50
  %t52 = getelementptr { i32, i32 }, ptr %o14, i32 0, i32 1
  %t53 = load i32, ptr %t52
  %t54 = mul i32 %t51, %t53
  store i32 %t54, ptr %o15
  %t55 = load i32, ptr %o15
  %t56 = getelementptr { i32, i32 }, ptr %o16, i32 0, i32 0
  store i32 %t55, ptr %t56
  %t57 = getelementptr { i32, i32 }, ptr %o16, i32 0, i32 0
  %t58 = load i32, ptr %t57
  %t59 = getelementptr { i32, i32 }, ptr %o16, i32 0, i32 1
  %t60 = load i32, ptr %t59
  %t61 = add i32 %t58, %t60
  store i32 %t61, ptr %o17
  %t62 = load i32, ptr %o17
  %t63 = getelementptr { ptr, i32 }, ptr %o18, i32 0, i32 1
  store i32 %t62, ptr %t63
  %t64 = load ptr, ptr %o4
  %t65 = getelementptr { ptr, i32 }, ptr %o18, i32 0, i32 1
  %t66 = load i32, ptr %t65
  %t67 = sext i32 %t66 to i64
  %t68 = getelementptr [32768 x float], ptr %t64, i64 0, i64 %t67
  %t69 = load float, ptr %t68
  store float %t69, ptr %o19
  %t70 = load float, ptr %o19
  %t71 = getelementptr { float, float }, ptr %o20, i32 0, i32 1
  store float %t70, ptr %t71
  %t72 = getelementptr { float, float }, ptr %o20, i32 0, i32 0
  %t73 = load float, ptr %t72
  %t74 = getelementptr { float, float }, ptr %o20, i32 0, i32 1
  %t75 = load float, ptr %t74
  %t76 = fmul float %t73, %t75
  store float %t76, ptr %o21
  %t77 = load float, ptr %o21
  %t78 = getelementptr { float, float }, ptr %o22, i32 0, i32 1
  store float %t77, ptr %t78
  %t79 = getelementptr { float, float }, ptr %o22, i32 0, i32 0
  %t80 = load float, ptr %t79
  %t81 = getelementptr { float, float }, ptr %o22, i32 0, i32 1
  %t82 = load float, ptr %t81
  %t83 = fadd float %t80, %t82
  store float %t83, ptr %o1
  %t84 = load float, ptr %o1
  ret float %t84
}

define internal float @fn6({ ptr, ptr, ptr, i32 } %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca { ptr, ptr, ptr, i32 }
  %o1 = alloca float
  %o2 = alloca ptr
  %o3 = alloca ptr
  %o4 = alloca ptr
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  %o10 = alloca { ptr, i32, ptr, i32, float, ptr }
  %s38 = alloca float
  %s39 = alloca i64
  %s48 = alloca { ptr, i32, ptr, i32, float, i32 }
  store { ptr, ptr, ptr, i32 } %arg, ptr %o0
  %t0 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 0
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %o2
  %t2 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 1
  %t3 = load ptr, ptr %t2
  store ptr %t3, ptr %o3
  %t4 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 2
  %t5 = load ptr, ptr %t4
  store ptr %t5, ptr %o4
  %t6 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 3
  %t7 = load i32, ptr %t6
  store i32 %t7, ptr %o5
  %t8 = load ptr, ptr %o2
  %t9 = getelementptr { ptr, i32, ptr, i32, float, ptr }, ptr %o10, i32 0, i32 5
  store ptr %t8, ptr %t9
  %t10 = load ptr, ptr %o3
  %t11 = getelementptr { ptr, i32, ptr, i32, float, ptr }, ptr %o10, i32 0, i32 0
  store ptr %t10, ptr %t11
  %t12 = load ptr, ptr %o4
  %t13 = getelementptr { ptr, i32, ptr, i32, float, ptr }, ptr %o10, i32 0, i32 2
  store ptr %t12, ptr %t13
  %t14 = load i32, ptr %o5
  %t15 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t14, ptr %t15
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 256, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = sdiv i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { ptr, i32, ptr, i32, float, ptr }, ptr %o10, i32 0, i32 1
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 256, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = srem i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = getelementptr { ptr, i32, ptr, i32, float, ptr }, ptr %o10, i32 0, i32 3
  store i32 %t32, ptr %t33
  %t34 = getelementptr { ptr, i32, ptr, i32, float, ptr }, ptr %o10, i32 0, i32 4
  store float 0x0000000000000000, ptr %t34
  %t35 = getelementptr { ptr, i32, ptr, i32, float, ptr }, ptr %o10, i32 0, i32 4
  %t36 = load float, ptr %t35
  %t37 = load ptr, ptr %o2
  store float %t36, ptr %s38
  store i64 0, ptr %s39
  br label %bb40
bb40:
  %t43 = load i64, ptr %s39
  %t44 = icmp uge i64 %t43, 128
  br i1 %t44, label %bb42, label %bb41
bb41:
  %t45 = getelementptr [128 x i32], ptr %t37, i64 0, i64 %t43
  %t46 = load i32, ptr %t45
  %t47 = load float, ptr %s38
  %t49 = load ptr, ptr %o3
  %t50 = getelementptr { ptr, i32, ptr, i32, float, i32 }, ptr %s48, i32 0, i32 0
  store ptr %t49, ptr %t50
  %t51 = getelementptr { ptr, i32, ptr, i32, float, ptr }, ptr %o10, i32 0, i32 1
  %t52 = load i32, ptr %t51
  %t53 = getelementptr { ptr, i32, ptr, i32, float, i32 }, ptr %s48, i32 0, i32 1
  store i32 %t52, ptr %t53
  %t54 = load ptr, ptr %o4
  %t55 = getelementptr { ptr, i32, ptr, i32, float, i32 }, ptr %s48, i32 0, i32 2
  store ptr %t54, ptr %t55
  %t56 = getelementptr { ptr, i32, ptr, i32, float, ptr }, ptr %o10, i32 0, i32 3
  %t57 = load i32, ptr %t56
  %t58 = getelementptr { ptr, i32, ptr, i32, float, i32 }, ptr %s48, i32 0, i32 3
  store i32 %t57, ptr %t58
  %t59 = getelementptr { ptr, i32, ptr, i32, float, i32 }, ptr %s48, i32 0, i32 4
  store float %t47, ptr %t59
  %t60 = getelementptr { ptr, i32, ptr, i32, float, i32 }, ptr %s48, i32 0, i32 5
  store i32 %t46, ptr %t60
  %t61 = load { ptr, i32, ptr, i32, float, i32 }, ptr %s48
  %t62 = call float @fn5({ ptr, i32, ptr, i32, float, i32 } %t61)
  store float %t62, ptr %s38
  %t63 = add i64 %t43, 1
  store i64 %t63, ptr %s39
  br label %bb40
bb42:
  %t64 = load float, ptr %s38
  store float %t64, ptr %o1
  %t65 = load float, ptr %o1
  ret float %t65
}

define i32 @main() {
entry:
  call void @mapal_gpu_init(i32 5)
  call void @mapal_main()
  ret i32 0
}
