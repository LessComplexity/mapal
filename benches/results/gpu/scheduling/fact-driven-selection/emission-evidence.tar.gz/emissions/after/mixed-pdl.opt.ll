; ModuleID = '/private/tmp/mapal-gpu-schedule-facts/emissions/after/mixed-pdl.device.ll'
source_filename = "/private/tmp/mapal-gpu-schedule-facts/emissions/after/mixed-pdl.device.ll"
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@mapal_smem = external addrspace(3) global [0 x i8], align 16

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 2147483647) i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #0

; Function Attrs: nocallback nounwind memory(argmem: readwrite)
declare void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) noalias writeonly, ptr addrspace(1) noalias readonly) #1

; Function Attrs: nounwind
declare void @llvm.nvvm.cp.async.commit.group() #2

; Function Attrs: nounwind
declare void @llvm.nvvm.cp.async.wait.group(i32 immarg) #2

; Function Attrs: nounwind
define ptx_kernel void @mapal_tile_4f4a449969407bc3(ptr addrspace(1) noalias readonly align 4 captures(none) %a, ptr addrspace(1) noalias readonly align 4 captures(none) %b, ptr addrspace(1) noalias writeonly align 4 captures(none) %o) local_unnamed_addr #3 {
entry:
  tail call void asm sideeffect "griddepcontrol.wait;", "~{memory}"() #2
  tail call void asm sideeffect "griddepcontrol.launch_dependents;", "~{memory}"() #2
  %v1 = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = zext nneg i32 %v1 to i64
  %v3 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v7 = icmp eq i32 %v3, 0
  br i1 %v7, label %kloop.preheader, label %done

kloop.preheader:                                  ; preds = %entry
  %.idx = shl nuw nsw i64 %v2, 9
  %0 = getelementptr i8, ptr addrspace(1) %b, i64 %.idx
  br label %kloop

kloop:                                            ; preds = %kloop, %kloop.preheader
  %v18 = phi i64 [ 0, %kloop.preheader ], [ %v20.7, %kloop ]
  %v19 = phi float [ 2.000000e+00, %kloop.preheader ], [ %v29.7, %kloop ]
  %v23 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v18
  %v24 = load float, ptr addrspace(1) %v23, align 4
  %v27 = getelementptr float, ptr addrspace(1) %0, i64 %v18
  %v28 = load float, ptr addrspace(1) %v27, align 4
  %v30 = fmul float %v24, %v28
  %v29 = fadd float %v19, %v30
  %v20 = or disjoint i64 %v18, 1
  %v23.1 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v20
  %v24.1 = load float, ptr addrspace(1) %v23.1, align 4
  %v27.1 = getelementptr float, ptr addrspace(1) %0, i64 %v20
  %v28.1 = load float, ptr addrspace(1) %v27.1, align 4
  %v30.1 = fmul float %v24.1, %v28.1
  %v29.1 = fadd float %v29, %v30.1
  %v20.1 = or disjoint i64 %v18, 2
  %v23.2 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v20.1
  %v24.2 = load float, ptr addrspace(1) %v23.2, align 4
  %v27.2 = getelementptr float, ptr addrspace(1) %0, i64 %v20.1
  %v28.2 = load float, ptr addrspace(1) %v27.2, align 4
  %v30.2 = fmul float %v24.2, %v28.2
  %v29.2 = fadd float %v29.1, %v30.2
  %v20.2 = or disjoint i64 %v18, 3
  %v23.3 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v20.2
  %v24.3 = load float, ptr addrspace(1) %v23.3, align 4
  %v27.3 = getelementptr float, ptr addrspace(1) %0, i64 %v20.2
  %v28.3 = load float, ptr addrspace(1) %v27.3, align 4
  %v30.3 = fmul float %v24.3, %v28.3
  %v29.3 = fadd float %v29.2, %v30.3
  %v20.3 = or disjoint i64 %v18, 4
  %v23.4 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v20.3
  %v24.4 = load float, ptr addrspace(1) %v23.4, align 4
  %v27.4 = getelementptr float, ptr addrspace(1) %0, i64 %v20.3
  %v28.4 = load float, ptr addrspace(1) %v27.4, align 4
  %v30.4 = fmul float %v24.4, %v28.4
  %v29.4 = fadd float %v29.3, %v30.4
  %v20.4 = or disjoint i64 %v18, 5
  %v23.5 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v20.4
  %v24.5 = load float, ptr addrspace(1) %v23.5, align 4
  %v27.5 = getelementptr float, ptr addrspace(1) %0, i64 %v20.4
  %v28.5 = load float, ptr addrspace(1) %v27.5, align 4
  %v30.5 = fmul float %v24.5, %v28.5
  %v29.5 = fadd float %v29.4, %v30.5
  %v20.5 = or disjoint i64 %v18, 6
  %v23.6 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v20.5
  %v24.6 = load float, ptr addrspace(1) %v23.6, align 4
  %v27.6 = getelementptr float, ptr addrspace(1) %0, i64 %v20.5
  %v28.6 = load float, ptr addrspace(1) %v27.6, align 4
  %v30.6 = fmul float %v24.6, %v28.6
  %v29.6 = fadd float %v29.5, %v30.6
  %v20.6 = or disjoint i64 %v18, 7
  %v23.7 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v20.6
  %v24.7 = load float, ptr addrspace(1) %v23.7, align 4
  %v27.7 = getelementptr float, ptr addrspace(1) %0, i64 %v20.6
  %v28.7 = load float, ptr addrspace(1) %v27.7, align 4
  %v30.7 = fmul float %v24.7, %v28.7
  %v29.7 = fadd float %v29.6, %v30.7
  %v20.7 = add nuw nsw i64 %v18, 8
  %v31.7 = icmp eq i64 %v20.7, 128
  br i1 %v31.7, label %store, label %kloop

store:                                            ; preds = %kloop
  %v32 = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %v2
  store float %v29.7, ptr addrspace(1) %v32, align 4
  br label %done

done:                                             ; preds = %store, %entry
  ret void
}

; Function Attrs: nounwind
define ptx_kernel void @mapal_tile_93f6db1048a2cdd3(ptr addrspace(1) noalias readonly align 16 %a, ptr addrspace(1) noalias readonly align 16 %b, ptr addrspace(1) noalias writeonly align 16 %o) local_unnamed_addr #4 {
entry:
  tail call void asm sideeffect "griddepcontrol.wait;", "~{memory}"() #2
  tail call void asm sideeffect "griddepcontrol.launch_dependents;", "~{memory}"() #2
  %v1 = tail call range(i32 0, 32) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = zext nneg i32 %v1 to i64
  %v3 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v4 = zext nneg i32 %v3 to i64
  %v5 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v111 = lshr i64 %v2, 2
  %v12 = and i64 %v2, 3
  %0 = shl nuw nsw i32 %v5, 6
  %v13 = zext nneg i32 %0 to i64
  %v14 = shl nuw nsw i64 %v4, 6
  %v147 = shl nuw nsw i64 %v12, 2
  %v148 = or disjoint i64 %v111, %v13
  %v154 = or disjoint i64 %v2, 32
  %v1553 = lshr i64 %v154, 2
  %v156 = shl nuw nsw i64 %v2, 2
  %v157 = and i64 %v156, 12
  %v158 = or disjoint i64 %v1553, %v13
  %v164 = or disjoint i64 %v2, 64
  %v1655 = lshr i64 %v164, 2
  %v168 = or disjoint i64 %v1655, %v13
  %v174 = or disjoint i64 %v2, 96
  %v1757 = lshr i64 %v174, 2
  %v178 = or disjoint i64 %v1757, %v13
  %v184 = or disjoint i64 %v2, 128
  %v18510 = lshr i64 %v184, 2
  %v188 = or disjoint i64 %v18510, %v13
  %v194 = or disjoint i64 %v2, 160
  %v19511 = lshr i64 %v194, 2
  %v198 = or disjoint i64 %v19511, %v13
  %v204 = or disjoint i64 %v2, 192
  %v20512 = lshr i64 %v204, 2
  %v208 = or disjoint i64 %v20512, %v13
  %v214 = or disjoint i64 %v2, 224
  %v21513 = lshr i64 %v214, 2
  %v218 = or disjoint i64 %v21513, %v13
  %v22514 = lshr i64 %v2, 4
  %v227 = and i64 %v156, 60
  %v229 = or disjoint i64 %v227, %v14
  %v23615 = lshr i64 %v154, 4
  %v24716 = lshr i64 %v164, 4
  %v25817 = lshr i64 %v174, 4
  %v26918 = lshr i64 %v184, 4
  %v28019 = lshr i64 %v194, 4
  %v29120 = lshr i64 %v204, 4
  %v30221 = lshr i64 %v214, 4
  %.idx = shl nuw nsw i64 %v148, 9
  %1 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx
  %v317 = getelementptr inbounds nuw float, ptr addrspace(1) %1, i64 %v147
  %.idx24 = mul nuw nsw i64 %v111, 80
  %2 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx24
  %v319 = getelementptr inbounds nuw float, ptr addrspace(3) %2, i64 %v147
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v319, ptr addrspace(1) %v317)
  %.idx25 = shl nuw nsw i64 %v158, 9
  %3 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx25
  %v321 = getelementptr inbounds nuw float, ptr addrspace(1) %3, i64 %v157
  %.idx26 = mul nuw nsw i64 %v1553, 80
  %4 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx26
  %v323 = getelementptr inbounds nuw float, ptr addrspace(3) %4, i64 %v157
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v323, ptr addrspace(1) %v321)
  %.idx27 = shl nuw nsw i64 %v168, 9
  %5 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx27
  %v325 = getelementptr inbounds nuw float, ptr addrspace(1) %5, i64 %v157
  %.idx28 = mul nuw nsw i64 %v1655, 80
  %6 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx28
  %v327 = getelementptr inbounds nuw float, ptr addrspace(3) %6, i64 %v157
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v327, ptr addrspace(1) %v325)
  %.idx29 = shl nuw nsw i64 %v178, 9
  %7 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx29
  %v329 = getelementptr inbounds nuw float, ptr addrspace(1) %7, i64 %v157
  %.idx30 = mul nuw nsw i64 %v1757, 80
  %8 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx30
  %v331 = getelementptr inbounds nuw float, ptr addrspace(3) %8, i64 %v157
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v331, ptr addrspace(1) %v329)
  %.idx31 = shl nuw nsw i64 %v188, 9
  %9 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx31
  %v333 = getelementptr inbounds nuw float, ptr addrspace(1) %9, i64 %v157
  %.idx32 = mul nuw nsw i64 %v18510, 80
  %10 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx32
  %v335 = getelementptr inbounds nuw float, ptr addrspace(3) %10, i64 %v157
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v335, ptr addrspace(1) %v333)
  %.idx33 = shl nuw nsw i64 %v198, 9
  %11 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx33
  %v337 = getelementptr inbounds nuw float, ptr addrspace(1) %11, i64 %v157
  %.idx34 = mul nuw nsw i64 %v19511, 80
  %12 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx34
  %v339 = getelementptr inbounds nuw float, ptr addrspace(3) %12, i64 %v157
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v339, ptr addrspace(1) %v337)
  %.idx35 = shl nuw nsw i64 %v208, 9
  %13 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx35
  %v341 = getelementptr inbounds nuw float, ptr addrspace(1) %13, i64 %v157
  %.idx36 = mul nuw nsw i64 %v20512, 80
  %14 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx36
  %v343 = getelementptr inbounds nuw float, ptr addrspace(3) %14, i64 %v157
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v343, ptr addrspace(1) %v341)
  %.idx37 = shl nuw nsw i64 %v218, 9
  %15 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx37
  %v345 = getelementptr inbounds nuw float, ptr addrspace(1) %15, i64 %v157
  %.idx38 = mul nuw nsw i64 %v21513, 80
  %16 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx38
  %v347 = getelementptr inbounds nuw float, ptr addrspace(3) %16, i64 %v157
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v347, ptr addrspace(1) %v345)
  %.idx39 = shl nuw nsw i64 %v22514, 10
  %17 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx39
  %v349 = getelementptr inbounds nuw float, ptr addrspace(1) %17, i64 %v229
  %.idx40 = mul nuw nsw i64 %v22514, 288
  %18 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx40
  %19 = getelementptr inbounds nuw float, ptr addrspace(3) %18, i64 %v227
  %v351 = getelementptr inbounds nuw i8, ptr addrspace(3) %19, i64 5120
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v351, ptr addrspace(1) %v349)
  %.idx41 = shl nuw nsw i64 %v23615, 10
  %20 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx41
  %v353 = getelementptr inbounds nuw float, ptr addrspace(1) %20, i64 %v229
  %.idx42 = mul nuw nsw i64 %v23615, 288
  %21 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx42
  %22 = getelementptr inbounds nuw float, ptr addrspace(3) %21, i64 %v227
  %v355 = getelementptr inbounds nuw i8, ptr addrspace(3) %22, i64 5120
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v355, ptr addrspace(1) nonnull %v353)
  %.idx43 = shl nuw nsw i64 %v24716, 10
  %23 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx43
  %v357 = getelementptr inbounds nuw float, ptr addrspace(1) %23, i64 %v229
  %.idx44 = mul nuw nsw i64 %v24716, 288
  %24 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx44
  %25 = getelementptr inbounds nuw float, ptr addrspace(3) %24, i64 %v227
  %v359 = getelementptr inbounds nuw i8, ptr addrspace(3) %25, i64 5120
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v359, ptr addrspace(1) nonnull %v357)
  %.idx45 = shl nuw nsw i64 %v25817, 10
  %26 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx45
  %v361 = getelementptr inbounds nuw float, ptr addrspace(1) %26, i64 %v229
  %.idx46 = mul nuw nsw i64 %v25817, 288
  %27 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx46
  %28 = getelementptr inbounds nuw float, ptr addrspace(3) %27, i64 %v227
  %v363 = getelementptr inbounds nuw i8, ptr addrspace(3) %28, i64 5120
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v363, ptr addrspace(1) nonnull %v361)
  %.idx47 = shl nuw nsw i64 %v26918, 10
  %29 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx47
  %v365 = getelementptr inbounds nuw float, ptr addrspace(1) %29, i64 %v229
  %.idx48 = mul nuw nsw i64 %v26918, 288
  %30 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx48
  %31 = getelementptr inbounds nuw float, ptr addrspace(3) %30, i64 %v227
  %v367 = getelementptr inbounds nuw i8, ptr addrspace(3) %31, i64 5120
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v367, ptr addrspace(1) nonnull %v365)
  %.idx49 = shl nuw nsw i64 %v28019, 10
  %32 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx49
  %v369 = getelementptr inbounds nuw float, ptr addrspace(1) %32, i64 %v229
  %.idx50 = mul nuw nsw i64 %v28019, 288
  %33 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx50
  %34 = getelementptr inbounds nuw float, ptr addrspace(3) %33, i64 %v227
  %v371 = getelementptr inbounds nuw i8, ptr addrspace(3) %34, i64 5120
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v371, ptr addrspace(1) nonnull %v369)
  %.idx51 = shl nuw nsw i64 %v29120, 10
  %35 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx51
  %v373 = getelementptr inbounds nuw float, ptr addrspace(1) %35, i64 %v229
  %.idx52 = mul nuw nsw i64 %v29120, 288
  %36 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx52
  %37 = getelementptr inbounds nuw float, ptr addrspace(3) %36, i64 %v227
  %v375 = getelementptr inbounds nuw i8, ptr addrspace(3) %37, i64 5120
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v375, ptr addrspace(1) nonnull %v373)
  %.idx53 = shl nuw nsw i64 %v30221, 10
  %38 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx53
  %v377 = getelementptr inbounds nuw float, ptr addrspace(1) %38, i64 %v229
  %.idx54 = mul nuw nsw i64 %v30221, 288
  %39 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx54
  %40 = getelementptr inbounds nuw float, ptr addrspace(3) %39, i64 %v227
  %v379 = getelementptr inbounds nuw i8, ptr addrspace(3) %40, i64 5120
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v379, ptr addrspace(1) nonnull %v377)
  tail call void @llvm.nvvm.cp.async.commit.group()
  %v471 = and i64 %v2, 15
  %v475 = and i64 %v111, 4
  %.idx55 = mul nuw nsw i64 %v471, 80
  %invariant.gep = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx55
  %invariant.gep57 = getelementptr inbounds nuw float, ptr addrspace(3) %invariant.gep, i64 %v475
  %.idx56 = mul nuw nsw i64 %v12, 288
  %invariant.gep59 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx56
  %invariant.gep60 = getelementptr inbounds nuw float, ptr addrspace(3) %invariant.gep59, i64 %v111
  br label %kt

kt:                                               ; preds = %issued, %entry
  %v15.sroa.762.0 = phi float [ 0.000000e+00, %entry ], [ %v1533, %issued ]
  %v15.sroa.756.0 = phi float [ 0.000000e+00, %entry ], [ %v1532, %issued ]
  %v15.sroa.750.0 = phi float [ 0.000000e+00, %entry ], [ %v1531, %issued ]
  %v15.sroa.744.0 = phi float [ 0.000000e+00, %entry ], [ %v1530, %issued ]
  %v15.sroa.738.0 = phi float [ 0.000000e+00, %entry ], [ %v1520, %issued ]
  %v15.sroa.732.0 = phi float [ 0.000000e+00, %entry ], [ %v1519, %issued ]
  %v15.sroa.726.0 = phi float [ 0.000000e+00, %entry ], [ %v1518, %issued ]
  %v15.sroa.720.0 = phi float [ 0.000000e+00, %entry ], [ %v1517, %issued ]
  %v15.sroa.714.0 = phi float [ 0.000000e+00, %entry ], [ %v1507, %issued ]
  %v15.sroa.708.0 = phi float [ 0.000000e+00, %entry ], [ %v1506, %issued ]
  %v15.sroa.702.0 = phi float [ 0.000000e+00, %entry ], [ %v1505, %issued ]
  %v15.sroa.696.0 = phi float [ 0.000000e+00, %entry ], [ %v1504, %issued ]
  %v15.sroa.690.0 = phi float [ 0.000000e+00, %entry ], [ %v1494, %issued ]
  %v15.sroa.684.0 = phi float [ 0.000000e+00, %entry ], [ %v1493, %issued ]
  %v15.sroa.678.0 = phi float [ 0.000000e+00, %entry ], [ %v1492, %issued ]
  %v15.sroa.672.0 = phi float [ 0.000000e+00, %entry ], [ %v1491, %issued ]
  %v15.sroa.666.0 = phi float [ 0.000000e+00, %entry ], [ %v1481, %issued ]
  %v15.sroa.660.0 = phi float [ 0.000000e+00, %entry ], [ %v1480, %issued ]
  %v15.sroa.654.0 = phi float [ 0.000000e+00, %entry ], [ %v1479, %issued ]
  %v15.sroa.648.0 = phi float [ 0.000000e+00, %entry ], [ %v1478, %issued ]
  %v15.sroa.642.0 = phi float [ 0.000000e+00, %entry ], [ %v1468, %issued ]
  %v15.sroa.636.0 = phi float [ 0.000000e+00, %entry ], [ %v1467, %issued ]
  %v15.sroa.630.0 = phi float [ 0.000000e+00, %entry ], [ %v1466, %issued ]
  %v15.sroa.624.0 = phi float [ 0.000000e+00, %entry ], [ %v1465, %issued ]
  %v15.sroa.618.0 = phi float [ 0.000000e+00, %entry ], [ %v1455, %issued ]
  %v15.sroa.612.0 = phi float [ 0.000000e+00, %entry ], [ %v1454, %issued ]
  %v15.sroa.606.0 = phi float [ 0.000000e+00, %entry ], [ %v1453, %issued ]
  %v15.sroa.600.0 = phi float [ 0.000000e+00, %entry ], [ %v1452, %issued ]
  %v15.sroa.594.0 = phi float [ 0.000000e+00, %entry ], [ %v1442, %issued ]
  %v15.sroa.588.0 = phi float [ 0.000000e+00, %entry ], [ %v1441, %issued ]
  %v15.sroa.582.0 = phi float [ 0.000000e+00, %entry ], [ %v1440, %issued ]
  %v15.sroa.576.0 = phi float [ 0.000000e+00, %entry ], [ %v1439, %issued ]
  %v15.sroa.570.0 = phi float [ 0.000000e+00, %entry ], [ %v1429, %issued ]
  %v15.sroa.564.0 = phi float [ 0.000000e+00, %entry ], [ %v1428, %issued ]
  %v15.sroa.558.0 = phi float [ 0.000000e+00, %entry ], [ %v1427, %issued ]
  %v15.sroa.552.0 = phi float [ 0.000000e+00, %entry ], [ %v1426, %issued ]
  %v15.sroa.546.0 = phi float [ 0.000000e+00, %entry ], [ %v1416, %issued ]
  %v15.sroa.540.0 = phi float [ 0.000000e+00, %entry ], [ %v1415, %issued ]
  %v15.sroa.534.0 = phi float [ 0.000000e+00, %entry ], [ %v1414, %issued ]
  %v15.sroa.528.0 = phi float [ 0.000000e+00, %entry ], [ %v1413, %issued ]
  %v15.sroa.522.0 = phi float [ 0.000000e+00, %entry ], [ %v1403, %issued ]
  %v15.sroa.516.0 = phi float [ 0.000000e+00, %entry ], [ %v1402, %issued ]
  %v15.sroa.510.0 = phi float [ 0.000000e+00, %entry ], [ %v1401, %issued ]
  %v15.sroa.504.0 = phi float [ 0.000000e+00, %entry ], [ %v1400, %issued ]
  %v15.sroa.498.0 = phi float [ 0.000000e+00, %entry ], [ %v1390, %issued ]
  %v15.sroa.492.0 = phi float [ 0.000000e+00, %entry ], [ %v1389, %issued ]
  %v15.sroa.486.0 = phi float [ 0.000000e+00, %entry ], [ %v1388, %issued ]
  %v15.sroa.480.0 = phi float [ 0.000000e+00, %entry ], [ %v1387, %issued ]
  %v15.sroa.474.0 = phi float [ 0.000000e+00, %entry ], [ %v1377, %issued ]
  %v15.sroa.468.0 = phi float [ 0.000000e+00, %entry ], [ %v1376, %issued ]
  %v15.sroa.462.0 = phi float [ 0.000000e+00, %entry ], [ %v1375, %issued ]
  %v15.sroa.456.0 = phi float [ 0.000000e+00, %entry ], [ %v1374, %issued ]
  %v15.sroa.450.0 = phi float [ 0.000000e+00, %entry ], [ %v1364, %issued ]
  %v15.sroa.444.0 = phi float [ 0.000000e+00, %entry ], [ %v1363, %issued ]
  %v15.sroa.438.0 = phi float [ 0.000000e+00, %entry ], [ %v1362, %issued ]
  %v15.sroa.432.0 = phi float [ 0.000000e+00, %entry ], [ %v1361, %issued ]
  %v15.sroa.426.0 = phi float [ 0.000000e+00, %entry ], [ %v1351, %issued ]
  %v15.sroa.420.0 = phi float [ 0.000000e+00, %entry ], [ %v1350, %issued ]
  %v15.sroa.414.0 = phi float [ 0.000000e+00, %entry ], [ %v1349, %issued ]
  %v15.sroa.408.0 = phi float [ 0.000000e+00, %entry ], [ %v1348, %issued ]
  %v15.sroa.402.0 = phi float [ 0.000000e+00, %entry ], [ %v1338, %issued ]
  %v15.sroa.396.0 = phi float [ 0.000000e+00, %entry ], [ %v1337, %issued ]
  %v15.sroa.390.0 = phi float [ 0.000000e+00, %entry ], [ %v1336, %issued ]
  %v15.sroa.384.0 = phi float [ 0.000000e+00, %entry ], [ %v1335, %issued ]
  %v15.sroa.378.0 = phi float [ 0.000000e+00, %entry ], [ %v1325, %issued ]
  %v15.sroa.372.0 = phi float [ 0.000000e+00, %entry ], [ %v1324, %issued ]
  %v15.sroa.366.0 = phi float [ 0.000000e+00, %entry ], [ %v1323, %issued ]
  %v15.sroa.360.0 = phi float [ 0.000000e+00, %entry ], [ %v1322, %issued ]
  %v15.sroa.354.0 = phi float [ 0.000000e+00, %entry ], [ %v1312, %issued ]
  %v15.sroa.348.0 = phi float [ 0.000000e+00, %entry ], [ %v1311, %issued ]
  %v15.sroa.342.0 = phi float [ 0.000000e+00, %entry ], [ %v1310, %issued ]
  %v15.sroa.336.0 = phi float [ 0.000000e+00, %entry ], [ %v1309, %issued ]
  %v15.sroa.330.0 = phi float [ 0.000000e+00, %entry ], [ %v1299, %issued ]
  %v15.sroa.324.0 = phi float [ 0.000000e+00, %entry ], [ %v1298, %issued ]
  %v15.sroa.318.0 = phi float [ 0.000000e+00, %entry ], [ %v1297, %issued ]
  %v15.sroa.312.0 = phi float [ 0.000000e+00, %entry ], [ %v1296, %issued ]
  %v15.sroa.306.0 = phi float [ 0.000000e+00, %entry ], [ %v1286, %issued ]
  %v15.sroa.300.0 = phi float [ 0.000000e+00, %entry ], [ %v1285, %issued ]
  %v15.sroa.294.0 = phi float [ 0.000000e+00, %entry ], [ %v1284, %issued ]
  %v15.sroa.288.0 = phi float [ 0.000000e+00, %entry ], [ %v1283, %issued ]
  %v15.sroa.282.0 = phi float [ 0.000000e+00, %entry ], [ %v1273, %issued ]
  %v15.sroa.276.0 = phi float [ 0.000000e+00, %entry ], [ %v1272, %issued ]
  %v15.sroa.270.0 = phi float [ 0.000000e+00, %entry ], [ %v1271, %issued ]
  %v15.sroa.264.0 = phi float [ 0.000000e+00, %entry ], [ %v1270, %issued ]
  %v15.sroa.258.0 = phi float [ 0.000000e+00, %entry ], [ %v1260, %issued ]
  %v15.sroa.252.0 = phi float [ 0.000000e+00, %entry ], [ %v1259, %issued ]
  %v15.sroa.246.0 = phi float [ 0.000000e+00, %entry ], [ %v1258, %issued ]
  %v15.sroa.240.0 = phi float [ 0.000000e+00, %entry ], [ %v1257, %issued ]
  %v15.sroa.234.0 = phi float [ 0.000000e+00, %entry ], [ %v1247, %issued ]
  %v15.sroa.228.0 = phi float [ 0.000000e+00, %entry ], [ %v1246, %issued ]
  %v15.sroa.222.0 = phi float [ 0.000000e+00, %entry ], [ %v1245, %issued ]
  %v15.sroa.216.0 = phi float [ 0.000000e+00, %entry ], [ %v1244, %issued ]
  %v15.sroa.210.0 = phi float [ 0.000000e+00, %entry ], [ %v1234, %issued ]
  %v15.sroa.204.0 = phi float [ 0.000000e+00, %entry ], [ %v1233, %issued ]
  %v15.sroa.198.0 = phi float [ 0.000000e+00, %entry ], [ %v1232, %issued ]
  %v15.sroa.192.0 = phi float [ 0.000000e+00, %entry ], [ %v1231, %issued ]
  %v15.sroa.186.0 = phi float [ 0.000000e+00, %entry ], [ %v1221, %issued ]
  %v15.sroa.180.0 = phi float [ 0.000000e+00, %entry ], [ %v1220, %issued ]
  %v15.sroa.174.0 = phi float [ 0.000000e+00, %entry ], [ %v1219, %issued ]
  %v15.sroa.168.0 = phi float [ 0.000000e+00, %entry ], [ %v1218, %issued ]
  %v15.sroa.162.0 = phi float [ 0.000000e+00, %entry ], [ %v1208, %issued ]
  %v15.sroa.156.0 = phi float [ 0.000000e+00, %entry ], [ %v1207, %issued ]
  %v15.sroa.150.0 = phi float [ 0.000000e+00, %entry ], [ %v1206, %issued ]
  %v15.sroa.144.0 = phi float [ 0.000000e+00, %entry ], [ %v1205, %issued ]
  %v15.sroa.138.0 = phi float [ 0.000000e+00, %entry ], [ %v1195, %issued ]
  %v15.sroa.132.0 = phi float [ 0.000000e+00, %entry ], [ %v1194, %issued ]
  %v15.sroa.126.0 = phi float [ 0.000000e+00, %entry ], [ %v1193, %issued ]
  %v15.sroa.120.0 = phi float [ 0.000000e+00, %entry ], [ %v1192, %issued ]
  %v15.sroa.114.0 = phi float [ 0.000000e+00, %entry ], [ %v1182, %issued ]
  %v15.sroa.108.0 = phi float [ 0.000000e+00, %entry ], [ %v1181, %issued ]
  %v15.sroa.102.0 = phi float [ 0.000000e+00, %entry ], [ %v1180, %issued ]
  %v15.sroa.96.0 = phi float [ 0.000000e+00, %entry ], [ %v1179, %issued ]
  %v15.sroa.90.0 = phi float [ 0.000000e+00, %entry ], [ %v1169, %issued ]
  %v15.sroa.84.0 = phi float [ 0.000000e+00, %entry ], [ %v1168, %issued ]
  %v15.sroa.78.0 = phi float [ 0.000000e+00, %entry ], [ %v1167, %issued ]
  %v15.sroa.72.0 = phi float [ 0.000000e+00, %entry ], [ %v1166, %issued ]
  %v15.sroa.66.0 = phi float [ 0.000000e+00, %entry ], [ %v1156, %issued ]
  %v15.sroa.60.0 = phi float [ 0.000000e+00, %entry ], [ %v1155, %issued ]
  %v15.sroa.54.0 = phi float [ 0.000000e+00, %entry ], [ %v1154, %issued ]
  %v15.sroa.48.0 = phi float [ 0.000000e+00, %entry ], [ %v1153, %issued ]
  %v15.sroa.42.0 = phi float [ 0.000000e+00, %entry ], [ %v1143, %issued ]
  %v15.sroa.36.0 = phi float [ 0.000000e+00, %entry ], [ %v1142, %issued ]
  %v15.sroa.30.0 = phi float [ 0.000000e+00, %entry ], [ %v1141, %issued ]
  %v15.sroa.24.0 = phi float [ 0.000000e+00, %entry ], [ %v1140, %issued ]
  %v15.sroa.18.0 = phi float [ 0.000000e+00, %entry ], [ %v1130, %issued ]
  %v15.sroa.12.0 = phi float [ 0.000000e+00, %entry ], [ %v1129, %issued ]
  %v15.sroa.6.0 = phi float [ 0.000000e+00, %entry ], [ %v1128, %issued ]
  %v15.sroa.0.0 = phi float [ 0.000000e+00, %entry ], [ %v1127, %issued ]
  %v389 = phi i64 [ 0, %entry ], [ %v391, %issued ]
  tail call void @llvm.nvvm.cp.async.wait.group(i32 0)
  tail call void @llvm.nvvm.barrier.cta.sync.aligned.all(i32 0)
  %v391 = add nuw nsw i64 %v389, 1
  %v392 = icmp samesign ult i64 %v389, 7
  br i1 %v392, label %issue, label %issued

issue:                                            ; preds = %kt
  %v394 = shl nuw nsw i64 %v391, 4
  %v396 = shl nuw nsw i64 %v391, 12
  %41 = trunc i64 %v391 to i1
  %v397 = select i1 %41, i64 2432, i64 0
  %v399 = getelementptr inbounds nuw float, ptr addrspace(1) %v317, i64 %v394
  %v401 = getelementptr inbounds nuw float, ptr addrspace(3) %v319, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v401, ptr addrspace(1) nonnull %v399)
  %v403 = getelementptr inbounds nuw float, ptr addrspace(1) %v321, i64 %v394
  %v405 = getelementptr inbounds nuw float, ptr addrspace(3) %v323, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v405, ptr addrspace(1) nonnull %v403)
  %v407 = getelementptr inbounds nuw float, ptr addrspace(1) %v325, i64 %v394
  %v409 = getelementptr inbounds nuw float, ptr addrspace(3) %v327, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v409, ptr addrspace(1) nonnull %v407)
  %v411 = getelementptr inbounds nuw float, ptr addrspace(1) %v329, i64 %v394
  %v413 = getelementptr inbounds nuw float, ptr addrspace(3) %v331, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v413, ptr addrspace(1) nonnull %v411)
  %v415 = getelementptr inbounds nuw float, ptr addrspace(1) %v333, i64 %v394
  %v417 = getelementptr inbounds nuw float, ptr addrspace(3) %v335, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v417, ptr addrspace(1) nonnull %v415)
  %v419 = getelementptr inbounds nuw float, ptr addrspace(1) %v337, i64 %v394
  %v421 = getelementptr inbounds nuw float, ptr addrspace(3) %v339, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v421, ptr addrspace(1) nonnull %v419)
  %v423 = getelementptr inbounds nuw float, ptr addrspace(1) %v341, i64 %v394
  %v425 = getelementptr inbounds nuw float, ptr addrspace(3) %v343, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v425, ptr addrspace(1) nonnull %v423)
  %v427 = getelementptr inbounds nuw float, ptr addrspace(1) %v345, i64 %v394
  %v429 = getelementptr inbounds nuw float, ptr addrspace(3) %v347, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v429, ptr addrspace(1) nonnull %v427)
  %v431 = getelementptr inbounds nuw float, ptr addrspace(1) %v349, i64 %v396
  %v433 = getelementptr inbounds nuw float, ptr addrspace(3) %v351, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v433, ptr addrspace(1) nonnull %v431)
  %v435 = getelementptr inbounds nuw float, ptr addrspace(1) %v353, i64 %v396
  %v437 = getelementptr inbounds nuw float, ptr addrspace(3) %v355, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v437, ptr addrspace(1) nonnull %v435)
  %v439 = getelementptr inbounds nuw float, ptr addrspace(1) %v357, i64 %v396
  %v441 = getelementptr inbounds nuw float, ptr addrspace(3) %v359, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v441, ptr addrspace(1) nonnull %v439)
  %v443 = getelementptr inbounds nuw float, ptr addrspace(1) %v361, i64 %v396
  %v445 = getelementptr inbounds nuw float, ptr addrspace(3) %v363, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v445, ptr addrspace(1) nonnull %v443)
  %v447 = getelementptr inbounds nuw float, ptr addrspace(1) %v365, i64 %v396
  %v449 = getelementptr inbounds nuw float, ptr addrspace(3) %v367, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v449, ptr addrspace(1) nonnull %v447)
  %v451 = getelementptr inbounds nuw float, ptr addrspace(1) %v369, i64 %v396
  %v453 = getelementptr inbounds nuw float, ptr addrspace(3) %v371, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v453, ptr addrspace(1) nonnull %v451)
  %v455 = getelementptr inbounds nuw float, ptr addrspace(1) %v373, i64 %v396
  %v457 = getelementptr inbounds nuw float, ptr addrspace(3) %v375, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v457, ptr addrspace(1) nonnull %v455)
  %v459 = getelementptr inbounds nuw float, ptr addrspace(1) %v377, i64 %v396
  %v461 = getelementptr inbounds nuw float, ptr addrspace(3) %v379, i64 %v397
  tail call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) nonnull %v461, ptr addrspace(1) nonnull %v459)
  br label %issued

issued:                                           ; preds = %issue, %kt
  tail call void @llvm.nvvm.cp.async.commit.group()
  %42 = trunc i64 %v389 to i1
  %v463 = select i1 %42, i64 2432, i64 0
  %gep58 = getelementptr inbounds nuw float, ptr addrspace(3) %invariant.gep57, i64 %v463
  %43 = ptrtoint ptr addrspace(3) %gep58 to i64
  %v480 = trunc i64 %43 to i32
  %v481 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v480) #2
  %v482 = extractvalue { i32, i32, i32, i32 } %v481, 0
  %v483 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v482) #2
  %v484 = extractvalue { i32, i32, i32, i32 } %v481, 1
  %v485 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v484) #2
  %v486 = extractvalue { i32, i32, i32, i32 } %v481, 2
  %v487 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v486) #2
  %v488 = extractvalue { i32, i32, i32, i32 } %v481, 3
  %v489 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v488) #2
  %v491 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep58, i64 1280
  %44 = ptrtoint ptr addrspace(3) %v491 to i64
  %v492 = trunc i64 %44 to i32
  %v493 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v492) #2
  %v494 = extractvalue { i32, i32, i32, i32 } %v493, 0
  %v495 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v494) #2
  %v496 = extractvalue { i32, i32, i32, i32 } %v493, 1
  %v497 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v496) #2
  %v498 = extractvalue { i32, i32, i32, i32 } %v493, 2
  %v499 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v498) #2
  %v500 = extractvalue { i32, i32, i32, i32 } %v493, 3
  %v501 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v500) #2
  %v503 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep58, i64 2560
  %45 = ptrtoint ptr addrspace(3) %v503 to i64
  %v504 = trunc i64 %45 to i32
  %v505 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v504) #2
  %v506 = extractvalue { i32, i32, i32, i32 } %v505, 0
  %v507 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v506) #2
  %v508 = extractvalue { i32, i32, i32, i32 } %v505, 1
  %v509 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v508) #2
  %v510 = extractvalue { i32, i32, i32, i32 } %v505, 2
  %v511 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v510) #2
  %v512 = extractvalue { i32, i32, i32, i32 } %v505, 3
  %v513 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v512) #2
  %v515 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep58, i64 3840
  %46 = ptrtoint ptr addrspace(3) %v515 to i64
  %v516 = trunc i64 %46 to i32
  %v517 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v516) #2
  %v518 = extractvalue { i32, i32, i32, i32 } %v517, 0
  %v519 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v518) #2
  %v520 = extractvalue { i32, i32, i32, i32 } %v517, 1
  %v521 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v520) #2
  %v522 = extractvalue { i32, i32, i32, i32 } %v517, 2
  %v523 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v522) #2
  %v524 = extractvalue { i32, i32, i32, i32 } %v517, 3
  %v525 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v524) #2
  %gep61 = getelementptr inbounds nuw float, ptr addrspace(3) %invariant.gep60, i64 %v463
  %v527 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 5120
  %v528 = load float, ptr addrspace(3) %v527, align 4
  %v529 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v528) #2
  %v531 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 6272
  %v532 = load float, ptr addrspace(3) %v531, align 4
  %v533 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v532) #2
  %v535 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 5152
  %v536 = load float, ptr addrspace(3) %v535, align 4
  %v537 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v536) #2
  %v539 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 6304
  %v540 = load float, ptr addrspace(3) %v539, align 4
  %v541 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v540) #2
  %v543 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 5184
  %v544 = load float, ptr addrspace(3) %v543, align 4
  %v545 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v544) #2
  %v547 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 6336
  %v548 = load float, ptr addrspace(3) %v547, align 4
  %v549 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v548) #2
  %v551 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 5216
  %v552 = load float, ptr addrspace(3) %v551, align 4
  %v553 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v552) #2
  %v555 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 6368
  %v556 = load float, ptr addrspace(3) %v555, align 4
  %v557 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v556) #2
  %v559 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 5248
  %v560 = load float, ptr addrspace(3) %v559, align 4
  %v561 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v560) #2
  %v563 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 6400
  %v564 = load float, ptr addrspace(3) %v563, align 4
  %v565 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v564) #2
  %v567 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 5280
  %v568 = load float, ptr addrspace(3) %v567, align 4
  %v569 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v568) #2
  %v571 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 6432
  %v572 = load float, ptr addrspace(3) %v571, align 4
  %v573 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v572) #2
  %v575 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 5312
  %v576 = load float, ptr addrspace(3) %v575, align 4
  %v577 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v576) #2
  %v579 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 6464
  %v580 = load float, ptr addrspace(3) %v579, align 4
  %v581 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v580) #2
  %v583 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 5344
  %v584 = load float, ptr addrspace(3) %v583, align 4
  %v585 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v584) #2
  %v587 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 6496
  %v588 = load float, ptr addrspace(3) %v587, align 4
  %v589 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v588) #2
  %v598 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v483, i32 %v485, i32 %v487, i32 %v489, i32 %v529, i32 %v533, float %v15.sroa.0.0, float %v15.sroa.6.0, float %v15.sroa.12.0, float %v15.sroa.18.0) #2
  %v599 = extractvalue { float, float, float, float } %v598, 0
  %v600 = extractvalue { float, float, float, float } %v598, 1
  %v601 = extractvalue { float, float, float, float } %v598, 2
  %v602 = extractvalue { float, float, float, float } %v598, 3
  %v611 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v483, i32 %v485, i32 %v487, i32 %v489, i32 %v537, i32 %v541, float %v15.sroa.24.0, float %v15.sroa.30.0, float %v15.sroa.36.0, float %v15.sroa.42.0) #2
  %v612 = extractvalue { float, float, float, float } %v611, 0
  %v613 = extractvalue { float, float, float, float } %v611, 1
  %v614 = extractvalue { float, float, float, float } %v611, 2
  %v615 = extractvalue { float, float, float, float } %v611, 3
  %v624 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v483, i32 %v485, i32 %v487, i32 %v489, i32 %v545, i32 %v549, float %v15.sroa.48.0, float %v15.sroa.54.0, float %v15.sroa.60.0, float %v15.sroa.66.0) #2
  %v625 = extractvalue { float, float, float, float } %v624, 0
  %v626 = extractvalue { float, float, float, float } %v624, 1
  %v627 = extractvalue { float, float, float, float } %v624, 2
  %v628 = extractvalue { float, float, float, float } %v624, 3
  %v637 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v483, i32 %v485, i32 %v487, i32 %v489, i32 %v553, i32 %v557, float %v15.sroa.72.0, float %v15.sroa.78.0, float %v15.sroa.84.0, float %v15.sroa.90.0) #2
  %v638 = extractvalue { float, float, float, float } %v637, 0
  %v639 = extractvalue { float, float, float, float } %v637, 1
  %v640 = extractvalue { float, float, float, float } %v637, 2
  %v641 = extractvalue { float, float, float, float } %v637, 3
  %v650 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v483, i32 %v485, i32 %v487, i32 %v489, i32 %v561, i32 %v565, float %v15.sroa.96.0, float %v15.sroa.102.0, float %v15.sroa.108.0, float %v15.sroa.114.0) #2
  %v651 = extractvalue { float, float, float, float } %v650, 0
  %v652 = extractvalue { float, float, float, float } %v650, 1
  %v653 = extractvalue { float, float, float, float } %v650, 2
  %v654 = extractvalue { float, float, float, float } %v650, 3
  %v663 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v483, i32 %v485, i32 %v487, i32 %v489, i32 %v569, i32 %v573, float %v15.sroa.120.0, float %v15.sroa.126.0, float %v15.sroa.132.0, float %v15.sroa.138.0) #2
  %v664 = extractvalue { float, float, float, float } %v663, 0
  %v665 = extractvalue { float, float, float, float } %v663, 1
  %v666 = extractvalue { float, float, float, float } %v663, 2
  %v667 = extractvalue { float, float, float, float } %v663, 3
  %v676 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v483, i32 %v485, i32 %v487, i32 %v489, i32 %v577, i32 %v581, float %v15.sroa.144.0, float %v15.sroa.150.0, float %v15.sroa.156.0, float %v15.sroa.162.0) #2
  %v677 = extractvalue { float, float, float, float } %v676, 0
  %v678 = extractvalue { float, float, float, float } %v676, 1
  %v679 = extractvalue { float, float, float, float } %v676, 2
  %v680 = extractvalue { float, float, float, float } %v676, 3
  %v689 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v483, i32 %v485, i32 %v487, i32 %v489, i32 %v585, i32 %v589, float %v15.sroa.168.0, float %v15.sroa.174.0, float %v15.sroa.180.0, float %v15.sroa.186.0) #2
  %v690 = extractvalue { float, float, float, float } %v689, 0
  %v691 = extractvalue { float, float, float, float } %v689, 1
  %v692 = extractvalue { float, float, float, float } %v689, 2
  %v693 = extractvalue { float, float, float, float } %v689, 3
  %v702 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v495, i32 %v497, i32 %v499, i32 %v501, i32 %v529, i32 %v533, float %v15.sroa.192.0, float %v15.sroa.198.0, float %v15.sroa.204.0, float %v15.sroa.210.0) #2
  %v703 = extractvalue { float, float, float, float } %v702, 0
  %v704 = extractvalue { float, float, float, float } %v702, 1
  %v705 = extractvalue { float, float, float, float } %v702, 2
  %v706 = extractvalue { float, float, float, float } %v702, 3
  %v715 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v495, i32 %v497, i32 %v499, i32 %v501, i32 %v537, i32 %v541, float %v15.sroa.216.0, float %v15.sroa.222.0, float %v15.sroa.228.0, float %v15.sroa.234.0) #2
  %v716 = extractvalue { float, float, float, float } %v715, 0
  %v717 = extractvalue { float, float, float, float } %v715, 1
  %v718 = extractvalue { float, float, float, float } %v715, 2
  %v719 = extractvalue { float, float, float, float } %v715, 3
  %v728 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v495, i32 %v497, i32 %v499, i32 %v501, i32 %v545, i32 %v549, float %v15.sroa.240.0, float %v15.sroa.246.0, float %v15.sroa.252.0, float %v15.sroa.258.0) #2
  %v729 = extractvalue { float, float, float, float } %v728, 0
  %v730 = extractvalue { float, float, float, float } %v728, 1
  %v731 = extractvalue { float, float, float, float } %v728, 2
  %v732 = extractvalue { float, float, float, float } %v728, 3
  %v741 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v495, i32 %v497, i32 %v499, i32 %v501, i32 %v553, i32 %v557, float %v15.sroa.264.0, float %v15.sroa.270.0, float %v15.sroa.276.0, float %v15.sroa.282.0) #2
  %v742 = extractvalue { float, float, float, float } %v741, 0
  %v743 = extractvalue { float, float, float, float } %v741, 1
  %v744 = extractvalue { float, float, float, float } %v741, 2
  %v745 = extractvalue { float, float, float, float } %v741, 3
  %v754 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v495, i32 %v497, i32 %v499, i32 %v501, i32 %v561, i32 %v565, float %v15.sroa.288.0, float %v15.sroa.294.0, float %v15.sroa.300.0, float %v15.sroa.306.0) #2
  %v755 = extractvalue { float, float, float, float } %v754, 0
  %v756 = extractvalue { float, float, float, float } %v754, 1
  %v757 = extractvalue { float, float, float, float } %v754, 2
  %v758 = extractvalue { float, float, float, float } %v754, 3
  %v767 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v495, i32 %v497, i32 %v499, i32 %v501, i32 %v569, i32 %v573, float %v15.sroa.312.0, float %v15.sroa.318.0, float %v15.sroa.324.0, float %v15.sroa.330.0) #2
  %v768 = extractvalue { float, float, float, float } %v767, 0
  %v769 = extractvalue { float, float, float, float } %v767, 1
  %v770 = extractvalue { float, float, float, float } %v767, 2
  %v771 = extractvalue { float, float, float, float } %v767, 3
  %v780 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v495, i32 %v497, i32 %v499, i32 %v501, i32 %v577, i32 %v581, float %v15.sroa.336.0, float %v15.sroa.342.0, float %v15.sroa.348.0, float %v15.sroa.354.0) #2
  %v781 = extractvalue { float, float, float, float } %v780, 0
  %v782 = extractvalue { float, float, float, float } %v780, 1
  %v783 = extractvalue { float, float, float, float } %v780, 2
  %v784 = extractvalue { float, float, float, float } %v780, 3
  %v793 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v495, i32 %v497, i32 %v499, i32 %v501, i32 %v585, i32 %v589, float %v15.sroa.360.0, float %v15.sroa.366.0, float %v15.sroa.372.0, float %v15.sroa.378.0) #2
  %v794 = extractvalue { float, float, float, float } %v793, 0
  %v795 = extractvalue { float, float, float, float } %v793, 1
  %v796 = extractvalue { float, float, float, float } %v793, 2
  %v797 = extractvalue { float, float, float, float } %v793, 3
  %v806 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v507, i32 %v509, i32 %v511, i32 %v513, i32 %v529, i32 %v533, float %v15.sroa.384.0, float %v15.sroa.390.0, float %v15.sroa.396.0, float %v15.sroa.402.0) #2
  %v807 = extractvalue { float, float, float, float } %v806, 0
  %v808 = extractvalue { float, float, float, float } %v806, 1
  %v809 = extractvalue { float, float, float, float } %v806, 2
  %v810 = extractvalue { float, float, float, float } %v806, 3
  %v819 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v507, i32 %v509, i32 %v511, i32 %v513, i32 %v537, i32 %v541, float %v15.sroa.408.0, float %v15.sroa.414.0, float %v15.sroa.420.0, float %v15.sroa.426.0) #2
  %v820 = extractvalue { float, float, float, float } %v819, 0
  %v821 = extractvalue { float, float, float, float } %v819, 1
  %v822 = extractvalue { float, float, float, float } %v819, 2
  %v823 = extractvalue { float, float, float, float } %v819, 3
  %v832 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v507, i32 %v509, i32 %v511, i32 %v513, i32 %v545, i32 %v549, float %v15.sroa.432.0, float %v15.sroa.438.0, float %v15.sroa.444.0, float %v15.sroa.450.0) #2
  %v833 = extractvalue { float, float, float, float } %v832, 0
  %v834 = extractvalue { float, float, float, float } %v832, 1
  %v835 = extractvalue { float, float, float, float } %v832, 2
  %v836 = extractvalue { float, float, float, float } %v832, 3
  %v845 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v507, i32 %v509, i32 %v511, i32 %v513, i32 %v553, i32 %v557, float %v15.sroa.456.0, float %v15.sroa.462.0, float %v15.sroa.468.0, float %v15.sroa.474.0) #2
  %v846 = extractvalue { float, float, float, float } %v845, 0
  %v847 = extractvalue { float, float, float, float } %v845, 1
  %v848 = extractvalue { float, float, float, float } %v845, 2
  %v849 = extractvalue { float, float, float, float } %v845, 3
  %v858 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v507, i32 %v509, i32 %v511, i32 %v513, i32 %v561, i32 %v565, float %v15.sroa.480.0, float %v15.sroa.486.0, float %v15.sroa.492.0, float %v15.sroa.498.0) #2
  %v859 = extractvalue { float, float, float, float } %v858, 0
  %v860 = extractvalue { float, float, float, float } %v858, 1
  %v861 = extractvalue { float, float, float, float } %v858, 2
  %v862 = extractvalue { float, float, float, float } %v858, 3
  %v871 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v507, i32 %v509, i32 %v511, i32 %v513, i32 %v569, i32 %v573, float %v15.sroa.504.0, float %v15.sroa.510.0, float %v15.sroa.516.0, float %v15.sroa.522.0) #2
  %v872 = extractvalue { float, float, float, float } %v871, 0
  %v873 = extractvalue { float, float, float, float } %v871, 1
  %v874 = extractvalue { float, float, float, float } %v871, 2
  %v875 = extractvalue { float, float, float, float } %v871, 3
  %v884 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v507, i32 %v509, i32 %v511, i32 %v513, i32 %v577, i32 %v581, float %v15.sroa.528.0, float %v15.sroa.534.0, float %v15.sroa.540.0, float %v15.sroa.546.0) #2
  %v885 = extractvalue { float, float, float, float } %v884, 0
  %v886 = extractvalue { float, float, float, float } %v884, 1
  %v887 = extractvalue { float, float, float, float } %v884, 2
  %v888 = extractvalue { float, float, float, float } %v884, 3
  %v897 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v507, i32 %v509, i32 %v511, i32 %v513, i32 %v585, i32 %v589, float %v15.sroa.552.0, float %v15.sroa.558.0, float %v15.sroa.564.0, float %v15.sroa.570.0) #2
  %v898 = extractvalue { float, float, float, float } %v897, 0
  %v899 = extractvalue { float, float, float, float } %v897, 1
  %v900 = extractvalue { float, float, float, float } %v897, 2
  %v901 = extractvalue { float, float, float, float } %v897, 3
  %v910 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v519, i32 %v521, i32 %v523, i32 %v525, i32 %v529, i32 %v533, float %v15.sroa.576.0, float %v15.sroa.582.0, float %v15.sroa.588.0, float %v15.sroa.594.0) #2
  %v911 = extractvalue { float, float, float, float } %v910, 0
  %v912 = extractvalue { float, float, float, float } %v910, 1
  %v913 = extractvalue { float, float, float, float } %v910, 2
  %v914 = extractvalue { float, float, float, float } %v910, 3
  %v923 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v519, i32 %v521, i32 %v523, i32 %v525, i32 %v537, i32 %v541, float %v15.sroa.600.0, float %v15.sroa.606.0, float %v15.sroa.612.0, float %v15.sroa.618.0) #2
  %v924 = extractvalue { float, float, float, float } %v923, 0
  %v925 = extractvalue { float, float, float, float } %v923, 1
  %v926 = extractvalue { float, float, float, float } %v923, 2
  %v927 = extractvalue { float, float, float, float } %v923, 3
  %v936 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v519, i32 %v521, i32 %v523, i32 %v525, i32 %v545, i32 %v549, float %v15.sroa.624.0, float %v15.sroa.630.0, float %v15.sroa.636.0, float %v15.sroa.642.0) #2
  %v937 = extractvalue { float, float, float, float } %v936, 0
  %v938 = extractvalue { float, float, float, float } %v936, 1
  %v939 = extractvalue { float, float, float, float } %v936, 2
  %v940 = extractvalue { float, float, float, float } %v936, 3
  %v949 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v519, i32 %v521, i32 %v523, i32 %v525, i32 %v553, i32 %v557, float %v15.sroa.648.0, float %v15.sroa.654.0, float %v15.sroa.660.0, float %v15.sroa.666.0) #2
  %v950 = extractvalue { float, float, float, float } %v949, 0
  %v951 = extractvalue { float, float, float, float } %v949, 1
  %v952 = extractvalue { float, float, float, float } %v949, 2
  %v953 = extractvalue { float, float, float, float } %v949, 3
  %v962 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v519, i32 %v521, i32 %v523, i32 %v525, i32 %v561, i32 %v565, float %v15.sroa.672.0, float %v15.sroa.678.0, float %v15.sroa.684.0, float %v15.sroa.690.0) #2
  %v963 = extractvalue { float, float, float, float } %v962, 0
  %v964 = extractvalue { float, float, float, float } %v962, 1
  %v965 = extractvalue { float, float, float, float } %v962, 2
  %v966 = extractvalue { float, float, float, float } %v962, 3
  %v975 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v519, i32 %v521, i32 %v523, i32 %v525, i32 %v569, i32 %v573, float %v15.sroa.696.0, float %v15.sroa.702.0, float %v15.sroa.708.0, float %v15.sroa.714.0) #2
  %v976 = extractvalue { float, float, float, float } %v975, 0
  %v977 = extractvalue { float, float, float, float } %v975, 1
  %v978 = extractvalue { float, float, float, float } %v975, 2
  %v979 = extractvalue { float, float, float, float } %v975, 3
  %v988 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v519, i32 %v521, i32 %v523, i32 %v525, i32 %v577, i32 %v581, float %v15.sroa.720.0, float %v15.sroa.726.0, float %v15.sroa.732.0, float %v15.sroa.738.0) #2
  %v989 = extractvalue { float, float, float, float } %v988, 0
  %v990 = extractvalue { float, float, float, float } %v988, 1
  %v991 = extractvalue { float, float, float, float } %v988, 2
  %v992 = extractvalue { float, float, float, float } %v988, 3
  %v1001 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v519, i32 %v521, i32 %v523, i32 %v525, i32 %v585, i32 %v589, float %v15.sroa.744.0, float %v15.sroa.750.0, float %v15.sroa.756.0, float %v15.sroa.762.0) #2
  %v1002 = extractvalue { float, float, float, float } %v1001, 0
  %v1003 = extractvalue { float, float, float, float } %v1001, 1
  %v1004 = extractvalue { float, float, float, float } %v1001, 2
  %v1005 = extractvalue { float, float, float, float } %v1001, 3
  %v1007 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep58, i64 32
  %47 = ptrtoint ptr addrspace(3) %v1007 to i64
  %v1008 = trunc i64 %47 to i32
  %v1009 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v1008) #2
  %v1010 = extractvalue { i32, i32, i32, i32 } %v1009, 0
  %v1011 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1010) #2
  %v1012 = extractvalue { i32, i32, i32, i32 } %v1009, 1
  %v1013 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1012) #2
  %v1014 = extractvalue { i32, i32, i32, i32 } %v1009, 2
  %v1015 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1014) #2
  %v1016 = extractvalue { i32, i32, i32, i32 } %v1009, 3
  %v1017 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1016) #2
  %v1019 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep58, i64 1312
  %48 = ptrtoint ptr addrspace(3) %v1019 to i64
  %v1020 = trunc i64 %48 to i32
  %v1021 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v1020) #2
  %v1022 = extractvalue { i32, i32, i32, i32 } %v1021, 0
  %v1023 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1022) #2
  %v1024 = extractvalue { i32, i32, i32, i32 } %v1021, 1
  %v1025 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1024) #2
  %v1026 = extractvalue { i32, i32, i32, i32 } %v1021, 2
  %v1027 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1026) #2
  %v1028 = extractvalue { i32, i32, i32, i32 } %v1021, 3
  %v1029 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1028) #2
  %v1031 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep58, i64 2592
  %49 = ptrtoint ptr addrspace(3) %v1031 to i64
  %v1032 = trunc i64 %49 to i32
  %v1033 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v1032) #2
  %v1034 = extractvalue { i32, i32, i32, i32 } %v1033, 0
  %v1035 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1034) #2
  %v1036 = extractvalue { i32, i32, i32, i32 } %v1033, 1
  %v1037 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1036) #2
  %v1038 = extractvalue { i32, i32, i32, i32 } %v1033, 2
  %v1039 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1038) #2
  %v1040 = extractvalue { i32, i32, i32, i32 } %v1033, 3
  %v1041 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1040) #2
  %v1043 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep58, i64 3872
  %50 = ptrtoint ptr addrspace(3) %v1043 to i64
  %v1044 = trunc i64 %50 to i32
  %v1045 = tail call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v1044) #2
  %v1046 = extractvalue { i32, i32, i32, i32 } %v1045, 0
  %v1047 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1046) #2
  %v1048 = extractvalue { i32, i32, i32, i32 } %v1045, 1
  %v1049 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1048) #2
  %v1050 = extractvalue { i32, i32, i32, i32 } %v1045, 2
  %v1051 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1050) #2
  %v1052 = extractvalue { i32, i32, i32, i32 } %v1045, 3
  %v1053 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v1052) #2
  %v1055 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 7424
  %v1056 = load float, ptr addrspace(3) %v1055, align 4
  %v1057 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1056) #2
  %v1059 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 8576
  %v1060 = load float, ptr addrspace(3) %v1059, align 4
  %v1061 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1060) #2
  %v1063 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 7456
  %v1064 = load float, ptr addrspace(3) %v1063, align 4
  %v1065 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1064) #2
  %v1067 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 8608
  %v1068 = load float, ptr addrspace(3) %v1067, align 4
  %v1069 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1068) #2
  %v1071 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 7488
  %v1072 = load float, ptr addrspace(3) %v1071, align 4
  %v1073 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1072) #2
  %v1075 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 8640
  %v1076 = load float, ptr addrspace(3) %v1075, align 4
  %v1077 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1076) #2
  %v1079 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 7520
  %v1080 = load float, ptr addrspace(3) %v1079, align 4
  %v1081 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1080) #2
  %v1083 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 8672
  %v1084 = load float, ptr addrspace(3) %v1083, align 4
  %v1085 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1084) #2
  %v1087 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 7552
  %v1088 = load float, ptr addrspace(3) %v1087, align 4
  %v1089 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1088) #2
  %v1091 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 8704
  %v1092 = load float, ptr addrspace(3) %v1091, align 4
  %v1093 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1092) #2
  %v1095 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 7584
  %v1096 = load float, ptr addrspace(3) %v1095, align 4
  %v1097 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1096) #2
  %v1099 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 8736
  %v1100 = load float, ptr addrspace(3) %v1099, align 4
  %v1101 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1100) #2
  %v1103 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 7616
  %v1104 = load float, ptr addrspace(3) %v1103, align 4
  %v1105 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1104) #2
  %v1107 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 8768
  %v1108 = load float, ptr addrspace(3) %v1107, align 4
  %v1109 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1108) #2
  %v1111 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 7648
  %v1112 = load float, ptr addrspace(3) %v1111, align 4
  %v1113 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1112) #2
  %v1115 = getelementptr inbounds nuw i8, ptr addrspace(3) %gep61, i64 8800
  %v1116 = load float, ptr addrspace(3) %v1115, align 4
  %v1117 = tail call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v1116) #2
  %v1126 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1011, i32 %v1013, i32 %v1015, i32 %v1017, i32 %v1057, i32 %v1061, float %v599, float %v600, float %v601, float %v602) #2
  %v1127 = extractvalue { float, float, float, float } %v1126, 0
  %v1128 = extractvalue { float, float, float, float } %v1126, 1
  %v1129 = extractvalue { float, float, float, float } %v1126, 2
  %v1130 = extractvalue { float, float, float, float } %v1126, 3
  %v1139 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1011, i32 %v1013, i32 %v1015, i32 %v1017, i32 %v1065, i32 %v1069, float %v612, float %v613, float %v614, float %v615) #2
  %v1140 = extractvalue { float, float, float, float } %v1139, 0
  %v1141 = extractvalue { float, float, float, float } %v1139, 1
  %v1142 = extractvalue { float, float, float, float } %v1139, 2
  %v1143 = extractvalue { float, float, float, float } %v1139, 3
  %v1152 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1011, i32 %v1013, i32 %v1015, i32 %v1017, i32 %v1073, i32 %v1077, float %v625, float %v626, float %v627, float %v628) #2
  %v1153 = extractvalue { float, float, float, float } %v1152, 0
  %v1154 = extractvalue { float, float, float, float } %v1152, 1
  %v1155 = extractvalue { float, float, float, float } %v1152, 2
  %v1156 = extractvalue { float, float, float, float } %v1152, 3
  %v1165 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1011, i32 %v1013, i32 %v1015, i32 %v1017, i32 %v1081, i32 %v1085, float %v638, float %v639, float %v640, float %v641) #2
  %v1166 = extractvalue { float, float, float, float } %v1165, 0
  %v1167 = extractvalue { float, float, float, float } %v1165, 1
  %v1168 = extractvalue { float, float, float, float } %v1165, 2
  %v1169 = extractvalue { float, float, float, float } %v1165, 3
  %v1178 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1011, i32 %v1013, i32 %v1015, i32 %v1017, i32 %v1089, i32 %v1093, float %v651, float %v652, float %v653, float %v654) #2
  %v1179 = extractvalue { float, float, float, float } %v1178, 0
  %v1180 = extractvalue { float, float, float, float } %v1178, 1
  %v1181 = extractvalue { float, float, float, float } %v1178, 2
  %v1182 = extractvalue { float, float, float, float } %v1178, 3
  %v1191 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1011, i32 %v1013, i32 %v1015, i32 %v1017, i32 %v1097, i32 %v1101, float %v664, float %v665, float %v666, float %v667) #2
  %v1192 = extractvalue { float, float, float, float } %v1191, 0
  %v1193 = extractvalue { float, float, float, float } %v1191, 1
  %v1194 = extractvalue { float, float, float, float } %v1191, 2
  %v1195 = extractvalue { float, float, float, float } %v1191, 3
  %v1204 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1011, i32 %v1013, i32 %v1015, i32 %v1017, i32 %v1105, i32 %v1109, float %v677, float %v678, float %v679, float %v680) #2
  %v1205 = extractvalue { float, float, float, float } %v1204, 0
  %v1206 = extractvalue { float, float, float, float } %v1204, 1
  %v1207 = extractvalue { float, float, float, float } %v1204, 2
  %v1208 = extractvalue { float, float, float, float } %v1204, 3
  %v1217 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1011, i32 %v1013, i32 %v1015, i32 %v1017, i32 %v1113, i32 %v1117, float %v690, float %v691, float %v692, float %v693) #2
  %v1218 = extractvalue { float, float, float, float } %v1217, 0
  %v1219 = extractvalue { float, float, float, float } %v1217, 1
  %v1220 = extractvalue { float, float, float, float } %v1217, 2
  %v1221 = extractvalue { float, float, float, float } %v1217, 3
  %v1230 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1023, i32 %v1025, i32 %v1027, i32 %v1029, i32 %v1057, i32 %v1061, float %v703, float %v704, float %v705, float %v706) #2
  %v1231 = extractvalue { float, float, float, float } %v1230, 0
  %v1232 = extractvalue { float, float, float, float } %v1230, 1
  %v1233 = extractvalue { float, float, float, float } %v1230, 2
  %v1234 = extractvalue { float, float, float, float } %v1230, 3
  %v1243 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1023, i32 %v1025, i32 %v1027, i32 %v1029, i32 %v1065, i32 %v1069, float %v716, float %v717, float %v718, float %v719) #2
  %v1244 = extractvalue { float, float, float, float } %v1243, 0
  %v1245 = extractvalue { float, float, float, float } %v1243, 1
  %v1246 = extractvalue { float, float, float, float } %v1243, 2
  %v1247 = extractvalue { float, float, float, float } %v1243, 3
  %v1256 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1023, i32 %v1025, i32 %v1027, i32 %v1029, i32 %v1073, i32 %v1077, float %v729, float %v730, float %v731, float %v732) #2
  %v1257 = extractvalue { float, float, float, float } %v1256, 0
  %v1258 = extractvalue { float, float, float, float } %v1256, 1
  %v1259 = extractvalue { float, float, float, float } %v1256, 2
  %v1260 = extractvalue { float, float, float, float } %v1256, 3
  %v1269 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1023, i32 %v1025, i32 %v1027, i32 %v1029, i32 %v1081, i32 %v1085, float %v742, float %v743, float %v744, float %v745) #2
  %v1270 = extractvalue { float, float, float, float } %v1269, 0
  %v1271 = extractvalue { float, float, float, float } %v1269, 1
  %v1272 = extractvalue { float, float, float, float } %v1269, 2
  %v1273 = extractvalue { float, float, float, float } %v1269, 3
  %v1282 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1023, i32 %v1025, i32 %v1027, i32 %v1029, i32 %v1089, i32 %v1093, float %v755, float %v756, float %v757, float %v758) #2
  %v1283 = extractvalue { float, float, float, float } %v1282, 0
  %v1284 = extractvalue { float, float, float, float } %v1282, 1
  %v1285 = extractvalue { float, float, float, float } %v1282, 2
  %v1286 = extractvalue { float, float, float, float } %v1282, 3
  %v1295 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1023, i32 %v1025, i32 %v1027, i32 %v1029, i32 %v1097, i32 %v1101, float %v768, float %v769, float %v770, float %v771) #2
  %v1296 = extractvalue { float, float, float, float } %v1295, 0
  %v1297 = extractvalue { float, float, float, float } %v1295, 1
  %v1298 = extractvalue { float, float, float, float } %v1295, 2
  %v1299 = extractvalue { float, float, float, float } %v1295, 3
  %v1308 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1023, i32 %v1025, i32 %v1027, i32 %v1029, i32 %v1105, i32 %v1109, float %v781, float %v782, float %v783, float %v784) #2
  %v1309 = extractvalue { float, float, float, float } %v1308, 0
  %v1310 = extractvalue { float, float, float, float } %v1308, 1
  %v1311 = extractvalue { float, float, float, float } %v1308, 2
  %v1312 = extractvalue { float, float, float, float } %v1308, 3
  %v1321 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1023, i32 %v1025, i32 %v1027, i32 %v1029, i32 %v1113, i32 %v1117, float %v794, float %v795, float %v796, float %v797) #2
  %v1322 = extractvalue { float, float, float, float } %v1321, 0
  %v1323 = extractvalue { float, float, float, float } %v1321, 1
  %v1324 = extractvalue { float, float, float, float } %v1321, 2
  %v1325 = extractvalue { float, float, float, float } %v1321, 3
  %v1334 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1035, i32 %v1037, i32 %v1039, i32 %v1041, i32 %v1057, i32 %v1061, float %v807, float %v808, float %v809, float %v810) #2
  %v1335 = extractvalue { float, float, float, float } %v1334, 0
  %v1336 = extractvalue { float, float, float, float } %v1334, 1
  %v1337 = extractvalue { float, float, float, float } %v1334, 2
  %v1338 = extractvalue { float, float, float, float } %v1334, 3
  %v1347 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1035, i32 %v1037, i32 %v1039, i32 %v1041, i32 %v1065, i32 %v1069, float %v820, float %v821, float %v822, float %v823) #2
  %v1348 = extractvalue { float, float, float, float } %v1347, 0
  %v1349 = extractvalue { float, float, float, float } %v1347, 1
  %v1350 = extractvalue { float, float, float, float } %v1347, 2
  %v1351 = extractvalue { float, float, float, float } %v1347, 3
  %v1360 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1035, i32 %v1037, i32 %v1039, i32 %v1041, i32 %v1073, i32 %v1077, float %v833, float %v834, float %v835, float %v836) #2
  %v1361 = extractvalue { float, float, float, float } %v1360, 0
  %v1362 = extractvalue { float, float, float, float } %v1360, 1
  %v1363 = extractvalue { float, float, float, float } %v1360, 2
  %v1364 = extractvalue { float, float, float, float } %v1360, 3
  %v1373 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1035, i32 %v1037, i32 %v1039, i32 %v1041, i32 %v1081, i32 %v1085, float %v846, float %v847, float %v848, float %v849) #2
  %v1374 = extractvalue { float, float, float, float } %v1373, 0
  %v1375 = extractvalue { float, float, float, float } %v1373, 1
  %v1376 = extractvalue { float, float, float, float } %v1373, 2
  %v1377 = extractvalue { float, float, float, float } %v1373, 3
  %v1386 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1035, i32 %v1037, i32 %v1039, i32 %v1041, i32 %v1089, i32 %v1093, float %v859, float %v860, float %v861, float %v862) #2
  %v1387 = extractvalue { float, float, float, float } %v1386, 0
  %v1388 = extractvalue { float, float, float, float } %v1386, 1
  %v1389 = extractvalue { float, float, float, float } %v1386, 2
  %v1390 = extractvalue { float, float, float, float } %v1386, 3
  %v1399 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1035, i32 %v1037, i32 %v1039, i32 %v1041, i32 %v1097, i32 %v1101, float %v872, float %v873, float %v874, float %v875) #2
  %v1400 = extractvalue { float, float, float, float } %v1399, 0
  %v1401 = extractvalue { float, float, float, float } %v1399, 1
  %v1402 = extractvalue { float, float, float, float } %v1399, 2
  %v1403 = extractvalue { float, float, float, float } %v1399, 3
  %v1412 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1035, i32 %v1037, i32 %v1039, i32 %v1041, i32 %v1105, i32 %v1109, float %v885, float %v886, float %v887, float %v888) #2
  %v1413 = extractvalue { float, float, float, float } %v1412, 0
  %v1414 = extractvalue { float, float, float, float } %v1412, 1
  %v1415 = extractvalue { float, float, float, float } %v1412, 2
  %v1416 = extractvalue { float, float, float, float } %v1412, 3
  %v1425 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1035, i32 %v1037, i32 %v1039, i32 %v1041, i32 %v1113, i32 %v1117, float %v898, float %v899, float %v900, float %v901) #2
  %v1426 = extractvalue { float, float, float, float } %v1425, 0
  %v1427 = extractvalue { float, float, float, float } %v1425, 1
  %v1428 = extractvalue { float, float, float, float } %v1425, 2
  %v1429 = extractvalue { float, float, float, float } %v1425, 3
  %v1438 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1047, i32 %v1049, i32 %v1051, i32 %v1053, i32 %v1057, i32 %v1061, float %v911, float %v912, float %v913, float %v914) #2
  %v1439 = extractvalue { float, float, float, float } %v1438, 0
  %v1440 = extractvalue { float, float, float, float } %v1438, 1
  %v1441 = extractvalue { float, float, float, float } %v1438, 2
  %v1442 = extractvalue { float, float, float, float } %v1438, 3
  %v1451 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1047, i32 %v1049, i32 %v1051, i32 %v1053, i32 %v1065, i32 %v1069, float %v924, float %v925, float %v926, float %v927) #2
  %v1452 = extractvalue { float, float, float, float } %v1451, 0
  %v1453 = extractvalue { float, float, float, float } %v1451, 1
  %v1454 = extractvalue { float, float, float, float } %v1451, 2
  %v1455 = extractvalue { float, float, float, float } %v1451, 3
  %v1464 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1047, i32 %v1049, i32 %v1051, i32 %v1053, i32 %v1073, i32 %v1077, float %v937, float %v938, float %v939, float %v940) #2
  %v1465 = extractvalue { float, float, float, float } %v1464, 0
  %v1466 = extractvalue { float, float, float, float } %v1464, 1
  %v1467 = extractvalue { float, float, float, float } %v1464, 2
  %v1468 = extractvalue { float, float, float, float } %v1464, 3
  %v1477 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1047, i32 %v1049, i32 %v1051, i32 %v1053, i32 %v1081, i32 %v1085, float %v950, float %v951, float %v952, float %v953) #2
  %v1478 = extractvalue { float, float, float, float } %v1477, 0
  %v1479 = extractvalue { float, float, float, float } %v1477, 1
  %v1480 = extractvalue { float, float, float, float } %v1477, 2
  %v1481 = extractvalue { float, float, float, float } %v1477, 3
  %v1490 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1047, i32 %v1049, i32 %v1051, i32 %v1053, i32 %v1089, i32 %v1093, float %v963, float %v964, float %v965, float %v966) #2
  %v1491 = extractvalue { float, float, float, float } %v1490, 0
  %v1492 = extractvalue { float, float, float, float } %v1490, 1
  %v1493 = extractvalue { float, float, float, float } %v1490, 2
  %v1494 = extractvalue { float, float, float, float } %v1490, 3
  %v1503 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1047, i32 %v1049, i32 %v1051, i32 %v1053, i32 %v1097, i32 %v1101, float %v976, float %v977, float %v978, float %v979) #2
  %v1504 = extractvalue { float, float, float, float } %v1503, 0
  %v1505 = extractvalue { float, float, float, float } %v1503, 1
  %v1506 = extractvalue { float, float, float, float } %v1503, 2
  %v1507 = extractvalue { float, float, float, float } %v1503, 3
  %v1516 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1047, i32 %v1049, i32 %v1051, i32 %v1053, i32 %v1105, i32 %v1109, float %v989, float %v990, float %v991, float %v992) #2
  %v1517 = extractvalue { float, float, float, float } %v1516, 0
  %v1518 = extractvalue { float, float, float, float } %v1516, 1
  %v1519 = extractvalue { float, float, float, float } %v1516, 2
  %v1520 = extractvalue { float, float, float, float } %v1516, 3
  %v1529 = tail call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v1047, i32 %v1049, i32 %v1051, i32 %v1053, i32 %v1113, i32 %v1117, float %v1002, float %v1003, float %v1004, float %v1005) #2
  %v1530 = extractvalue { float, float, float, float } %v1529, 0
  %v1531 = extractvalue { float, float, float, float } %v1529, 1
  %v1532 = extractvalue { float, float, float, float } %v1529, 2
  %v1533 = extractvalue { float, float, float, float } %v1529, 3
  %v1534 = icmp eq i64 %v391, 8
  br i1 %v1534, label %done, label %kt

done:                                             ; preds = %issued
  %v1540 = shl nuw nsw i64 %v12, 1
  %v1541 = or disjoint i64 %v1540, %v14
  %v1547 = insertelement <2 x float> poison, float %v1127, i64 0
  %v1550 = insertelement <2 x float> %v1547, float %v1128, i64 1
  %.idx62 = shl nuw nsw i64 %v148, 10
  %51 = getelementptr inbounds nuw i8, ptr addrspace(1) %o, i64 %.idx62
  %v1552 = getelementptr inbounds nuw float, ptr addrspace(1) %51, i64 %v1541
  store <2 x float> %v1550, ptr addrspace(1) %v1552, align 8
  %v1555 = insertelement <2 x float> poison, float %v1140, i64 0
  %v1558 = insertelement <2 x float> %v1555, float %v1141, i64 1
  %v1560 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1552, i64 32
  store <2 x float> %v1558, ptr addrspace(1) %v1560, align 8
  %v1563 = insertelement <2 x float> poison, float %v1153, i64 0
  %v1566 = insertelement <2 x float> %v1563, float %v1154, i64 1
  %v1568 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1552, i64 64
  store <2 x float> %v1566, ptr addrspace(1) %v1568, align 8
  %v1571 = insertelement <2 x float> poison, float %v1166, i64 0
  %v1574 = insertelement <2 x float> %v1571, float %v1167, i64 1
  %v1576 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1552, i64 96
  store <2 x float> %v1574, ptr addrspace(1) %v1576, align 8
  %v1579 = insertelement <2 x float> poison, float %v1179, i64 0
  %v1582 = insertelement <2 x float> %v1579, float %v1180, i64 1
  %v1584 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1552, i64 128
  store <2 x float> %v1582, ptr addrspace(1) %v1584, align 8
  %v1587 = insertelement <2 x float> poison, float %v1192, i64 0
  %v1590 = insertelement <2 x float> %v1587, float %v1193, i64 1
  %v1592 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1552, i64 160
  store <2 x float> %v1590, ptr addrspace(1) %v1592, align 8
  %v1595 = insertelement <2 x float> poison, float %v1205, i64 0
  %v1598 = insertelement <2 x float> %v1595, float %v1206, i64 1
  %v1600 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1552, i64 192
  store <2 x float> %v1598, ptr addrspace(1) %v1600, align 8
  %v1603 = insertelement <2 x float> poison, float %v1218, i64 0
  %v1606 = insertelement <2 x float> %v1603, float %v1219, i64 1
  %v1608 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1552, i64 224
  store <2 x float> %v1606, ptr addrspace(1) %v1608, align 8
  %v1614 = insertelement <2 x float> poison, float %v1129, i64 0
  %v1617 = insertelement <2 x float> %v1614, float %v1130, i64 1
  %52 = getelementptr inbounds nuw i8, ptr addrspace(1) %51, i64 8192
  %v1619 = getelementptr inbounds nuw float, ptr addrspace(1) %52, i64 %v1541
  store <2 x float> %v1617, ptr addrspace(1) %v1619, align 8
  %v1622 = insertelement <2 x float> poison, float %v1142, i64 0
  %v1625 = insertelement <2 x float> %v1622, float %v1143, i64 1
  %v1627 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1619, i64 32
  store <2 x float> %v1625, ptr addrspace(1) %v1627, align 8
  %v1630 = insertelement <2 x float> poison, float %v1155, i64 0
  %v1633 = insertelement <2 x float> %v1630, float %v1156, i64 1
  %v1635 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1619, i64 64
  store <2 x float> %v1633, ptr addrspace(1) %v1635, align 8
  %v1638 = insertelement <2 x float> poison, float %v1168, i64 0
  %v1641 = insertelement <2 x float> %v1638, float %v1169, i64 1
  %v1643 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1619, i64 96
  store <2 x float> %v1641, ptr addrspace(1) %v1643, align 8
  %v1646 = insertelement <2 x float> poison, float %v1181, i64 0
  %v1649 = insertelement <2 x float> %v1646, float %v1182, i64 1
  %v1651 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1619, i64 128
  store <2 x float> %v1649, ptr addrspace(1) %v1651, align 8
  %v1654 = insertelement <2 x float> poison, float %v1194, i64 0
  %v1657 = insertelement <2 x float> %v1654, float %v1195, i64 1
  %v1659 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1619, i64 160
  store <2 x float> %v1657, ptr addrspace(1) %v1659, align 8
  %v1662 = insertelement <2 x float> poison, float %v1207, i64 0
  %v1665 = insertelement <2 x float> %v1662, float %v1208, i64 1
  %v1667 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1619, i64 192
  store <2 x float> %v1665, ptr addrspace(1) %v1667, align 8
  %v1670 = insertelement <2 x float> poison, float %v1220, i64 0
  %v1673 = insertelement <2 x float> %v1670, float %v1221, i64 1
  %v1675 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1619, i64 224
  store <2 x float> %v1673, ptr addrspace(1) %v1675, align 8
  %v1681 = insertelement <2 x float> poison, float %v1231, i64 0
  %v1684 = insertelement <2 x float> %v1681, float %v1232, i64 1
  %53 = getelementptr inbounds nuw i8, ptr addrspace(1) %51, i64 16384
  %v1686 = getelementptr inbounds nuw float, ptr addrspace(1) %53, i64 %v1541
  store <2 x float> %v1684, ptr addrspace(1) %v1686, align 8
  %v1689 = insertelement <2 x float> poison, float %v1244, i64 0
  %v1692 = insertelement <2 x float> %v1689, float %v1245, i64 1
  %v1694 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1686, i64 32
  store <2 x float> %v1692, ptr addrspace(1) %v1694, align 8
  %v1697 = insertelement <2 x float> poison, float %v1257, i64 0
  %v1700 = insertelement <2 x float> %v1697, float %v1258, i64 1
  %v1702 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1686, i64 64
  store <2 x float> %v1700, ptr addrspace(1) %v1702, align 8
  %v1705 = insertelement <2 x float> poison, float %v1270, i64 0
  %v1708 = insertelement <2 x float> %v1705, float %v1271, i64 1
  %v1710 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1686, i64 96
  store <2 x float> %v1708, ptr addrspace(1) %v1710, align 8
  %v1713 = insertelement <2 x float> poison, float %v1283, i64 0
  %v1716 = insertelement <2 x float> %v1713, float %v1284, i64 1
  %v1718 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1686, i64 128
  store <2 x float> %v1716, ptr addrspace(1) %v1718, align 8
  %v1721 = insertelement <2 x float> poison, float %v1296, i64 0
  %v1724 = insertelement <2 x float> %v1721, float %v1297, i64 1
  %v1726 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1686, i64 160
  store <2 x float> %v1724, ptr addrspace(1) %v1726, align 8
  %v1729 = insertelement <2 x float> poison, float %v1309, i64 0
  %v1732 = insertelement <2 x float> %v1729, float %v1310, i64 1
  %v1734 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1686, i64 192
  store <2 x float> %v1732, ptr addrspace(1) %v1734, align 8
  %v1737 = insertelement <2 x float> poison, float %v1322, i64 0
  %v1740 = insertelement <2 x float> %v1737, float %v1323, i64 1
  %v1742 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1686, i64 224
  store <2 x float> %v1740, ptr addrspace(1) %v1742, align 8
  %v1748 = insertelement <2 x float> poison, float %v1233, i64 0
  %v1751 = insertelement <2 x float> %v1748, float %v1234, i64 1
  %54 = getelementptr inbounds nuw i8, ptr addrspace(1) %51, i64 24576
  %v1753 = getelementptr inbounds nuw float, ptr addrspace(1) %54, i64 %v1541
  store <2 x float> %v1751, ptr addrspace(1) %v1753, align 8
  %v1756 = insertelement <2 x float> poison, float %v1246, i64 0
  %v1759 = insertelement <2 x float> %v1756, float %v1247, i64 1
  %v1761 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1753, i64 32
  store <2 x float> %v1759, ptr addrspace(1) %v1761, align 8
  %v1764 = insertelement <2 x float> poison, float %v1259, i64 0
  %v1767 = insertelement <2 x float> %v1764, float %v1260, i64 1
  %v1769 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1753, i64 64
  store <2 x float> %v1767, ptr addrspace(1) %v1769, align 8
  %v1772 = insertelement <2 x float> poison, float %v1272, i64 0
  %v1775 = insertelement <2 x float> %v1772, float %v1273, i64 1
  %v1777 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1753, i64 96
  store <2 x float> %v1775, ptr addrspace(1) %v1777, align 8
  %v1780 = insertelement <2 x float> poison, float %v1285, i64 0
  %v1783 = insertelement <2 x float> %v1780, float %v1286, i64 1
  %v1785 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1753, i64 128
  store <2 x float> %v1783, ptr addrspace(1) %v1785, align 8
  %v1788 = insertelement <2 x float> poison, float %v1298, i64 0
  %v1791 = insertelement <2 x float> %v1788, float %v1299, i64 1
  %v1793 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1753, i64 160
  store <2 x float> %v1791, ptr addrspace(1) %v1793, align 8
  %v1796 = insertelement <2 x float> poison, float %v1311, i64 0
  %v1799 = insertelement <2 x float> %v1796, float %v1312, i64 1
  %v1801 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1753, i64 192
  store <2 x float> %v1799, ptr addrspace(1) %v1801, align 8
  %v1804 = insertelement <2 x float> poison, float %v1324, i64 0
  %v1807 = insertelement <2 x float> %v1804, float %v1325, i64 1
  %v1809 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1753, i64 224
  store <2 x float> %v1807, ptr addrspace(1) %v1809, align 8
  %v1815 = insertelement <2 x float> poison, float %v1335, i64 0
  %v1818 = insertelement <2 x float> %v1815, float %v1336, i64 1
  %55 = getelementptr inbounds nuw i8, ptr addrspace(1) %51, i64 32768
  %v1820 = getelementptr inbounds nuw float, ptr addrspace(1) %55, i64 %v1541
  store <2 x float> %v1818, ptr addrspace(1) %v1820, align 8
  %v1823 = insertelement <2 x float> poison, float %v1348, i64 0
  %v1826 = insertelement <2 x float> %v1823, float %v1349, i64 1
  %v1828 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1820, i64 32
  store <2 x float> %v1826, ptr addrspace(1) %v1828, align 8
  %v1831 = insertelement <2 x float> poison, float %v1361, i64 0
  %v1834 = insertelement <2 x float> %v1831, float %v1362, i64 1
  %v1836 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1820, i64 64
  store <2 x float> %v1834, ptr addrspace(1) %v1836, align 8
  %v1839 = insertelement <2 x float> poison, float %v1374, i64 0
  %v1842 = insertelement <2 x float> %v1839, float %v1375, i64 1
  %v1844 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1820, i64 96
  store <2 x float> %v1842, ptr addrspace(1) %v1844, align 8
  %v1847 = insertelement <2 x float> poison, float %v1387, i64 0
  %v1850 = insertelement <2 x float> %v1847, float %v1388, i64 1
  %v1852 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1820, i64 128
  store <2 x float> %v1850, ptr addrspace(1) %v1852, align 8
  %v1855 = insertelement <2 x float> poison, float %v1400, i64 0
  %v1858 = insertelement <2 x float> %v1855, float %v1401, i64 1
  %v1860 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1820, i64 160
  store <2 x float> %v1858, ptr addrspace(1) %v1860, align 8
  %v1863 = insertelement <2 x float> poison, float %v1413, i64 0
  %v1866 = insertelement <2 x float> %v1863, float %v1414, i64 1
  %v1868 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1820, i64 192
  store <2 x float> %v1866, ptr addrspace(1) %v1868, align 8
  %v1871 = insertelement <2 x float> poison, float %v1426, i64 0
  %v1874 = insertelement <2 x float> %v1871, float %v1427, i64 1
  %v1876 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1820, i64 224
  store <2 x float> %v1874, ptr addrspace(1) %v1876, align 8
  %v1882 = insertelement <2 x float> poison, float %v1337, i64 0
  %v1885 = insertelement <2 x float> %v1882, float %v1338, i64 1
  %56 = getelementptr inbounds nuw i8, ptr addrspace(1) %51, i64 40960
  %v1887 = getelementptr inbounds nuw float, ptr addrspace(1) %56, i64 %v1541
  store <2 x float> %v1885, ptr addrspace(1) %v1887, align 8
  %v1890 = insertelement <2 x float> poison, float %v1350, i64 0
  %v1893 = insertelement <2 x float> %v1890, float %v1351, i64 1
  %v1895 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1887, i64 32
  store <2 x float> %v1893, ptr addrspace(1) %v1895, align 8
  %v1898 = insertelement <2 x float> poison, float %v1363, i64 0
  %v1901 = insertelement <2 x float> %v1898, float %v1364, i64 1
  %v1903 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1887, i64 64
  store <2 x float> %v1901, ptr addrspace(1) %v1903, align 8
  %v1906 = insertelement <2 x float> poison, float %v1376, i64 0
  %v1909 = insertelement <2 x float> %v1906, float %v1377, i64 1
  %v1911 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1887, i64 96
  store <2 x float> %v1909, ptr addrspace(1) %v1911, align 8
  %v1914 = insertelement <2 x float> poison, float %v1389, i64 0
  %v1917 = insertelement <2 x float> %v1914, float %v1390, i64 1
  %v1919 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1887, i64 128
  store <2 x float> %v1917, ptr addrspace(1) %v1919, align 8
  %v1922 = insertelement <2 x float> poison, float %v1402, i64 0
  %v1925 = insertelement <2 x float> %v1922, float %v1403, i64 1
  %v1927 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1887, i64 160
  store <2 x float> %v1925, ptr addrspace(1) %v1927, align 8
  %v1930 = insertelement <2 x float> poison, float %v1415, i64 0
  %v1933 = insertelement <2 x float> %v1930, float %v1416, i64 1
  %v1935 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1887, i64 192
  store <2 x float> %v1933, ptr addrspace(1) %v1935, align 8
  %v1938 = insertelement <2 x float> poison, float %v1428, i64 0
  %v1941 = insertelement <2 x float> %v1938, float %v1429, i64 1
  %v1943 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1887, i64 224
  store <2 x float> %v1941, ptr addrspace(1) %v1943, align 8
  %v1949 = insertelement <2 x float> poison, float %v1439, i64 0
  %v1952 = insertelement <2 x float> %v1949, float %v1440, i64 1
  %57 = getelementptr inbounds nuw i8, ptr addrspace(1) %51, i64 49152
  %v1954 = getelementptr inbounds nuw float, ptr addrspace(1) %57, i64 %v1541
  store <2 x float> %v1952, ptr addrspace(1) %v1954, align 8
  %v1957 = insertelement <2 x float> poison, float %v1452, i64 0
  %v1960 = insertelement <2 x float> %v1957, float %v1453, i64 1
  %v1962 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1954, i64 32
  store <2 x float> %v1960, ptr addrspace(1) %v1962, align 8
  %v1965 = insertelement <2 x float> poison, float %v1465, i64 0
  %v1968 = insertelement <2 x float> %v1965, float %v1466, i64 1
  %v1970 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1954, i64 64
  store <2 x float> %v1968, ptr addrspace(1) %v1970, align 8
  %v1973 = insertelement <2 x float> poison, float %v1478, i64 0
  %v1976 = insertelement <2 x float> %v1973, float %v1479, i64 1
  %v1978 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1954, i64 96
  store <2 x float> %v1976, ptr addrspace(1) %v1978, align 8
  %v1981 = insertelement <2 x float> poison, float %v1491, i64 0
  %v1984 = insertelement <2 x float> %v1981, float %v1492, i64 1
  %v1986 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1954, i64 128
  store <2 x float> %v1984, ptr addrspace(1) %v1986, align 8
  %v1989 = insertelement <2 x float> poison, float %v1504, i64 0
  %v1992 = insertelement <2 x float> %v1989, float %v1505, i64 1
  %v1994 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1954, i64 160
  store <2 x float> %v1992, ptr addrspace(1) %v1994, align 8
  %v1997 = insertelement <2 x float> poison, float %v1517, i64 0
  %v2000 = insertelement <2 x float> %v1997, float %v1518, i64 1
  %v2002 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1954, i64 192
  store <2 x float> %v2000, ptr addrspace(1) %v2002, align 8
  %v2005 = insertelement <2 x float> poison, float %v1530, i64 0
  %v2008 = insertelement <2 x float> %v2005, float %v1531, i64 1
  %v2010 = getelementptr inbounds nuw i8, ptr addrspace(1) %v1954, i64 224
  store <2 x float> %v2008, ptr addrspace(1) %v2010, align 8
  %v2016 = insertelement <2 x float> poison, float %v1441, i64 0
  %v2019 = insertelement <2 x float> %v2016, float %v1442, i64 1
  %58 = getelementptr inbounds nuw i8, ptr addrspace(1) %51, i64 57344
  %v2021 = getelementptr inbounds nuw float, ptr addrspace(1) %58, i64 %v1541
  store <2 x float> %v2019, ptr addrspace(1) %v2021, align 8
  %v2024 = insertelement <2 x float> poison, float %v1454, i64 0
  %v2027 = insertelement <2 x float> %v2024, float %v1455, i64 1
  %v2029 = getelementptr inbounds nuw i8, ptr addrspace(1) %v2021, i64 32
  store <2 x float> %v2027, ptr addrspace(1) %v2029, align 8
  %v2032 = insertelement <2 x float> poison, float %v1467, i64 0
  %v2035 = insertelement <2 x float> %v2032, float %v1468, i64 1
  %v2037 = getelementptr inbounds nuw i8, ptr addrspace(1) %v2021, i64 64
  store <2 x float> %v2035, ptr addrspace(1) %v2037, align 8
  %v2040 = insertelement <2 x float> poison, float %v1480, i64 0
  %v2043 = insertelement <2 x float> %v2040, float %v1481, i64 1
  %v2045 = getelementptr inbounds nuw i8, ptr addrspace(1) %v2021, i64 96
  store <2 x float> %v2043, ptr addrspace(1) %v2045, align 8
  %v2048 = insertelement <2 x float> poison, float %v1493, i64 0
  %v2051 = insertelement <2 x float> %v2048, float %v1494, i64 1
  %v2053 = getelementptr inbounds nuw i8, ptr addrspace(1) %v2021, i64 128
  store <2 x float> %v2051, ptr addrspace(1) %v2053, align 8
  %v2056 = insertelement <2 x float> poison, float %v1506, i64 0
  %v2059 = insertelement <2 x float> %v2056, float %v1507, i64 1
  %v2061 = getelementptr inbounds nuw i8, ptr addrspace(1) %v2021, i64 160
  store <2 x float> %v2059, ptr addrspace(1) %v2061, align 8
  %v2064 = insertelement <2 x float> poison, float %v1519, i64 0
  %v2067 = insertelement <2 x float> %v2064, float %v1520, i64 1
  %v2069 = getelementptr inbounds nuw i8, ptr addrspace(1) %v2021, i64 192
  store <2 x float> %v2067, ptr addrspace(1) %v2069, align 8
  %v2072 = insertelement <2 x float> poison, float %v1532, i64 0
  %v2075 = insertelement <2 x float> %v2072, float %v1533, i64 1
  %v2077 = getelementptr inbounds nuw i8, ptr addrspace(1) %v2021, i64 224
  store <2 x float> %v2075, ptr addrspace(1) %v2077, align 8
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_2b98ef88b8cfe803(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #5 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %p = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %i
  %x = trunc i64 %i to i32
  %t7.i = srem i32 %x, 31
  %t9.i = sitofp i32 %t7.i to float
  store float %t9.i, ptr addrspace(1) %p, align 4
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_5cee44f9496d8476(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #5 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %p = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %i
  %x = trunc i64 %i to i32
  %t7.i = srem i32 %x, 23
  %t9.i = sitofp i32 %t7.i to float
  store float %t9.i, ptr addrspace(1) %p, align 4
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.barrier.cta.sync.aligned.all(i32) #6

attributes #0 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nounwind memory(argmem: readwrite) }
attributes #2 = { nounwind }
attributes #3 = { nounwind "nvvm.maxntid"="256" }
attributes #4 = { nounwind "nvvm.maxntid"="32" }
attributes #5 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) "nvvm.maxntid"="256" }
attributes #6 = { convergent nocallback nounwind }
