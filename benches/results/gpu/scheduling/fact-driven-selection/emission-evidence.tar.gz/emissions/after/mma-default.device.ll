; mapal-backend-llvm device module
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@mapal_smem = external addrspace(3) global [0 x i8], align 16
declare i32 @llvm.nvvm.read.ptx.sreg.tid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
declare void @llvm.nvvm.barrier0()
declare void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.8(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.commit.group()
declare void @llvm.nvvm.cp.async.wait.group(i32 immarg)
declare float @llvm.fma.f32(float, float, float)
declare double @llvm.fma.f64(double, double, double)

define ptx_kernel void @mapal_tile_d0cfb9881535775e(ptr addrspace(1) noalias readonly align 16 %a, ptr addrspace(1) noalias readonly align 16 %b, ptr addrspace(1) noalias align 16 %o) "nvvm.maxntid"="128" "nvvm.minctasm"="2" {
entry:
  %v1 = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = zext i32 %v1 to i64
  %v3 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v4 = zext i32 %v3 to i64
  %v5 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v6 = zext i32 %v5 to i64
  %v7 = udiv i64 %v2, 32
  %v8 = urem i64 %v2, 32
  %v9 = udiv i64 %v7, 2
  %v10 = urem i64 %v7, 2
  %v11 = udiv i64 %v8, 4
  %v12 = urem i64 %v8, 4
  %v13 = mul i64 %v6, 64
  %v14 = mul i64 %v4, 64
  %v15 = alloca [32 x float], align 16
  %v16 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 0
  store float 0x0000000000000000, ptr %v16, align 4
  %v17 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 1
  store float 0x0000000000000000, ptr %v17, align 4
  %v18 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 2
  store float 0x0000000000000000, ptr %v18, align 4
  %v19 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 3
  store float 0x0000000000000000, ptr %v19, align 4
  %v20 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 4
  store float 0x0000000000000000, ptr %v20, align 4
  %v21 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 5
  store float 0x0000000000000000, ptr %v21, align 4
  %v22 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 6
  store float 0x0000000000000000, ptr %v22, align 4
  %v23 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 7
  store float 0x0000000000000000, ptr %v23, align 4
  %v24 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 8
  store float 0x0000000000000000, ptr %v24, align 4
  %v25 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 9
  store float 0x0000000000000000, ptr %v25, align 4
  %v26 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 10
  store float 0x0000000000000000, ptr %v26, align 4
  %v27 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 11
  store float 0x0000000000000000, ptr %v27, align 4
  %v28 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 12
  store float 0x0000000000000000, ptr %v28, align 4
  %v29 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 13
  store float 0x0000000000000000, ptr %v29, align 4
  %v30 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 14
  store float 0x0000000000000000, ptr %v30, align 4
  %v31 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 15
  store float 0x0000000000000000, ptr %v31, align 4
  %v32 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 16
  store float 0x0000000000000000, ptr %v32, align 4
  %v33 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 17
  store float 0x0000000000000000, ptr %v33, align 4
  %v34 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 18
  store float 0x0000000000000000, ptr %v34, align 4
  %v35 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 19
  store float 0x0000000000000000, ptr %v35, align 4
  %v36 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 20
  store float 0x0000000000000000, ptr %v36, align 4
  %v37 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 21
  store float 0x0000000000000000, ptr %v37, align 4
  %v38 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 22
  store float 0x0000000000000000, ptr %v38, align 4
  %v39 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 23
  store float 0x0000000000000000, ptr %v39, align 4
  %v40 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 24
  store float 0x0000000000000000, ptr %v40, align 4
  %v41 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 25
  store float 0x0000000000000000, ptr %v41, align 4
  %v42 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 26
  store float 0x0000000000000000, ptr %v42, align 4
  %v43 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 27
  store float 0x0000000000000000, ptr %v43, align 4
  %v44 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 28
  store float 0x0000000000000000, ptr %v44, align 4
  %v45 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 29
  store float 0x0000000000000000, ptr %v45, align 4
  %v46 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 30
  store float 0x0000000000000000, ptr %v46, align 4
  %v47 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 31
  store float 0x0000000000000000, ptr %v47, align 4
  %v48 = add i64 %v2, 0
  %v49 = udiv i64 %v48, 8
  %v50 = urem i64 %v48, 8
  %v51 = mul i64 %v50, 4
  %v52 = add i64 %v13, %v49
  %v53 = mul i64 %v52, 1024
  %v54 = add i64 %v53, %v51
  %v55 = add i64 %v54, 0
  %v56 = mul i64 %v49, 36
  %v57 = add i64 %v56, %v51
  %v58 = add i64 %v2, 128
  %v59 = udiv i64 %v58, 8
  %v60 = urem i64 %v58, 8
  %v61 = mul i64 %v60, 4
  %v62 = add i64 %v13, %v59
  %v63 = mul i64 %v62, 1024
  %v64 = add i64 %v63, %v61
  %v65 = add i64 %v64, 0
  %v66 = mul i64 %v59, 36
  %v67 = add i64 %v66, %v61
  %v68 = add i64 %v2, 256
  %v69 = udiv i64 %v68, 8
  %v70 = urem i64 %v68, 8
  %v71 = mul i64 %v70, 4
  %v72 = add i64 %v13, %v69
  %v73 = mul i64 %v72, 1024
  %v74 = add i64 %v73, %v71
  %v75 = add i64 %v74, 0
  %v76 = mul i64 %v69, 36
  %v77 = add i64 %v76, %v71
  %v78 = add i64 %v2, 384
  %v79 = udiv i64 %v78, 8
  %v80 = urem i64 %v78, 8
  %v81 = mul i64 %v80, 4
  %v82 = add i64 %v13, %v79
  %v83 = mul i64 %v82, 1024
  %v84 = add i64 %v83, %v81
  %v85 = add i64 %v84, 0
  %v86 = mul i64 %v79, 36
  %v87 = add i64 %v86, %v81
  %v88 = add i64 %v2, 0
  %v89 = udiv i64 %v88, 16
  %v90 = urem i64 %v88, 16
  %v91 = mul i64 %v90, 4
  %v92 = mul i64 %v89, 1024
  %v93 = add i64 %v14, %v91
  %v94 = add i64 %v92, %v93
  %v95 = add i64 %v94, 0
  %v96 = mul i64 %v89, 72
  %v97 = add i64 %v96, %v91
  %v98 = add i64 %v97, 2304
  %v99 = add i64 %v2, 128
  %v100 = udiv i64 %v99, 16
  %v101 = urem i64 %v99, 16
  %v102 = mul i64 %v101, 4
  %v103 = mul i64 %v100, 1024
  %v104 = add i64 %v14, %v102
  %v105 = add i64 %v103, %v104
  %v106 = add i64 %v105, 0
  %v107 = mul i64 %v100, 72
  %v108 = add i64 %v107, %v102
  %v109 = add i64 %v108, 2304
  %v110 = add i64 %v2, 256
  %v111 = udiv i64 %v110, 16
  %v112 = urem i64 %v110, 16
  %v113 = mul i64 %v112, 4
  %v114 = mul i64 %v111, 1024
  %v115 = add i64 %v14, %v113
  %v116 = add i64 %v114, %v115
  %v117 = add i64 %v116, 0
  %v118 = mul i64 %v111, 72
  %v119 = add i64 %v118, %v113
  %v120 = add i64 %v119, 2304
  %v121 = add i64 %v2, 384
  %v122 = udiv i64 %v121, 16
  %v123 = urem i64 %v121, 16
  %v124 = mul i64 %v123, 4
  %v125 = mul i64 %v122, 1024
  %v126 = add i64 %v14, %v124
  %v127 = add i64 %v125, %v126
  %v128 = add i64 %v127, 0
  %v129 = mul i64 %v122, 72
  %v130 = add i64 %v129, %v124
  %v131 = add i64 %v130, 2304
  %v132 = mul i64 0, 32
  %v133 = mul i64 %v132, 1
  %v134 = mul i64 %v132, 1024
  %v135 = mul i64 0, 4608
  %v136 = add i64 %v55, %v133
  %v137 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v136
  %v138 = add i64 %v57, %v135
  %v139 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v138
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v139, ptr addrspace(1) %v137)
  %v140 = add i64 %v65, %v133
  %v141 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v140
  %v142 = add i64 %v67, %v135
  %v143 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v142
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v143, ptr addrspace(1) %v141)
  %v144 = add i64 %v75, %v133
  %v145 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v144
  %v146 = add i64 %v77, %v135
  %v147 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v146
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v147, ptr addrspace(1) %v145)
  %v148 = add i64 %v85, %v133
  %v149 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v148
  %v150 = add i64 %v87, %v135
  %v151 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v150
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v151, ptr addrspace(1) %v149)
  %v152 = add i64 %v95, %v134
  %v153 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v152
  %v154 = add i64 %v98, %v135
  %v155 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v154
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v155, ptr addrspace(1) %v153)
  %v156 = add i64 %v106, %v134
  %v157 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v156
  %v158 = add i64 %v109, %v135
  %v159 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v158
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v159, ptr addrspace(1) %v157)
  %v160 = add i64 %v117, %v134
  %v161 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v160
  %v162 = add i64 %v120, %v135
  %v163 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v162
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v163, ptr addrspace(1) %v161)
  %v164 = add i64 %v128, %v134
  %v165 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v164
  %v166 = add i64 %v131, %v135
  %v167 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v166
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v167, ptr addrspace(1) %v165)
  call void @llvm.nvvm.cp.async.commit.group()
  %v168 = mul i64 %v9, 32
  %v169 = add i64 %v168, %v11
  %v170 = mul i64 %v169, 36
  %v171 = add i64 %v170, %v12
  %v172 = mul i64 %v12, 72
  %v173 = mul i64 %v10, 32
  %v174 = add i64 %v172, %v173
  %v175 = add i64 %v174, %v11
  %v176 = add i64 %v175, 2304
  br label %kt
kt:
  %v177 = phi i64 [0, %entry], [%v178, %issued]
  call void @llvm.nvvm.cp.async.wait.group(i32 0)
  call void @llvm.nvvm.barrier0()
  %v179 = add i64 %v177, 1
  %v180 = icmp ult i64 %v179, 32
  br i1 %v180, label %issue, label %issued
issue:
  %v181 = urem i64 %v179, 2
  %v182 = mul i64 %v179, 32
  %v183 = mul i64 %v182, 1
  %v184 = mul i64 %v182, 1024
  %v185 = mul i64 %v181, 4608
  %v186 = add i64 %v55, %v183
  %v187 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v186
  %v188 = add i64 %v57, %v185
  %v189 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v188
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v189, ptr addrspace(1) %v187)
  %v190 = add i64 %v65, %v183
  %v191 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v190
  %v192 = add i64 %v67, %v185
  %v193 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v192
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v193, ptr addrspace(1) %v191)
  %v194 = add i64 %v75, %v183
  %v195 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v194
  %v196 = add i64 %v77, %v185
  %v197 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v196
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v197, ptr addrspace(1) %v195)
  %v198 = add i64 %v85, %v183
  %v199 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v198
  %v200 = add i64 %v87, %v185
  %v201 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v200
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v201, ptr addrspace(1) %v199)
  %v202 = add i64 %v95, %v184
  %v203 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v202
  %v204 = add i64 %v98, %v185
  %v205 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v204
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v205, ptr addrspace(1) %v203)
  %v206 = add i64 %v106, %v184
  %v207 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v206
  %v208 = add i64 %v109, %v185
  %v209 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v208
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v209, ptr addrspace(1) %v207)
  %v210 = add i64 %v117, %v184
  %v211 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v210
  %v212 = add i64 %v120, %v185
  %v213 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v212
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v213, ptr addrspace(1) %v211)
  %v214 = add i64 %v128, %v184
  %v215 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v214
  %v216 = add i64 %v131, %v185
  %v217 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v216
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v217, ptr addrspace(1) %v215)
  br label %issued
issued:
  call void @llvm.nvvm.cp.async.commit.group()
  %v218 = urem i64 %v177, 2
  %v219 = mul i64 %v218, 4608
  %v220 = add i64 %v219, %v171
  %v221 = add i64 %v219, %v176
  %v222 = add i64 %v220, 0
  %v223 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v222
  %v224 = load float, ptr addrspace(3) %v223, align 4
  %v225 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v224)
  %v226 = add i64 %v220, 288
  %v227 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v226
  %v228 = load float, ptr addrspace(3) %v227, align 4
  %v229 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v228)
  %v230 = add i64 %v220, 4
  %v231 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v230
  %v232 = load float, ptr addrspace(3) %v231, align 4
  %v233 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v232)
  %v234 = add i64 %v220, 292
  %v235 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v234
  %v236 = load float, ptr addrspace(3) %v235, align 4
  %v237 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v236)
  %v238 = add i64 %v220, 576
  %v239 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v238
  %v240 = load float, ptr addrspace(3) %v239, align 4
  %v241 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v240)
  %v242 = add i64 %v220, 864
  %v243 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v242
  %v244 = load float, ptr addrspace(3) %v243, align 4
  %v245 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v244)
  %v246 = add i64 %v220, 580
  %v247 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v246
  %v248 = load float, ptr addrspace(3) %v247, align 4
  %v249 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v248)
  %v250 = add i64 %v220, 868
  %v251 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v250
  %v252 = load float, ptr addrspace(3) %v251, align 4
  %v253 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v252)
  %v254 = add i64 %v221, 0
  %v255 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v254
  %v256 = load float, ptr addrspace(3) %v255, align 4
  %v257 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v256)
  %v258 = add i64 %v221, 288
  %v259 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v258
  %v260 = load float, ptr addrspace(3) %v259, align 4
  %v261 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v260)
  %v262 = add i64 %v221, 8
  %v263 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v262
  %v264 = load float, ptr addrspace(3) %v263, align 4
  %v265 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v264)
  %v266 = add i64 %v221, 296
  %v267 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v266
  %v268 = load float, ptr addrspace(3) %v267, align 4
  %v269 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v268)
  %v270 = add i64 %v221, 16
  %v271 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v270
  %v272 = load float, ptr addrspace(3) %v271, align 4
  %v273 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v272)
  %v274 = add i64 %v221, 304
  %v275 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v274
  %v276 = load float, ptr addrspace(3) %v275, align 4
  %v277 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v276)
  %v278 = add i64 %v221, 24
  %v279 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v278
  %v280 = load float, ptr addrspace(3) %v279, align 4
  %v281 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v280)
  %v282 = add i64 %v221, 312
  %v283 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v282
  %v284 = load float, ptr addrspace(3) %v283, align 4
  %v285 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v284)
  %v286 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 0
  %v287 = load float, ptr %v286, align 4
  %v288 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 1
  %v289 = load float, ptr %v288, align 4
  %v290 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 2
  %v291 = load float, ptr %v290, align 4
  %v292 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 3
  %v293 = load float, ptr %v292, align 4
  %v294 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v225, i32 %v229, i32 %v233, i32 %v237, i32 %v257, i32 %v261, float %v287, float %v289, float %v291, float %v293)
  %v295 = extractvalue { float, float, float, float } %v294, 0
  store float %v295, ptr %v286, align 4
  %v296 = extractvalue { float, float, float, float } %v294, 1
  store float %v296, ptr %v288, align 4
  %v297 = extractvalue { float, float, float, float } %v294, 2
  store float %v297, ptr %v290, align 4
  %v298 = extractvalue { float, float, float, float } %v294, 3
  store float %v298, ptr %v292, align 4
  %v299 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 4
  %v300 = load float, ptr %v299, align 4
  %v301 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 5
  %v302 = load float, ptr %v301, align 4
  %v303 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 6
  %v304 = load float, ptr %v303, align 4
  %v305 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 7
  %v306 = load float, ptr %v305, align 4
  %v307 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v225, i32 %v229, i32 %v233, i32 %v237, i32 %v265, i32 %v269, float %v300, float %v302, float %v304, float %v306)
  %v308 = extractvalue { float, float, float, float } %v307, 0
  store float %v308, ptr %v299, align 4
  %v309 = extractvalue { float, float, float, float } %v307, 1
  store float %v309, ptr %v301, align 4
  %v310 = extractvalue { float, float, float, float } %v307, 2
  store float %v310, ptr %v303, align 4
  %v311 = extractvalue { float, float, float, float } %v307, 3
  store float %v311, ptr %v305, align 4
  %v312 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 8
  %v313 = load float, ptr %v312, align 4
  %v314 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 9
  %v315 = load float, ptr %v314, align 4
  %v316 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 10
  %v317 = load float, ptr %v316, align 4
  %v318 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 11
  %v319 = load float, ptr %v318, align 4
  %v320 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v225, i32 %v229, i32 %v233, i32 %v237, i32 %v273, i32 %v277, float %v313, float %v315, float %v317, float %v319)
  %v321 = extractvalue { float, float, float, float } %v320, 0
  store float %v321, ptr %v312, align 4
  %v322 = extractvalue { float, float, float, float } %v320, 1
  store float %v322, ptr %v314, align 4
  %v323 = extractvalue { float, float, float, float } %v320, 2
  store float %v323, ptr %v316, align 4
  %v324 = extractvalue { float, float, float, float } %v320, 3
  store float %v324, ptr %v318, align 4
  %v325 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 12
  %v326 = load float, ptr %v325, align 4
  %v327 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 13
  %v328 = load float, ptr %v327, align 4
  %v329 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 14
  %v330 = load float, ptr %v329, align 4
  %v331 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 15
  %v332 = load float, ptr %v331, align 4
  %v333 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v225, i32 %v229, i32 %v233, i32 %v237, i32 %v281, i32 %v285, float %v326, float %v328, float %v330, float %v332)
  %v334 = extractvalue { float, float, float, float } %v333, 0
  store float %v334, ptr %v325, align 4
  %v335 = extractvalue { float, float, float, float } %v333, 1
  store float %v335, ptr %v327, align 4
  %v336 = extractvalue { float, float, float, float } %v333, 2
  store float %v336, ptr %v329, align 4
  %v337 = extractvalue { float, float, float, float } %v333, 3
  store float %v337, ptr %v331, align 4
  %v338 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 16
  %v339 = load float, ptr %v338, align 4
  %v340 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 17
  %v341 = load float, ptr %v340, align 4
  %v342 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 18
  %v343 = load float, ptr %v342, align 4
  %v344 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 19
  %v345 = load float, ptr %v344, align 4
  %v346 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v241, i32 %v245, i32 %v249, i32 %v253, i32 %v257, i32 %v261, float %v339, float %v341, float %v343, float %v345)
  %v347 = extractvalue { float, float, float, float } %v346, 0
  store float %v347, ptr %v338, align 4
  %v348 = extractvalue { float, float, float, float } %v346, 1
  store float %v348, ptr %v340, align 4
  %v349 = extractvalue { float, float, float, float } %v346, 2
  store float %v349, ptr %v342, align 4
  %v350 = extractvalue { float, float, float, float } %v346, 3
  store float %v350, ptr %v344, align 4
  %v351 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 20
  %v352 = load float, ptr %v351, align 4
  %v353 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 21
  %v354 = load float, ptr %v353, align 4
  %v355 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 22
  %v356 = load float, ptr %v355, align 4
  %v357 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 23
  %v358 = load float, ptr %v357, align 4
  %v359 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v241, i32 %v245, i32 %v249, i32 %v253, i32 %v265, i32 %v269, float %v352, float %v354, float %v356, float %v358)
  %v360 = extractvalue { float, float, float, float } %v359, 0
  store float %v360, ptr %v351, align 4
  %v361 = extractvalue { float, float, float, float } %v359, 1
  store float %v361, ptr %v353, align 4
  %v362 = extractvalue { float, float, float, float } %v359, 2
  store float %v362, ptr %v355, align 4
  %v363 = extractvalue { float, float, float, float } %v359, 3
  store float %v363, ptr %v357, align 4
  %v364 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 24
  %v365 = load float, ptr %v364, align 4
  %v366 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 25
  %v367 = load float, ptr %v366, align 4
  %v368 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 26
  %v369 = load float, ptr %v368, align 4
  %v370 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 27
  %v371 = load float, ptr %v370, align 4
  %v372 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v241, i32 %v245, i32 %v249, i32 %v253, i32 %v273, i32 %v277, float %v365, float %v367, float %v369, float %v371)
  %v373 = extractvalue { float, float, float, float } %v372, 0
  store float %v373, ptr %v364, align 4
  %v374 = extractvalue { float, float, float, float } %v372, 1
  store float %v374, ptr %v366, align 4
  %v375 = extractvalue { float, float, float, float } %v372, 2
  store float %v375, ptr %v368, align 4
  %v376 = extractvalue { float, float, float, float } %v372, 3
  store float %v376, ptr %v370, align 4
  %v377 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 28
  %v378 = load float, ptr %v377, align 4
  %v379 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 29
  %v380 = load float, ptr %v379, align 4
  %v381 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 30
  %v382 = load float, ptr %v381, align 4
  %v383 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 31
  %v384 = load float, ptr %v383, align 4
  %v385 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v241, i32 %v245, i32 %v249, i32 %v253, i32 %v281, i32 %v285, float %v378, float %v380, float %v382, float %v384)
  %v386 = extractvalue { float, float, float, float } %v385, 0
  store float %v386, ptr %v377, align 4
  %v387 = extractvalue { float, float, float, float } %v385, 1
  store float %v387, ptr %v379, align 4
  %v388 = extractvalue { float, float, float, float } %v385, 2
  store float %v388, ptr %v381, align 4
  %v389 = extractvalue { float, float, float, float } %v385, 3
  store float %v389, ptr %v383, align 4
  %v390 = add i64 %v220, 8
  %v391 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v390
  %v392 = load float, ptr addrspace(3) %v391, align 4
  %v393 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v392)
  %v394 = add i64 %v220, 296
  %v395 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v394
  %v396 = load float, ptr addrspace(3) %v395, align 4
  %v397 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v396)
  %v398 = add i64 %v220, 12
  %v399 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v398
  %v400 = load float, ptr addrspace(3) %v399, align 4
  %v401 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v400)
  %v402 = add i64 %v220, 300
  %v403 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v402
  %v404 = load float, ptr addrspace(3) %v403, align 4
  %v405 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v404)
  %v406 = add i64 %v220, 584
  %v407 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v406
  %v408 = load float, ptr addrspace(3) %v407, align 4
  %v409 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v408)
  %v410 = add i64 %v220, 872
  %v411 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v410
  %v412 = load float, ptr addrspace(3) %v411, align 4
  %v413 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v412)
  %v414 = add i64 %v220, 588
  %v415 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v414
  %v416 = load float, ptr addrspace(3) %v415, align 4
  %v417 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v416)
  %v418 = add i64 %v220, 876
  %v419 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v418
  %v420 = load float, ptr addrspace(3) %v419, align 4
  %v421 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v420)
  %v422 = add i64 %v221, 576
  %v423 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v422
  %v424 = load float, ptr addrspace(3) %v423, align 4
  %v425 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v424)
  %v426 = add i64 %v221, 864
  %v427 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v426
  %v428 = load float, ptr addrspace(3) %v427, align 4
  %v429 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v428)
  %v430 = add i64 %v221, 584
  %v431 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v430
  %v432 = load float, ptr addrspace(3) %v431, align 4
  %v433 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v432)
  %v434 = add i64 %v221, 872
  %v435 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v434
  %v436 = load float, ptr addrspace(3) %v435, align 4
  %v437 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v436)
  %v438 = add i64 %v221, 592
  %v439 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v438
  %v440 = load float, ptr addrspace(3) %v439, align 4
  %v441 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v440)
  %v442 = add i64 %v221, 880
  %v443 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v442
  %v444 = load float, ptr addrspace(3) %v443, align 4
  %v445 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v444)
  %v446 = add i64 %v221, 600
  %v447 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v446
  %v448 = load float, ptr addrspace(3) %v447, align 4
  %v449 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v448)
  %v450 = add i64 %v221, 888
  %v451 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v450
  %v452 = load float, ptr addrspace(3) %v451, align 4
  %v453 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v452)
  %v454 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 0
  %v455 = load float, ptr %v454, align 4
  %v456 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 1
  %v457 = load float, ptr %v456, align 4
  %v458 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 2
  %v459 = load float, ptr %v458, align 4
  %v460 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 3
  %v461 = load float, ptr %v460, align 4
  %v462 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v393, i32 %v397, i32 %v401, i32 %v405, i32 %v425, i32 %v429, float %v455, float %v457, float %v459, float %v461)
  %v463 = extractvalue { float, float, float, float } %v462, 0
  store float %v463, ptr %v454, align 4
  %v464 = extractvalue { float, float, float, float } %v462, 1
  store float %v464, ptr %v456, align 4
  %v465 = extractvalue { float, float, float, float } %v462, 2
  store float %v465, ptr %v458, align 4
  %v466 = extractvalue { float, float, float, float } %v462, 3
  store float %v466, ptr %v460, align 4
  %v467 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 4
  %v468 = load float, ptr %v467, align 4
  %v469 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 5
  %v470 = load float, ptr %v469, align 4
  %v471 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 6
  %v472 = load float, ptr %v471, align 4
  %v473 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 7
  %v474 = load float, ptr %v473, align 4
  %v475 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v393, i32 %v397, i32 %v401, i32 %v405, i32 %v433, i32 %v437, float %v468, float %v470, float %v472, float %v474)
  %v476 = extractvalue { float, float, float, float } %v475, 0
  store float %v476, ptr %v467, align 4
  %v477 = extractvalue { float, float, float, float } %v475, 1
  store float %v477, ptr %v469, align 4
  %v478 = extractvalue { float, float, float, float } %v475, 2
  store float %v478, ptr %v471, align 4
  %v479 = extractvalue { float, float, float, float } %v475, 3
  store float %v479, ptr %v473, align 4
  %v480 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 8
  %v481 = load float, ptr %v480, align 4
  %v482 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 9
  %v483 = load float, ptr %v482, align 4
  %v484 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 10
  %v485 = load float, ptr %v484, align 4
  %v486 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 11
  %v487 = load float, ptr %v486, align 4
  %v488 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v393, i32 %v397, i32 %v401, i32 %v405, i32 %v441, i32 %v445, float %v481, float %v483, float %v485, float %v487)
  %v489 = extractvalue { float, float, float, float } %v488, 0
  store float %v489, ptr %v480, align 4
  %v490 = extractvalue { float, float, float, float } %v488, 1
  store float %v490, ptr %v482, align 4
  %v491 = extractvalue { float, float, float, float } %v488, 2
  store float %v491, ptr %v484, align 4
  %v492 = extractvalue { float, float, float, float } %v488, 3
  store float %v492, ptr %v486, align 4
  %v493 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 12
  %v494 = load float, ptr %v493, align 4
  %v495 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 13
  %v496 = load float, ptr %v495, align 4
  %v497 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 14
  %v498 = load float, ptr %v497, align 4
  %v499 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 15
  %v500 = load float, ptr %v499, align 4
  %v501 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v393, i32 %v397, i32 %v401, i32 %v405, i32 %v449, i32 %v453, float %v494, float %v496, float %v498, float %v500)
  %v502 = extractvalue { float, float, float, float } %v501, 0
  store float %v502, ptr %v493, align 4
  %v503 = extractvalue { float, float, float, float } %v501, 1
  store float %v503, ptr %v495, align 4
  %v504 = extractvalue { float, float, float, float } %v501, 2
  store float %v504, ptr %v497, align 4
  %v505 = extractvalue { float, float, float, float } %v501, 3
  store float %v505, ptr %v499, align 4
  %v506 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 16
  %v507 = load float, ptr %v506, align 4
  %v508 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 17
  %v509 = load float, ptr %v508, align 4
  %v510 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 18
  %v511 = load float, ptr %v510, align 4
  %v512 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 19
  %v513 = load float, ptr %v512, align 4
  %v514 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v409, i32 %v413, i32 %v417, i32 %v421, i32 %v425, i32 %v429, float %v507, float %v509, float %v511, float %v513)
  %v515 = extractvalue { float, float, float, float } %v514, 0
  store float %v515, ptr %v506, align 4
  %v516 = extractvalue { float, float, float, float } %v514, 1
  store float %v516, ptr %v508, align 4
  %v517 = extractvalue { float, float, float, float } %v514, 2
  store float %v517, ptr %v510, align 4
  %v518 = extractvalue { float, float, float, float } %v514, 3
  store float %v518, ptr %v512, align 4
  %v519 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 20
  %v520 = load float, ptr %v519, align 4
  %v521 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 21
  %v522 = load float, ptr %v521, align 4
  %v523 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 22
  %v524 = load float, ptr %v523, align 4
  %v525 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 23
  %v526 = load float, ptr %v525, align 4
  %v527 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v409, i32 %v413, i32 %v417, i32 %v421, i32 %v433, i32 %v437, float %v520, float %v522, float %v524, float %v526)
  %v528 = extractvalue { float, float, float, float } %v527, 0
  store float %v528, ptr %v519, align 4
  %v529 = extractvalue { float, float, float, float } %v527, 1
  store float %v529, ptr %v521, align 4
  %v530 = extractvalue { float, float, float, float } %v527, 2
  store float %v530, ptr %v523, align 4
  %v531 = extractvalue { float, float, float, float } %v527, 3
  store float %v531, ptr %v525, align 4
  %v532 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 24
  %v533 = load float, ptr %v532, align 4
  %v534 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 25
  %v535 = load float, ptr %v534, align 4
  %v536 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 26
  %v537 = load float, ptr %v536, align 4
  %v538 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 27
  %v539 = load float, ptr %v538, align 4
  %v540 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v409, i32 %v413, i32 %v417, i32 %v421, i32 %v441, i32 %v445, float %v533, float %v535, float %v537, float %v539)
  %v541 = extractvalue { float, float, float, float } %v540, 0
  store float %v541, ptr %v532, align 4
  %v542 = extractvalue { float, float, float, float } %v540, 1
  store float %v542, ptr %v534, align 4
  %v543 = extractvalue { float, float, float, float } %v540, 2
  store float %v543, ptr %v536, align 4
  %v544 = extractvalue { float, float, float, float } %v540, 3
  store float %v544, ptr %v538, align 4
  %v545 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 28
  %v546 = load float, ptr %v545, align 4
  %v547 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 29
  %v548 = load float, ptr %v547, align 4
  %v549 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 30
  %v550 = load float, ptr %v549, align 4
  %v551 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 31
  %v552 = load float, ptr %v551, align 4
  %v553 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v409, i32 %v413, i32 %v417, i32 %v421, i32 %v449, i32 %v453, float %v546, float %v548, float %v550, float %v552)
  %v554 = extractvalue { float, float, float, float } %v553, 0
  store float %v554, ptr %v545, align 4
  %v555 = extractvalue { float, float, float, float } %v553, 1
  store float %v555, ptr %v547, align 4
  %v556 = extractvalue { float, float, float, float } %v553, 2
  store float %v556, ptr %v549, align 4
  %v557 = extractvalue { float, float, float, float } %v553, 3
  store float %v557, ptr %v551, align 4
  %v558 = add i64 %v220, 16
  %v559 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v558
  %v560 = load float, ptr addrspace(3) %v559, align 4
  %v561 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v560)
  %v562 = add i64 %v220, 304
  %v563 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v562
  %v564 = load float, ptr addrspace(3) %v563, align 4
  %v565 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v564)
  %v566 = add i64 %v220, 20
  %v567 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v566
  %v568 = load float, ptr addrspace(3) %v567, align 4
  %v569 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v568)
  %v570 = add i64 %v220, 308
  %v571 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v570
  %v572 = load float, ptr addrspace(3) %v571, align 4
  %v573 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v572)
  %v574 = add i64 %v220, 592
  %v575 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v574
  %v576 = load float, ptr addrspace(3) %v575, align 4
  %v577 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v576)
  %v578 = add i64 %v220, 880
  %v579 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v578
  %v580 = load float, ptr addrspace(3) %v579, align 4
  %v581 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v580)
  %v582 = add i64 %v220, 596
  %v583 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v582
  %v584 = load float, ptr addrspace(3) %v583, align 4
  %v585 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v584)
  %v586 = add i64 %v220, 884
  %v587 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v586
  %v588 = load float, ptr addrspace(3) %v587, align 4
  %v589 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v588)
  %v590 = add i64 %v221, 1152
  %v591 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v590
  %v592 = load float, ptr addrspace(3) %v591, align 4
  %v593 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v592)
  %v594 = add i64 %v221, 1440
  %v595 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v594
  %v596 = load float, ptr addrspace(3) %v595, align 4
  %v597 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v596)
  %v598 = add i64 %v221, 1160
  %v599 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v598
  %v600 = load float, ptr addrspace(3) %v599, align 4
  %v601 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v600)
  %v602 = add i64 %v221, 1448
  %v603 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v602
  %v604 = load float, ptr addrspace(3) %v603, align 4
  %v605 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v604)
  %v606 = add i64 %v221, 1168
  %v607 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v606
  %v608 = load float, ptr addrspace(3) %v607, align 4
  %v609 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v608)
  %v610 = add i64 %v221, 1456
  %v611 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v610
  %v612 = load float, ptr addrspace(3) %v611, align 4
  %v613 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v612)
  %v614 = add i64 %v221, 1176
  %v615 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v614
  %v616 = load float, ptr addrspace(3) %v615, align 4
  %v617 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v616)
  %v618 = add i64 %v221, 1464
  %v619 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v618
  %v620 = load float, ptr addrspace(3) %v619, align 4
  %v621 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v620)
  %v622 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 0
  %v623 = load float, ptr %v622, align 4
  %v624 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 1
  %v625 = load float, ptr %v624, align 4
  %v626 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 2
  %v627 = load float, ptr %v626, align 4
  %v628 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 3
  %v629 = load float, ptr %v628, align 4
  %v630 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v561, i32 %v565, i32 %v569, i32 %v573, i32 %v593, i32 %v597, float %v623, float %v625, float %v627, float %v629)
  %v631 = extractvalue { float, float, float, float } %v630, 0
  store float %v631, ptr %v622, align 4
  %v632 = extractvalue { float, float, float, float } %v630, 1
  store float %v632, ptr %v624, align 4
  %v633 = extractvalue { float, float, float, float } %v630, 2
  store float %v633, ptr %v626, align 4
  %v634 = extractvalue { float, float, float, float } %v630, 3
  store float %v634, ptr %v628, align 4
  %v635 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 4
  %v636 = load float, ptr %v635, align 4
  %v637 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 5
  %v638 = load float, ptr %v637, align 4
  %v639 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 6
  %v640 = load float, ptr %v639, align 4
  %v641 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 7
  %v642 = load float, ptr %v641, align 4
  %v643 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v561, i32 %v565, i32 %v569, i32 %v573, i32 %v601, i32 %v605, float %v636, float %v638, float %v640, float %v642)
  %v644 = extractvalue { float, float, float, float } %v643, 0
  store float %v644, ptr %v635, align 4
  %v645 = extractvalue { float, float, float, float } %v643, 1
  store float %v645, ptr %v637, align 4
  %v646 = extractvalue { float, float, float, float } %v643, 2
  store float %v646, ptr %v639, align 4
  %v647 = extractvalue { float, float, float, float } %v643, 3
  store float %v647, ptr %v641, align 4
  %v648 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 8
  %v649 = load float, ptr %v648, align 4
  %v650 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 9
  %v651 = load float, ptr %v650, align 4
  %v652 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 10
  %v653 = load float, ptr %v652, align 4
  %v654 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 11
  %v655 = load float, ptr %v654, align 4
  %v656 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v561, i32 %v565, i32 %v569, i32 %v573, i32 %v609, i32 %v613, float %v649, float %v651, float %v653, float %v655)
  %v657 = extractvalue { float, float, float, float } %v656, 0
  store float %v657, ptr %v648, align 4
  %v658 = extractvalue { float, float, float, float } %v656, 1
  store float %v658, ptr %v650, align 4
  %v659 = extractvalue { float, float, float, float } %v656, 2
  store float %v659, ptr %v652, align 4
  %v660 = extractvalue { float, float, float, float } %v656, 3
  store float %v660, ptr %v654, align 4
  %v661 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 12
  %v662 = load float, ptr %v661, align 4
  %v663 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 13
  %v664 = load float, ptr %v663, align 4
  %v665 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 14
  %v666 = load float, ptr %v665, align 4
  %v667 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 15
  %v668 = load float, ptr %v667, align 4
  %v669 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v561, i32 %v565, i32 %v569, i32 %v573, i32 %v617, i32 %v621, float %v662, float %v664, float %v666, float %v668)
  %v670 = extractvalue { float, float, float, float } %v669, 0
  store float %v670, ptr %v661, align 4
  %v671 = extractvalue { float, float, float, float } %v669, 1
  store float %v671, ptr %v663, align 4
  %v672 = extractvalue { float, float, float, float } %v669, 2
  store float %v672, ptr %v665, align 4
  %v673 = extractvalue { float, float, float, float } %v669, 3
  store float %v673, ptr %v667, align 4
  %v674 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 16
  %v675 = load float, ptr %v674, align 4
  %v676 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 17
  %v677 = load float, ptr %v676, align 4
  %v678 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 18
  %v679 = load float, ptr %v678, align 4
  %v680 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 19
  %v681 = load float, ptr %v680, align 4
  %v682 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v577, i32 %v581, i32 %v585, i32 %v589, i32 %v593, i32 %v597, float %v675, float %v677, float %v679, float %v681)
  %v683 = extractvalue { float, float, float, float } %v682, 0
  store float %v683, ptr %v674, align 4
  %v684 = extractvalue { float, float, float, float } %v682, 1
  store float %v684, ptr %v676, align 4
  %v685 = extractvalue { float, float, float, float } %v682, 2
  store float %v685, ptr %v678, align 4
  %v686 = extractvalue { float, float, float, float } %v682, 3
  store float %v686, ptr %v680, align 4
  %v687 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 20
  %v688 = load float, ptr %v687, align 4
  %v689 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 21
  %v690 = load float, ptr %v689, align 4
  %v691 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 22
  %v692 = load float, ptr %v691, align 4
  %v693 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 23
  %v694 = load float, ptr %v693, align 4
  %v695 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v577, i32 %v581, i32 %v585, i32 %v589, i32 %v601, i32 %v605, float %v688, float %v690, float %v692, float %v694)
  %v696 = extractvalue { float, float, float, float } %v695, 0
  store float %v696, ptr %v687, align 4
  %v697 = extractvalue { float, float, float, float } %v695, 1
  store float %v697, ptr %v689, align 4
  %v698 = extractvalue { float, float, float, float } %v695, 2
  store float %v698, ptr %v691, align 4
  %v699 = extractvalue { float, float, float, float } %v695, 3
  store float %v699, ptr %v693, align 4
  %v700 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 24
  %v701 = load float, ptr %v700, align 4
  %v702 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 25
  %v703 = load float, ptr %v702, align 4
  %v704 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 26
  %v705 = load float, ptr %v704, align 4
  %v706 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 27
  %v707 = load float, ptr %v706, align 4
  %v708 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v577, i32 %v581, i32 %v585, i32 %v589, i32 %v609, i32 %v613, float %v701, float %v703, float %v705, float %v707)
  %v709 = extractvalue { float, float, float, float } %v708, 0
  store float %v709, ptr %v700, align 4
  %v710 = extractvalue { float, float, float, float } %v708, 1
  store float %v710, ptr %v702, align 4
  %v711 = extractvalue { float, float, float, float } %v708, 2
  store float %v711, ptr %v704, align 4
  %v712 = extractvalue { float, float, float, float } %v708, 3
  store float %v712, ptr %v706, align 4
  %v713 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 28
  %v714 = load float, ptr %v713, align 4
  %v715 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 29
  %v716 = load float, ptr %v715, align 4
  %v717 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 30
  %v718 = load float, ptr %v717, align 4
  %v719 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 31
  %v720 = load float, ptr %v719, align 4
  %v721 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v577, i32 %v581, i32 %v585, i32 %v589, i32 %v617, i32 %v621, float %v714, float %v716, float %v718, float %v720)
  %v722 = extractvalue { float, float, float, float } %v721, 0
  store float %v722, ptr %v713, align 4
  %v723 = extractvalue { float, float, float, float } %v721, 1
  store float %v723, ptr %v715, align 4
  %v724 = extractvalue { float, float, float, float } %v721, 2
  store float %v724, ptr %v717, align 4
  %v725 = extractvalue { float, float, float, float } %v721, 3
  store float %v725, ptr %v719, align 4
  %v726 = add i64 %v220, 24
  %v727 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v726
  %v728 = load float, ptr addrspace(3) %v727, align 4
  %v729 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v728)
  %v730 = add i64 %v220, 312
  %v731 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v730
  %v732 = load float, ptr addrspace(3) %v731, align 4
  %v733 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v732)
  %v734 = add i64 %v220, 28
  %v735 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v734
  %v736 = load float, ptr addrspace(3) %v735, align 4
  %v737 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v736)
  %v738 = add i64 %v220, 316
  %v739 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v738
  %v740 = load float, ptr addrspace(3) %v739, align 4
  %v741 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v740)
  %v742 = add i64 %v220, 600
  %v743 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v742
  %v744 = load float, ptr addrspace(3) %v743, align 4
  %v745 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v744)
  %v746 = add i64 %v220, 888
  %v747 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v746
  %v748 = load float, ptr addrspace(3) %v747, align 4
  %v749 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v748)
  %v750 = add i64 %v220, 604
  %v751 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v750
  %v752 = load float, ptr addrspace(3) %v751, align 4
  %v753 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v752)
  %v754 = add i64 %v220, 892
  %v755 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v754
  %v756 = load float, ptr addrspace(3) %v755, align 4
  %v757 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v756)
  %v758 = add i64 %v221, 1728
  %v759 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v758
  %v760 = load float, ptr addrspace(3) %v759, align 4
  %v761 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v760)
  %v762 = add i64 %v221, 2016
  %v763 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v762
  %v764 = load float, ptr addrspace(3) %v763, align 4
  %v765 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v764)
  %v766 = add i64 %v221, 1736
  %v767 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v766
  %v768 = load float, ptr addrspace(3) %v767, align 4
  %v769 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v768)
  %v770 = add i64 %v221, 2024
  %v771 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v770
  %v772 = load float, ptr addrspace(3) %v771, align 4
  %v773 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v772)
  %v774 = add i64 %v221, 1744
  %v775 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v774
  %v776 = load float, ptr addrspace(3) %v775, align 4
  %v777 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v776)
  %v778 = add i64 %v221, 2032
  %v779 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v778
  %v780 = load float, ptr addrspace(3) %v779, align 4
  %v781 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v780)
  %v782 = add i64 %v221, 1752
  %v783 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v782
  %v784 = load float, ptr addrspace(3) %v783, align 4
  %v785 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v784)
  %v786 = add i64 %v221, 2040
  %v787 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v786
  %v788 = load float, ptr addrspace(3) %v787, align 4
  %v789 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v788)
  %v790 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 0
  %v791 = load float, ptr %v790, align 4
  %v792 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 1
  %v793 = load float, ptr %v792, align 4
  %v794 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 2
  %v795 = load float, ptr %v794, align 4
  %v796 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 3
  %v797 = load float, ptr %v796, align 4
  %v798 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v729, i32 %v733, i32 %v737, i32 %v741, i32 %v761, i32 %v765, float %v791, float %v793, float %v795, float %v797)
  %v799 = extractvalue { float, float, float, float } %v798, 0
  store float %v799, ptr %v790, align 4
  %v800 = extractvalue { float, float, float, float } %v798, 1
  store float %v800, ptr %v792, align 4
  %v801 = extractvalue { float, float, float, float } %v798, 2
  store float %v801, ptr %v794, align 4
  %v802 = extractvalue { float, float, float, float } %v798, 3
  store float %v802, ptr %v796, align 4
  %v803 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 4
  %v804 = load float, ptr %v803, align 4
  %v805 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 5
  %v806 = load float, ptr %v805, align 4
  %v807 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 6
  %v808 = load float, ptr %v807, align 4
  %v809 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 7
  %v810 = load float, ptr %v809, align 4
  %v811 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v729, i32 %v733, i32 %v737, i32 %v741, i32 %v769, i32 %v773, float %v804, float %v806, float %v808, float %v810)
  %v812 = extractvalue { float, float, float, float } %v811, 0
  store float %v812, ptr %v803, align 4
  %v813 = extractvalue { float, float, float, float } %v811, 1
  store float %v813, ptr %v805, align 4
  %v814 = extractvalue { float, float, float, float } %v811, 2
  store float %v814, ptr %v807, align 4
  %v815 = extractvalue { float, float, float, float } %v811, 3
  store float %v815, ptr %v809, align 4
  %v816 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 8
  %v817 = load float, ptr %v816, align 4
  %v818 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 9
  %v819 = load float, ptr %v818, align 4
  %v820 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 10
  %v821 = load float, ptr %v820, align 4
  %v822 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 11
  %v823 = load float, ptr %v822, align 4
  %v824 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v729, i32 %v733, i32 %v737, i32 %v741, i32 %v777, i32 %v781, float %v817, float %v819, float %v821, float %v823)
  %v825 = extractvalue { float, float, float, float } %v824, 0
  store float %v825, ptr %v816, align 4
  %v826 = extractvalue { float, float, float, float } %v824, 1
  store float %v826, ptr %v818, align 4
  %v827 = extractvalue { float, float, float, float } %v824, 2
  store float %v827, ptr %v820, align 4
  %v828 = extractvalue { float, float, float, float } %v824, 3
  store float %v828, ptr %v822, align 4
  %v829 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 12
  %v830 = load float, ptr %v829, align 4
  %v831 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 13
  %v832 = load float, ptr %v831, align 4
  %v833 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 14
  %v834 = load float, ptr %v833, align 4
  %v835 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 15
  %v836 = load float, ptr %v835, align 4
  %v837 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v729, i32 %v733, i32 %v737, i32 %v741, i32 %v785, i32 %v789, float %v830, float %v832, float %v834, float %v836)
  %v838 = extractvalue { float, float, float, float } %v837, 0
  store float %v838, ptr %v829, align 4
  %v839 = extractvalue { float, float, float, float } %v837, 1
  store float %v839, ptr %v831, align 4
  %v840 = extractvalue { float, float, float, float } %v837, 2
  store float %v840, ptr %v833, align 4
  %v841 = extractvalue { float, float, float, float } %v837, 3
  store float %v841, ptr %v835, align 4
  %v842 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 16
  %v843 = load float, ptr %v842, align 4
  %v844 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 17
  %v845 = load float, ptr %v844, align 4
  %v846 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 18
  %v847 = load float, ptr %v846, align 4
  %v848 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 19
  %v849 = load float, ptr %v848, align 4
  %v850 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v745, i32 %v749, i32 %v753, i32 %v757, i32 %v761, i32 %v765, float %v843, float %v845, float %v847, float %v849)
  %v851 = extractvalue { float, float, float, float } %v850, 0
  store float %v851, ptr %v842, align 4
  %v852 = extractvalue { float, float, float, float } %v850, 1
  store float %v852, ptr %v844, align 4
  %v853 = extractvalue { float, float, float, float } %v850, 2
  store float %v853, ptr %v846, align 4
  %v854 = extractvalue { float, float, float, float } %v850, 3
  store float %v854, ptr %v848, align 4
  %v855 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 20
  %v856 = load float, ptr %v855, align 4
  %v857 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 21
  %v858 = load float, ptr %v857, align 4
  %v859 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 22
  %v860 = load float, ptr %v859, align 4
  %v861 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 23
  %v862 = load float, ptr %v861, align 4
  %v863 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v745, i32 %v749, i32 %v753, i32 %v757, i32 %v769, i32 %v773, float %v856, float %v858, float %v860, float %v862)
  %v864 = extractvalue { float, float, float, float } %v863, 0
  store float %v864, ptr %v855, align 4
  %v865 = extractvalue { float, float, float, float } %v863, 1
  store float %v865, ptr %v857, align 4
  %v866 = extractvalue { float, float, float, float } %v863, 2
  store float %v866, ptr %v859, align 4
  %v867 = extractvalue { float, float, float, float } %v863, 3
  store float %v867, ptr %v861, align 4
  %v868 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 24
  %v869 = load float, ptr %v868, align 4
  %v870 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 25
  %v871 = load float, ptr %v870, align 4
  %v872 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 26
  %v873 = load float, ptr %v872, align 4
  %v874 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 27
  %v875 = load float, ptr %v874, align 4
  %v876 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v745, i32 %v749, i32 %v753, i32 %v757, i32 %v777, i32 %v781, float %v869, float %v871, float %v873, float %v875)
  %v877 = extractvalue { float, float, float, float } %v876, 0
  store float %v877, ptr %v868, align 4
  %v878 = extractvalue { float, float, float, float } %v876, 1
  store float %v878, ptr %v870, align 4
  %v879 = extractvalue { float, float, float, float } %v876, 2
  store float %v879, ptr %v872, align 4
  %v880 = extractvalue { float, float, float, float } %v876, 3
  store float %v880, ptr %v874, align 4
  %v881 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 28
  %v882 = load float, ptr %v881, align 4
  %v883 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 29
  %v884 = load float, ptr %v883, align 4
  %v885 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 30
  %v886 = load float, ptr %v885, align 4
  %v887 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 31
  %v888 = load float, ptr %v887, align 4
  %v889 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v745, i32 %v749, i32 %v753, i32 %v757, i32 %v785, i32 %v789, float %v882, float %v884, float %v886, float %v888)
  %v890 = extractvalue { float, float, float, float } %v889, 0
  store float %v890, ptr %v881, align 4
  %v891 = extractvalue { float, float, float, float } %v889, 1
  store float %v891, ptr %v883, align 4
  %v892 = extractvalue { float, float, float, float } %v889, 2
  store float %v892, ptr %v885, align 4
  %v893 = extractvalue { float, float, float, float } %v889, 3
  store float %v893, ptr %v887, align 4
  %v178 = add i64 %v177, 1
  %v894 = icmp eq i64 %v178, 32
  br i1 %v894, label %done, label %kt
done:
  %v895 = mul i64 %v9, 32
  %v896 = add i64 %v895, %v13
  %v897 = add i64 %v896, %v11
  %v898 = mul i64 %v10, 32
  %v899 = add i64 %v898, %v14
  %v900 = mul i64 %v12, 2
  %v901 = add i64 %v899, %v900
  %v902 = add i64 %v897, 0
  %v903 = mul i64 %v902, 1024
  %v904 = add i64 %v903, %v901
  %v905 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 0
  %v906 = load float, ptr %v905, align 4
  %v907 = insertelement <2 x float> poison, float %v906, i64 0
  %v908 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 1
  %v909 = load float, ptr %v908, align 4
  %v910 = insertelement <2 x float> %v907, float %v909, i64 1
  %v911 = add i64 %v904, 0
  %v912 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v911
  store <2 x float> %v910, ptr addrspace(1) %v912, align 8
  %v913 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 4
  %v914 = load float, ptr %v913, align 4
  %v915 = insertelement <2 x float> poison, float %v914, i64 0
  %v916 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 5
  %v917 = load float, ptr %v916, align 4
  %v918 = insertelement <2 x float> %v915, float %v917, i64 1
  %v919 = add i64 %v904, 8
  %v920 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v919
  store <2 x float> %v918, ptr addrspace(1) %v920, align 8
  %v921 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 8
  %v922 = load float, ptr %v921, align 4
  %v923 = insertelement <2 x float> poison, float %v922, i64 0
  %v924 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 9
  %v925 = load float, ptr %v924, align 4
  %v926 = insertelement <2 x float> %v923, float %v925, i64 1
  %v927 = add i64 %v904, 16
  %v928 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v927
  store <2 x float> %v926, ptr addrspace(1) %v928, align 8
  %v929 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 12
  %v930 = load float, ptr %v929, align 4
  %v931 = insertelement <2 x float> poison, float %v930, i64 0
  %v932 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 13
  %v933 = load float, ptr %v932, align 4
  %v934 = insertelement <2 x float> %v931, float %v933, i64 1
  %v935 = add i64 %v904, 24
  %v936 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v935
  store <2 x float> %v934, ptr addrspace(1) %v936, align 8
  %v937 = add i64 %v897, 8
  %v938 = mul i64 %v937, 1024
  %v939 = add i64 %v938, %v901
  %v940 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 2
  %v941 = load float, ptr %v940, align 4
  %v942 = insertelement <2 x float> poison, float %v941, i64 0
  %v943 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 3
  %v944 = load float, ptr %v943, align 4
  %v945 = insertelement <2 x float> %v942, float %v944, i64 1
  %v946 = add i64 %v939, 0
  %v947 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v946
  store <2 x float> %v945, ptr addrspace(1) %v947, align 8
  %v948 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 6
  %v949 = load float, ptr %v948, align 4
  %v950 = insertelement <2 x float> poison, float %v949, i64 0
  %v951 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 7
  %v952 = load float, ptr %v951, align 4
  %v953 = insertelement <2 x float> %v950, float %v952, i64 1
  %v954 = add i64 %v939, 8
  %v955 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v954
  store <2 x float> %v953, ptr addrspace(1) %v955, align 8
  %v956 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 10
  %v957 = load float, ptr %v956, align 4
  %v958 = insertelement <2 x float> poison, float %v957, i64 0
  %v959 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 11
  %v960 = load float, ptr %v959, align 4
  %v961 = insertelement <2 x float> %v958, float %v960, i64 1
  %v962 = add i64 %v939, 16
  %v963 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v962
  store <2 x float> %v961, ptr addrspace(1) %v963, align 8
  %v964 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 14
  %v965 = load float, ptr %v964, align 4
  %v966 = insertelement <2 x float> poison, float %v965, i64 0
  %v967 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 15
  %v968 = load float, ptr %v967, align 4
  %v969 = insertelement <2 x float> %v966, float %v968, i64 1
  %v970 = add i64 %v939, 24
  %v971 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v970
  store <2 x float> %v969, ptr addrspace(1) %v971, align 8
  %v972 = add i64 %v897, 16
  %v973 = mul i64 %v972, 1024
  %v974 = add i64 %v973, %v901
  %v975 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 16
  %v976 = load float, ptr %v975, align 4
  %v977 = insertelement <2 x float> poison, float %v976, i64 0
  %v978 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 17
  %v979 = load float, ptr %v978, align 4
  %v980 = insertelement <2 x float> %v977, float %v979, i64 1
  %v981 = add i64 %v974, 0
  %v982 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v981
  store <2 x float> %v980, ptr addrspace(1) %v982, align 8
  %v983 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 20
  %v984 = load float, ptr %v983, align 4
  %v985 = insertelement <2 x float> poison, float %v984, i64 0
  %v986 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 21
  %v987 = load float, ptr %v986, align 4
  %v988 = insertelement <2 x float> %v985, float %v987, i64 1
  %v989 = add i64 %v974, 8
  %v990 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v989
  store <2 x float> %v988, ptr addrspace(1) %v990, align 8
  %v991 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 24
  %v992 = load float, ptr %v991, align 4
  %v993 = insertelement <2 x float> poison, float %v992, i64 0
  %v994 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 25
  %v995 = load float, ptr %v994, align 4
  %v996 = insertelement <2 x float> %v993, float %v995, i64 1
  %v997 = add i64 %v974, 16
  %v998 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v997
  store <2 x float> %v996, ptr addrspace(1) %v998, align 8
  %v999 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 28
  %v1000 = load float, ptr %v999, align 4
  %v1001 = insertelement <2 x float> poison, float %v1000, i64 0
  %v1002 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 29
  %v1003 = load float, ptr %v1002, align 4
  %v1004 = insertelement <2 x float> %v1001, float %v1003, i64 1
  %v1005 = add i64 %v974, 24
  %v1006 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v1005
  store <2 x float> %v1004, ptr addrspace(1) %v1006, align 8
  %v1007 = add i64 %v897, 24
  %v1008 = mul i64 %v1007, 1024
  %v1009 = add i64 %v1008, %v901
  %v1010 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 18
  %v1011 = load float, ptr %v1010, align 4
  %v1012 = insertelement <2 x float> poison, float %v1011, i64 0
  %v1013 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 19
  %v1014 = load float, ptr %v1013, align 4
  %v1015 = insertelement <2 x float> %v1012, float %v1014, i64 1
  %v1016 = add i64 %v1009, 0
  %v1017 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v1016
  store <2 x float> %v1015, ptr addrspace(1) %v1017, align 8
  %v1018 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 22
  %v1019 = load float, ptr %v1018, align 4
  %v1020 = insertelement <2 x float> poison, float %v1019, i64 0
  %v1021 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 23
  %v1022 = load float, ptr %v1021, align 4
  %v1023 = insertelement <2 x float> %v1020, float %v1022, i64 1
  %v1024 = add i64 %v1009, 8
  %v1025 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v1024
  store <2 x float> %v1023, ptr addrspace(1) %v1025, align 8
  %v1026 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 26
  %v1027 = load float, ptr %v1026, align 4
  %v1028 = insertelement <2 x float> poison, float %v1027, i64 0
  %v1029 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 27
  %v1030 = load float, ptr %v1029, align 4
  %v1031 = insertelement <2 x float> %v1028, float %v1030, i64 1
  %v1032 = add i64 %v1009, 16
  %v1033 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v1032
  store <2 x float> %v1031, ptr addrspace(1) %v1033, align 8
  %v1034 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 30
  %v1035 = load float, ptr %v1034, align 4
  %v1036 = insertelement <2 x float> poison, float %v1035, i64 0
  %v1037 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 31
  %v1038 = load float, ptr %v1037, align 4
  %v1039 = insertelement <2 x float> %v1036, float %v1038, i64 1
  %v1040 = add i64 %v1009, 24
  %v1041 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v1040
  store <2 x float> %v1039, ptr addrspace(1) %v1041, align 8
  ret void
}

define internal float @fn1(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 7, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 13, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 101, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 50, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to float
  store float %t33, ptr %o1
  %t34 = load float, ptr %o1
  ret float %t34
}

define ptx_kernel void @mapal_gen_7a2ade86c804ef09(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call float @fn1(i32 %x)
  %p = getelementptr inbounds float, ptr addrspace(1) %o, i64 %i
  store float %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

define internal float @fn2(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 7, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 57, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 101, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 50, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to float
  store float %t33, ptr %o1
  %t34 = load float, ptr %o1
  ret float %t34
}

define ptx_kernel void @mapal_gen_1aeae5b5ba14d87e(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call float @fn2(i32 %x)
  %p = getelementptr inbounds float, ptr addrspace(1) %o, i64 %i
  store float %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

