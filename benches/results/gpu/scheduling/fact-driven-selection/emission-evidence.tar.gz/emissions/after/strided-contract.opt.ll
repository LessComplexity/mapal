; ModuleID = '/private/tmp/mapal-gpu-schedule-facts/emissions/after/strided-contract.device.ll'
source_filename = "/private/tmp/mapal-gpu-schedule-facts/emissions/after/strided-contract.device.ll"
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 2147483647) i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define ptx_kernel void @mapal_tile_d51aa3cbc2658d57(ptr addrspace(1) noalias readonly align 4 captures(none) %a, ptr addrspace(1) noalias readonly align 4 captures(none) %b, ptr addrspace(1) noalias writeonly align 4 captures(none) %o) local_unnamed_addr #1 {
entry:
  %v1 = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = zext nneg i32 %v1 to i64
  %v3 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v7 = icmp eq i32 %v3, 0
  br i1 %v7, label %kloop.preheader, label %done

kloop.preheader:                                  ; preds = %entry
  %.idx = shl nuw nsw i64 %v2, 9
  %0 = getelementptr i8, ptr addrspace(1) %b, i64 %.idx
  br label %kloop

kloop:                                            ; preds = %kloop, %kloop.preheader
  %v18 = phi i64 [ 0, %kloop.preheader ], [ %v20.7, %kloop ]
  %v19 = phi float [ 2.000000e+00, %kloop.preheader ], [ %v29.7, %kloop ]
  %v23 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v18
  %v24 = load float, ptr addrspace(1) %v23, align 4
  %v27 = getelementptr float, ptr addrspace(1) %0, i64 %v18
  %v28 = load float, ptr addrspace(1) %v27, align 4
  %v30 = fmul float %v24, %v28
  %v29 = fadd float %v19, %v30
  %v20 = or disjoint i64 %v18, 1
  %v23.1 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v20
  %v24.1 = load float, ptr addrspace(1) %v23.1, align 4
  %v27.1 = getelementptr float, ptr addrspace(1) %0, i64 %v20
  %v28.1 = load float, ptr addrspace(1) %v27.1, align 4
  %v30.1 = fmul float %v24.1, %v28.1
  %v29.1 = fadd float %v29, %v30.1
  %v20.1 = or disjoint i64 %v18, 2
  %v23.2 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v20.1
  %v24.2 = load float, ptr addrspace(1) %v23.2, align 4
  %v27.2 = getelementptr float, ptr addrspace(1) %0, i64 %v20.1
  %v28.2 = load float, ptr addrspace(1) %v27.2, align 4
  %v30.2 = fmul float %v24.2, %v28.2
  %v29.2 = fadd float %v29.1, %v30.2
  %v20.2 = or disjoint i64 %v18, 3
  %v23.3 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v20.2
  %v24.3 = load float, ptr addrspace(1) %v23.3, align 4
  %v27.3 = getelementptr float, ptr addrspace(1) %0, i64 %v20.2
  %v28.3 = load float, ptr addrspace(1) %v27.3, align 4
  %v30.3 = fmul float %v24.3, %v28.3
  %v29.3 = fadd float %v29.2, %v30.3
  %v20.3 = or disjoint i64 %v18, 4
  %v23.4 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v20.3
  %v24.4 = load float, ptr addrspace(1) %v23.4, align 4
  %v27.4 = getelementptr float, ptr addrspace(1) %0, i64 %v20.3
  %v28.4 = load float, ptr addrspace(1) %v27.4, align 4
  %v30.4 = fmul float %v24.4, %v28.4
  %v29.4 = fadd float %v29.3, %v30.4
  %v20.4 = or disjoint i64 %v18, 5
  %v23.5 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v20.4
  %v24.5 = load float, ptr addrspace(1) %v23.5, align 4
  %v27.5 = getelementptr float, ptr addrspace(1) %0, i64 %v20.4
  %v28.5 = load float, ptr addrspace(1) %v27.5, align 4
  %v30.5 = fmul float %v24.5, %v28.5
  %v29.5 = fadd float %v29.4, %v30.5
  %v20.5 = or disjoint i64 %v18, 6
  %v23.6 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v20.5
  %v24.6 = load float, ptr addrspace(1) %v23.6, align 4
  %v27.6 = getelementptr float, ptr addrspace(1) %0, i64 %v20.5
  %v28.6 = load float, ptr addrspace(1) %v27.6, align 4
  %v30.6 = fmul float %v24.6, %v28.6
  %v29.6 = fadd float %v29.5, %v30.6
  %v20.6 = or disjoint i64 %v18, 7
  %v23.7 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v20.6
  %v24.7 = load float, ptr addrspace(1) %v23.7, align 4
  %v27.7 = getelementptr float, ptr addrspace(1) %0, i64 %v20.6
  %v28.7 = load float, ptr addrspace(1) %v27.7, align 4
  %v30.7 = fmul float %v24.7, %v28.7
  %v29.7 = fadd float %v29.6, %v30.7
  %v20.7 = add nuw nsw i64 %v18, 8
  %v31.7 = icmp eq i64 %v20.7, 128
  br i1 %v31.7, label %store, label %kloop

store:                                            ; preds = %kloop
  %v32 = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %v2
  store float %v29.7, ptr addrspace(1) %v32, align 4
  br label %done

done:                                             ; preds = %store, %entry
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_fe449f90d1eda582(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #2 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %p = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %i
  %x = trunc i64 %i to i32
  %t1.i = sitofp i32 %x to float
  store float %t1.i, ptr addrspace(1) %p, align 4
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_5cee44f9496d8476(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #2 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %p = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %i
  %x = trunc i64 %i to i32
  %t1.i = sitofp i32 %x to float
  store float %t1.i, ptr addrspace(1) %p, align 4
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

attributes #0 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nofree norecurse nosync nounwind memory(argmem: readwrite) "nvvm.maxntid"="256" }
attributes #2 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) "nvvm.maxntid"="256" }
