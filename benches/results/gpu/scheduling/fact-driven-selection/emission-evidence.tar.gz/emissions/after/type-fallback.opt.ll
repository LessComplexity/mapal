; ModuleID = '/private/tmp/mapal-gpu-schedule-facts/emissions/after/type-fallback.device.ll'
source_filename = "/private/tmp/mapal-gpu-schedule-facts/emissions/after/type-fallback.device.ll"
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@mapal_smem = external local_unnamed_addr addrspace(3) global [0 x i8], align 16

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 2147483647) i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #0

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fma.f64(double, double, double) #1

; Function Attrs: norecurse nounwind
define ptx_kernel void @mapal_tile_61d2fbbfcaf906b7(ptr addrspace(1) noalias readonly align 16 captures(none) %a, ptr addrspace(1) noalias readonly align 16 captures(none) %b, ptr addrspace(1) noalias writeonly align 16 captures(none) %o) local_unnamed_addr #2 {
entry:
  %v1 = tail call range(i32 0, 32) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = zext nneg i32 %v1 to i64
  %v3 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v4 = zext nneg i32 %v3 to i64
  %v5 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %0 = shl nuw nsw i32 %v5, 4
  %v9 = zext nneg i32 %0 to i64
  %v10 = shl nuw nsw i64 %v4, 5
  %v294 = lshr i64 %v2, 1
  %v30 = shl nuw nsw i64 %v2, 1
  %v31 = and i64 %v30, 2
  %v32 = or disjoint i64 %v294, %v9
  %v405 = lshr i64 %v2, 4
  %v42 = and i64 %v30, 30
  %v44 = or disjoint i64 %v42, %v10
  %v526 = or disjoint i64 %v405, 2
  %v63 = and i64 %v294, 12
  %v8 = shl nuw nsw i64 %v2, 2
  %v64 = and i64 %v8, 28
  %.idx8 = shl nuw nsw i64 %v32, 10
  %1 = getelementptr inbounds nuw i8, ptr addrspace(1) %a, i64 %.idx8
  %v68 = getelementptr inbounds nuw double, ptr addrspace(1) %1, i64 %v31
  %v69 = load <2 x double>, ptr addrspace(1) %v68, align 16
  %.idx9 = shl nuw nsw i64 %v405, 10
  %2 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx9
  %v71 = getelementptr inbounds nuw double, ptr addrspace(1) %2, i64 %v44
  %v72 = load <2 x double>, ptr addrspace(1) %v71, align 16
  %.idx10 = shl nuw nsw i64 %v526, 10
  %3 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx10
  %v74 = getelementptr inbounds nuw double, ptr addrspace(1) %3, i64 %v44
  %v75 = load <2 x double>, ptr addrspace(1) %v74, align 16
  %.idx11 = shl nuw nsw i64 %v31, 7
  %4 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx11
  %v83 = getelementptr inbounds nuw double, ptr addrspace(3) %4, i64 %v294
  %v86 = getelementptr inbounds nuw i8, ptr addrspace(3) %v83, i64 128
  %.idx = shl nuw nsw i64 %v405, 8
  %5 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx
  %6 = getelementptr inbounds nuw double, ptr addrspace(3) %5, i64 %v42
  %v87 = getelementptr inbounds nuw i8, ptr addrspace(3) %6, i64 512
  %.idx7 = shl nuw nsw i64 %v526, 8
  %7 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx7
  %8 = getelementptr inbounds nuw double, ptr addrspace(3) %7, i64 %v42
  %v88 = getelementptr inbounds nuw i8, ptr addrspace(3) %8, i64 512
  %invariant.gep = getelementptr double, ptr addrspace(3) @mapal_smem, i64 %v63
  %invariant.gep14 = getelementptr double, ptr addrspace(3) @mapal_smem, i64 %v64
  %9 = getelementptr inbounds nuw i8, ptr addrspace(3) %invariant.gep, i64 8
  %v115 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 16
  %10 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 24
  %v124 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 512
  %11 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 520
  %v129 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 528
  %12 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 536
  %gep.1 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 128
  %13 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 136
  %v115.1 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 144
  %14 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 152
  %v124.1 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 768
  %15 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 776
  %v129.1 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 784
  %16 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 792
  %gep.2 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 256
  %17 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 264
  %v115.2 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 272
  %18 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 280
  %v124.2 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 1024
  %19 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 1032
  %v129.2 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 1040
  %20 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 1048
  %gep.3 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 384
  %21 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 392
  %v115.3 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 400
  %22 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 408
  %v124.3 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 1280
  %23 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 1288
  %v129.3 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 1296
  %24 = getelementptr i8, ptr addrspace(3) %invariant.gep14, i64 1304
  br label %kt

kt:                                               ; preds = %kt, %entry
  %v11.sroa.60.0 = phi double [ 0.000000e+00, %entry ], [ %v180.3, %kt ]
  %v11.sroa.56.0 = phi double [ 0.000000e+00, %entry ], [ %v177.3, %kt ]
  %v11.sroa.52.0 = phi double [ 0.000000e+00, %entry ], [ %v174.3, %kt ]
  %v11.sroa.48.0 = phi double [ 0.000000e+00, %entry ], [ %v171.3, %kt ]
  %v11.sroa.44.0 = phi double [ 0.000000e+00, %entry ], [ %v168.3, %kt ]
  %v11.sroa.40.0 = phi double [ 0.000000e+00, %entry ], [ %v165.3, %kt ]
  %v11.sroa.36.0 = phi double [ 0.000000e+00, %entry ], [ %v162.3, %kt ]
  %v11.sroa.32.0 = phi double [ 0.000000e+00, %entry ], [ %v159.3, %kt ]
  %v11.sroa.28.0 = phi double [ 0.000000e+00, %entry ], [ %v156.3, %kt ]
  %v11.sroa.24.0 = phi double [ 0.000000e+00, %entry ], [ %v153.3, %kt ]
  %v11.sroa.20.0 = phi double [ 0.000000e+00, %entry ], [ %v150.3, %kt ]
  %v11.sroa.16.0 = phi double [ 0.000000e+00, %entry ], [ %v147.3, %kt ]
  %v11.sroa.12.0 = phi double [ 0.000000e+00, %entry ], [ %v144.3, %kt ]
  %v11.sroa.8.0 = phi double [ 0.000000e+00, %entry ], [ %v141.3, %kt ]
  %v11.sroa.4.0 = phi double [ 0.000000e+00, %entry ], [ %v138.3, %kt ]
  %v11.sroa.0.0 = phi double [ 0.000000e+00, %entry ], [ %v135.3, %kt ]
  %v76 = phi i64 [ 0, %entry ], [ %v89, %kt ]
  %v78 = phi <2 x double> [ %v69, %entry ], [ %v96, %kt ]
  %v79 = phi <2 x double> [ %v72, %entry ], [ %v99, %kt ]
  %v80 = phi <2 x double> [ %v75, %entry ], [ %v102, %kt ]
  %v81 = extractelement <2 x double> %v78, i64 0
  store double %v81, ptr addrspace(3) %v83, align 8
  %v84 = extractelement <2 x double> %v78, i64 1
  store double %v84, ptr addrspace(3) %v86, align 8
  store <2 x double> %v79, ptr addrspace(3) %v87, align 16
  store <2 x double> %v80, ptr addrspace(3) %v88, align 16
  tail call void @llvm.nvvm.barrier.cta.sync.aligned.all(i32 0)
  %v89 = add nuw nsw i64 %v76, 4
  %v90 = icmp samesign ult i64 %v76, 124
  %v91 = select i1 %v90, i64 %v89, i64 %v76
  %v93 = shl i64 %v91, 7
  %v95 = getelementptr double, ptr addrspace(1) %v68, i64 %v91
  %v96 = load <2 x double>, ptr addrspace(1) %v95, align 16
  %v98 = getelementptr double, ptr addrspace(1) %v71, i64 %v93
  %v99 = load <2 x double>, ptr addrspace(1) %v98, align 16
  %v101 = getelementptr double, ptr addrspace(1) %v74, i64 %v93
  %v102 = load <2 x double>, ptr addrspace(1) %v101, align 16
  %v112 = load double, ptr addrspace(3) %invariant.gep, align 16
  %v113 = load double, ptr addrspace(3) %9, align 8
  %v117 = load double, ptr addrspace(3) %v115, align 16
  %v118 = load double, ptr addrspace(3) %10, align 8
  %v126 = load double, ptr addrspace(3) %v124, align 16
  %v127 = load double, ptr addrspace(3) %11, align 8
  %v131 = load double, ptr addrspace(3) %v129, align 16
  %v132 = load double, ptr addrspace(3) %12, align 8
  %v135 = tail call double @llvm.fma.f64(double %v112, double %v126, double %v11.sroa.0.0)
  %v138 = tail call double @llvm.fma.f64(double %v112, double %v127, double %v11.sroa.4.0)
  %v141 = tail call double @llvm.fma.f64(double %v112, double %v131, double %v11.sroa.8.0)
  %v144 = tail call double @llvm.fma.f64(double %v112, double %v132, double %v11.sroa.12.0)
  %v147 = tail call double @llvm.fma.f64(double %v113, double %v126, double %v11.sroa.16.0)
  %v150 = tail call double @llvm.fma.f64(double %v113, double %v127, double %v11.sroa.20.0)
  %v153 = tail call double @llvm.fma.f64(double %v113, double %v131, double %v11.sroa.24.0)
  %v156 = tail call double @llvm.fma.f64(double %v113, double %v132, double %v11.sroa.28.0)
  %v159 = tail call double @llvm.fma.f64(double %v117, double %v126, double %v11.sroa.32.0)
  %v162 = tail call double @llvm.fma.f64(double %v117, double %v127, double %v11.sroa.36.0)
  %v165 = tail call double @llvm.fma.f64(double %v117, double %v131, double %v11.sroa.40.0)
  %v168 = tail call double @llvm.fma.f64(double %v117, double %v132, double %v11.sroa.44.0)
  %v171 = tail call double @llvm.fma.f64(double %v118, double %v126, double %v11.sroa.48.0)
  %v174 = tail call double @llvm.fma.f64(double %v118, double %v127, double %v11.sroa.52.0)
  %v177 = tail call double @llvm.fma.f64(double %v118, double %v131, double %v11.sroa.56.0)
  %v180 = tail call double @llvm.fma.f64(double %v118, double %v132, double %v11.sroa.60.0)
  %v112.1 = load double, ptr addrspace(3) %gep.1, align 16
  %v113.1 = load double, ptr addrspace(3) %13, align 8
  %v117.1 = load double, ptr addrspace(3) %v115.1, align 16
  %v118.1 = load double, ptr addrspace(3) %14, align 8
  %v126.1 = load double, ptr addrspace(3) %v124.1, align 16
  %v127.1 = load double, ptr addrspace(3) %15, align 8
  %v131.1 = load double, ptr addrspace(3) %v129.1, align 16
  %v132.1 = load double, ptr addrspace(3) %16, align 8
  %v135.1 = tail call double @llvm.fma.f64(double %v112.1, double %v126.1, double %v135)
  %v138.1 = tail call double @llvm.fma.f64(double %v112.1, double %v127.1, double %v138)
  %v141.1 = tail call double @llvm.fma.f64(double %v112.1, double %v131.1, double %v141)
  %v144.1 = tail call double @llvm.fma.f64(double %v112.1, double %v132.1, double %v144)
  %v147.1 = tail call double @llvm.fma.f64(double %v113.1, double %v126.1, double %v147)
  %v150.1 = tail call double @llvm.fma.f64(double %v113.1, double %v127.1, double %v150)
  %v153.1 = tail call double @llvm.fma.f64(double %v113.1, double %v131.1, double %v153)
  %v156.1 = tail call double @llvm.fma.f64(double %v113.1, double %v132.1, double %v156)
  %v159.1 = tail call double @llvm.fma.f64(double %v117.1, double %v126.1, double %v159)
  %v162.1 = tail call double @llvm.fma.f64(double %v117.1, double %v127.1, double %v162)
  %v165.1 = tail call double @llvm.fma.f64(double %v117.1, double %v131.1, double %v165)
  %v168.1 = tail call double @llvm.fma.f64(double %v117.1, double %v132.1, double %v168)
  %v171.1 = tail call double @llvm.fma.f64(double %v118.1, double %v126.1, double %v171)
  %v174.1 = tail call double @llvm.fma.f64(double %v118.1, double %v127.1, double %v174)
  %v177.1 = tail call double @llvm.fma.f64(double %v118.1, double %v131.1, double %v177)
  %v180.1 = tail call double @llvm.fma.f64(double %v118.1, double %v132.1, double %v180)
  %v112.2 = load double, ptr addrspace(3) %gep.2, align 16
  %v113.2 = load double, ptr addrspace(3) %17, align 8
  %v117.2 = load double, ptr addrspace(3) %v115.2, align 16
  %v118.2 = load double, ptr addrspace(3) %18, align 8
  %v126.2 = load double, ptr addrspace(3) %v124.2, align 16
  %v127.2 = load double, ptr addrspace(3) %19, align 8
  %v131.2 = load double, ptr addrspace(3) %v129.2, align 16
  %v132.2 = load double, ptr addrspace(3) %20, align 8
  %v135.2 = tail call double @llvm.fma.f64(double %v112.2, double %v126.2, double %v135.1)
  %v138.2 = tail call double @llvm.fma.f64(double %v112.2, double %v127.2, double %v138.1)
  %v141.2 = tail call double @llvm.fma.f64(double %v112.2, double %v131.2, double %v141.1)
  %v144.2 = tail call double @llvm.fma.f64(double %v112.2, double %v132.2, double %v144.1)
  %v147.2 = tail call double @llvm.fma.f64(double %v113.2, double %v126.2, double %v147.1)
  %v150.2 = tail call double @llvm.fma.f64(double %v113.2, double %v127.2, double %v150.1)
  %v153.2 = tail call double @llvm.fma.f64(double %v113.2, double %v131.2, double %v153.1)
  %v156.2 = tail call double @llvm.fma.f64(double %v113.2, double %v132.2, double %v156.1)
  %v159.2 = tail call double @llvm.fma.f64(double %v117.2, double %v126.2, double %v159.1)
  %v162.2 = tail call double @llvm.fma.f64(double %v117.2, double %v127.2, double %v162.1)
  %v165.2 = tail call double @llvm.fma.f64(double %v117.2, double %v131.2, double %v165.1)
  %v168.2 = tail call double @llvm.fma.f64(double %v117.2, double %v132.2, double %v168.1)
  %v171.2 = tail call double @llvm.fma.f64(double %v118.2, double %v126.2, double %v171.1)
  %v174.2 = tail call double @llvm.fma.f64(double %v118.2, double %v127.2, double %v174.1)
  %v177.2 = tail call double @llvm.fma.f64(double %v118.2, double %v131.2, double %v177.1)
  %v180.2 = tail call double @llvm.fma.f64(double %v118.2, double %v132.2, double %v180.1)
  %v112.3 = load double, ptr addrspace(3) %gep.3, align 16
  %v113.3 = load double, ptr addrspace(3) %21, align 8
  %v117.3 = load double, ptr addrspace(3) %v115.3, align 16
  %v118.3 = load double, ptr addrspace(3) %22, align 8
  %v126.3 = load double, ptr addrspace(3) %v124.3, align 16
  %v127.3 = load double, ptr addrspace(3) %23, align 8
  %v131.3 = load double, ptr addrspace(3) %v129.3, align 16
  %v132.3 = load double, ptr addrspace(3) %24, align 8
  %v135.3 = tail call double @llvm.fma.f64(double %v112.3, double %v126.3, double %v135.2)
  %v138.3 = tail call double @llvm.fma.f64(double %v112.3, double %v127.3, double %v138.2)
  %v141.3 = tail call double @llvm.fma.f64(double %v112.3, double %v131.3, double %v141.2)
  %v144.3 = tail call double @llvm.fma.f64(double %v112.3, double %v132.3, double %v144.2)
  %v147.3 = tail call double @llvm.fma.f64(double %v113.3, double %v126.3, double %v147.2)
  %v150.3 = tail call double @llvm.fma.f64(double %v113.3, double %v127.3, double %v150.2)
  %v153.3 = tail call double @llvm.fma.f64(double %v113.3, double %v131.3, double %v153.2)
  %v156.3 = tail call double @llvm.fma.f64(double %v113.3, double %v132.3, double %v156.2)
  %v159.3 = tail call double @llvm.fma.f64(double %v117.3, double %v126.3, double %v159.2)
  %v162.3 = tail call double @llvm.fma.f64(double %v117.3, double %v127.3, double %v162.2)
  %v165.3 = tail call double @llvm.fma.f64(double %v117.3, double %v131.3, double %v165.2)
  %v168.3 = tail call double @llvm.fma.f64(double %v117.3, double %v132.3, double %v168.2)
  %v171.3 = tail call double @llvm.fma.f64(double %v118.3, double %v126.3, double %v171.2)
  %v174.3 = tail call double @llvm.fma.f64(double %v118.3, double %v127.3, double %v174.2)
  %v177.3 = tail call double @llvm.fma.f64(double %v118.3, double %v131.3, double %v177.2)
  %v180.3 = tail call double @llvm.fma.f64(double %v118.3, double %v132.3, double %v180.2)
  tail call void @llvm.nvvm.barrier.cta.sync.aligned.all(i32 0)
  %v182 = icmp eq i64 %v89, 128
  br i1 %v182, label %done, label %kt

done:                                             ; preds = %kt
  %v183 = or disjoint i64 %v63, %v9
  %v190 = insertelement <2 x double> poison, double %v135.3, i64 0
  %v193 = insertelement <2 x double> %v190, double %v138.3, i64 1
  %.idx16 = shl nuw nsw i64 %v183, 10
  %25 = getelementptr inbounds nuw i8, ptr addrspace(1) %o, i64 %.idx16
  %26 = getelementptr inbounds nuw double, ptr addrspace(1) %25, i64 %v10
  %v195 = getelementptr inbounds nuw double, ptr addrspace(1) %26, i64 %v64
  store <2 x double> %v193, ptr addrspace(1) %v195, align 16
  %v198 = insertelement <2 x double> poison, double %v141.3, i64 0
  %v201 = insertelement <2 x double> %v198, double %v144.3, i64 1
  %v203 = getelementptr inbounds nuw i8, ptr addrspace(1) %v195, i64 16
  store <2 x double> %v201, ptr addrspace(1) %v203, align 16
  %v211 = insertelement <2 x double> poison, double %v147.3, i64 0
  %v214 = insertelement <2 x double> %v211, double %v150.3, i64 1
  %27 = getelementptr inbounds nuw i8, ptr addrspace(1) %25, i64 1024
  %28 = getelementptr inbounds nuw double, ptr addrspace(1) %27, i64 %v10
  %v216 = getelementptr inbounds nuw double, ptr addrspace(1) %28, i64 %v64
  store <2 x double> %v214, ptr addrspace(1) %v216, align 16
  %v219 = insertelement <2 x double> poison, double %v153.3, i64 0
  %v222 = insertelement <2 x double> %v219, double %v156.3, i64 1
  %v224 = getelementptr inbounds nuw i8, ptr addrspace(1) %v216, i64 16
  store <2 x double> %v222, ptr addrspace(1) %v224, align 16
  %v232 = insertelement <2 x double> poison, double %v159.3, i64 0
  %v235 = insertelement <2 x double> %v232, double %v162.3, i64 1
  %29 = getelementptr inbounds nuw i8, ptr addrspace(1) %25, i64 2048
  %30 = getelementptr inbounds nuw double, ptr addrspace(1) %29, i64 %v10
  %v237 = getelementptr inbounds nuw double, ptr addrspace(1) %30, i64 %v64
  store <2 x double> %v235, ptr addrspace(1) %v237, align 16
  %v240 = insertelement <2 x double> poison, double %v165.3, i64 0
  %v243 = insertelement <2 x double> %v240, double %v168.3, i64 1
  %v245 = getelementptr inbounds nuw i8, ptr addrspace(1) %v237, i64 16
  store <2 x double> %v243, ptr addrspace(1) %v245, align 16
  %v253 = insertelement <2 x double> poison, double %v171.3, i64 0
  %v256 = insertelement <2 x double> %v253, double %v174.3, i64 1
  %31 = getelementptr inbounds nuw i8, ptr addrspace(1) %25, i64 3072
  %32 = getelementptr inbounds nuw double, ptr addrspace(1) %31, i64 %v10
  %v258 = getelementptr inbounds nuw double, ptr addrspace(1) %32, i64 %v64
  store <2 x double> %v256, ptr addrspace(1) %v258, align 16
  %v261 = insertelement <2 x double> poison, double %v177.3, i64 0
  %v264 = insertelement <2 x double> %v261, double %v180.3, i64 1
  %v266 = getelementptr inbounds nuw i8, ptr addrspace(1) %v258, i64 16
  store <2 x double> %v264, ptr addrspace(1) %v266, align 16
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_34fc01898169adc9(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #3 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %x = trunc i64 %i to i32
  %t7.i = mul i32 %x, 7
  %t15.i = add i32 %t7.i, 13
  %t23.i = srem i32 %t15.i, 101
  %t31.i = add nsw i32 %t23.i, -50
  %t33.i = sitofp i32 %t31.i to double
  %t41.i = fdiv double %t33.i, 7.000000e+00
  %p = getelementptr inbounds nuw double, ptr addrspace(1) %o, i64 %i
  store double %t41.i, ptr addrspace(1) %p, align 8
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_e1cb74ac3c460016(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #3 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %x = trunc i64 %i to i32
  %t7.i = mul i32 %x, 11
  %t15.i = add i32 %t7.i, 57
  %t23.i = srem i32 %t15.i, 103
  %t31.i = add nsw i32 %t23.i, -51
  %t33.i = sitofp i32 %t31.i to double
  %t41.i = fdiv double %t33.i, 9.000000e+00
  %p = getelementptr inbounds nuw double, ptr addrspace(1) %o, i64 %i
  store double %t41.i, ptr addrspace(1) %p, align 8
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.barrier.cta.sync.aligned.all(i32) #4

attributes #0 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { norecurse nounwind "nvvm.maxntid"="32" "nvvm.minctasm"="16" }
attributes #3 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) "nvvm.maxntid"="256" }
attributes #4 = { convergent nocallback nounwind }
