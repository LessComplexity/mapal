; mapal-backend-llvm device module
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@mapal_smem = external addrspace(3) global [0 x i8], align 16
declare i32 @llvm.nvvm.read.ptx.sreg.tid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
declare void @llvm.nvvm.barrier0()
declare void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.8(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.commit.group()
declare void @llvm.nvvm.cp.async.wait.group(i32 immarg)
declare float @llvm.fma.f32(float, float, float)
declare double @llvm.fma.f64(double, double, double)

define ptx_kernel void @mapal_tile_565ffde502536326(ptr addrspace(1) noalias readonly align 16 %a, ptr addrspace(1) noalias readonly align 16 %b, ptr addrspace(1) noalias align 16 %o) "nvvm.maxntid"="256" "nvvm.minctasm"="2" {
entry:
  %v1 = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = zext i32 %v1 to i64
  %v3 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v4 = zext i32 %v3 to i64
  %v5 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v6 = zext i32 %v5 to i64
  %v7 = udiv i64 %v2, 32
  %v8 = urem i64 %v2, 32
  %v9 = udiv i64 %v7, 2
  %v10 = urem i64 %v7, 2
  %v11 = udiv i64 %v8, 8
  %v12 = urem i64 %v8, 8
  %v13 = mul i64 %v9, 4
  %v14 = mul i64 %v10, 8
  %v15 = add i64 %v13, %v11
  %v16 = add i64 %v14, %v12
  %v17 = mul i64 %v6, 128
  %v18 = mul i64 %v4, 64
  %v19 = alloca [32 x float], align 16
  %v20 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 0
  store float 0x0000000000000000, ptr %v20, align 4
  %v21 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 1
  store float 0x0000000000000000, ptr %v21, align 4
  %v22 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 2
  store float 0x0000000000000000, ptr %v22, align 4
  %v23 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 3
  store float 0x0000000000000000, ptr %v23, align 4
  %v24 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 4
  store float 0x0000000000000000, ptr %v24, align 4
  %v25 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 5
  store float 0x0000000000000000, ptr %v25, align 4
  %v26 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 6
  store float 0x0000000000000000, ptr %v26, align 4
  %v27 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 7
  store float 0x0000000000000000, ptr %v27, align 4
  %v28 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 8
  store float 0x0000000000000000, ptr %v28, align 4
  %v29 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 9
  store float 0x0000000000000000, ptr %v29, align 4
  %v30 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 10
  store float 0x0000000000000000, ptr %v30, align 4
  %v31 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 11
  store float 0x0000000000000000, ptr %v31, align 4
  %v32 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 12
  store float 0x0000000000000000, ptr %v32, align 4
  %v33 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 13
  store float 0x0000000000000000, ptr %v33, align 4
  %v34 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 14
  store float 0x0000000000000000, ptr %v34, align 4
  %v35 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 15
  store float 0x0000000000000000, ptr %v35, align 4
  %v36 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 16
  store float 0x0000000000000000, ptr %v36, align 4
  %v37 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 17
  store float 0x0000000000000000, ptr %v37, align 4
  %v38 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 18
  store float 0x0000000000000000, ptr %v38, align 4
  %v39 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 19
  store float 0x0000000000000000, ptr %v39, align 4
  %v40 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 20
  store float 0x0000000000000000, ptr %v40, align 4
  %v41 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 21
  store float 0x0000000000000000, ptr %v41, align 4
  %v42 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 22
  store float 0x0000000000000000, ptr %v42, align 4
  %v43 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 23
  store float 0x0000000000000000, ptr %v43, align 4
  %v44 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 24
  store float 0x0000000000000000, ptr %v44, align 4
  %v45 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 25
  store float 0x0000000000000000, ptr %v45, align 4
  %v46 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 26
  store float 0x0000000000000000, ptr %v46, align 4
  %v47 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 27
  store float 0x0000000000000000, ptr %v47, align 4
  %v48 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 28
  store float 0x0000000000000000, ptr %v48, align 4
  %v49 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 29
  store float 0x0000000000000000, ptr %v49, align 4
  %v50 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 30
  store float 0x0000000000000000, ptr %v50, align 4
  %v51 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 31
  store float 0x0000000000000000, ptr %v51, align 4
  %v52 = add i64 %v2, 0
  %v53 = urem i64 %v52, 4
  %v54 = udiv i64 %v52, 4
  %v55 = urem i64 %v54, 128
  %v56 = udiv i64 %v54, 128
  %v57 = mul i64 %v56, 4
  %v58 = add i64 %v57, %v53
  %v59 = add i64 %v17, %v55
  %v60 = mul i64 %v59, 1024
  %v61 = mul i64 %v58, 1
  %v62 = add i64 %v60, %v61
  %v63 = add i64 %v62, 0
  %v64 = mul i64 %v58, 136
  %v65 = add i64 %v64, %v55
  %v66 = add i64 %v2, 256
  %v67 = urem i64 %v66, 4
  %v68 = udiv i64 %v66, 4
  %v69 = urem i64 %v68, 128
  %v70 = udiv i64 %v68, 128
  %v71 = mul i64 %v70, 4
  %v72 = add i64 %v71, %v67
  %v73 = add i64 %v17, %v69
  %v74 = mul i64 %v73, 1024
  %v75 = mul i64 %v72, 1
  %v76 = add i64 %v74, %v75
  %v77 = add i64 %v76, 0
  %v78 = mul i64 %v72, 136
  %v79 = add i64 %v78, %v69
  %v80 = add i64 %v2, 512
  %v81 = urem i64 %v80, 4
  %v82 = udiv i64 %v80, 4
  %v83 = urem i64 %v82, 128
  %v84 = udiv i64 %v82, 128
  %v85 = mul i64 %v84, 4
  %v86 = add i64 %v85, %v81
  %v87 = add i64 %v17, %v83
  %v88 = mul i64 %v87, 1024
  %v89 = mul i64 %v86, 1
  %v90 = add i64 %v88, %v89
  %v91 = add i64 %v90, 0
  %v92 = mul i64 %v86, 136
  %v93 = add i64 %v92, %v83
  %v94 = add i64 %v2, 768
  %v95 = urem i64 %v94, 4
  %v96 = udiv i64 %v94, 4
  %v97 = urem i64 %v96, 128
  %v98 = udiv i64 %v96, 128
  %v99 = mul i64 %v98, 4
  %v100 = add i64 %v99, %v95
  %v101 = add i64 %v17, %v97
  %v102 = mul i64 %v101, 1024
  %v103 = mul i64 %v100, 1
  %v104 = add i64 %v102, %v103
  %v105 = add i64 %v104, 0
  %v106 = mul i64 %v100, 136
  %v107 = add i64 %v106, %v97
  %v108 = add i64 %v2, 1024
  %v109 = urem i64 %v108, 4
  %v110 = udiv i64 %v108, 4
  %v111 = urem i64 %v110, 128
  %v112 = udiv i64 %v110, 128
  %v113 = mul i64 %v112, 4
  %v114 = add i64 %v113, %v109
  %v115 = add i64 %v17, %v111
  %v116 = mul i64 %v115, 1024
  %v117 = mul i64 %v114, 1
  %v118 = add i64 %v116, %v117
  %v119 = add i64 %v118, 0
  %v120 = mul i64 %v114, 136
  %v121 = add i64 %v120, %v111
  %v122 = add i64 %v2, 1280
  %v123 = urem i64 %v122, 4
  %v124 = udiv i64 %v122, 4
  %v125 = urem i64 %v124, 128
  %v126 = udiv i64 %v124, 128
  %v127 = mul i64 %v126, 4
  %v128 = add i64 %v127, %v123
  %v129 = add i64 %v17, %v125
  %v130 = mul i64 %v129, 1024
  %v131 = mul i64 %v128, 1
  %v132 = add i64 %v130, %v131
  %v133 = add i64 %v132, 0
  %v134 = mul i64 %v128, 136
  %v135 = add i64 %v134, %v125
  %v136 = add i64 %v2, 1536
  %v137 = urem i64 %v136, 4
  %v138 = udiv i64 %v136, 4
  %v139 = urem i64 %v138, 128
  %v140 = udiv i64 %v138, 128
  %v141 = mul i64 %v140, 4
  %v142 = add i64 %v141, %v137
  %v143 = add i64 %v17, %v139
  %v144 = mul i64 %v143, 1024
  %v145 = mul i64 %v142, 1
  %v146 = add i64 %v144, %v145
  %v147 = add i64 %v146, 0
  %v148 = mul i64 %v142, 136
  %v149 = add i64 %v148, %v139
  %v150 = add i64 %v2, 1792
  %v151 = urem i64 %v150, 4
  %v152 = udiv i64 %v150, 4
  %v153 = urem i64 %v152, 128
  %v154 = udiv i64 %v152, 128
  %v155 = mul i64 %v154, 4
  %v156 = add i64 %v155, %v151
  %v157 = add i64 %v17, %v153
  %v158 = mul i64 %v157, 1024
  %v159 = mul i64 %v156, 1
  %v160 = add i64 %v158, %v159
  %v161 = add i64 %v160, 0
  %v162 = mul i64 %v156, 136
  %v163 = add i64 %v162, %v153
  %v164 = add i64 %v2, 0
  %v165 = udiv i64 %v164, 16
  %v166 = urem i64 %v164, 16
  %v167 = mul i64 %v166, 4
  %v168 = mul i64 %v165, 1024
  %v169 = add i64 %v18, %v167
  %v170 = mul i64 %v169, 1
  %v171 = add i64 %v168, %v170
  %v172 = add i64 %v171, 0
  %v173 = mul i64 %v165, 64
  %v174 = add i64 %v173, %v167
  %v175 = add i64 %v174, 2176
  %v176 = mul i64 %v15, 4
  %v177 = mul i64 %v16, 4
  %v178 = mul i64 0, 16
  %v179 = mul i64 %v178, 1
  %v180 = mul i64 %v178, 1024
  %v181 = mul i64 0, 3200
  %v182 = add i64 %v63, %v179
  %v183 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v182
  %v184 = add i64 %v65, %v181
  %v185 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v184
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v185, ptr addrspace(1) %v183)
  %v186 = add i64 %v77, %v179
  %v187 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v186
  %v188 = add i64 %v79, %v181
  %v189 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v188
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v189, ptr addrspace(1) %v187)
  %v190 = add i64 %v91, %v179
  %v191 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v190
  %v192 = add i64 %v93, %v181
  %v193 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v192
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v193, ptr addrspace(1) %v191)
  %v194 = add i64 %v105, %v179
  %v195 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v194
  %v196 = add i64 %v107, %v181
  %v197 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v196
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v197, ptr addrspace(1) %v195)
  %v198 = add i64 %v119, %v179
  %v199 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v198
  %v200 = add i64 %v121, %v181
  %v201 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v200
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v201, ptr addrspace(1) %v199)
  %v202 = add i64 %v133, %v179
  %v203 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v202
  %v204 = add i64 %v135, %v181
  %v205 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v204
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v205, ptr addrspace(1) %v203)
  %v206 = add i64 %v147, %v179
  %v207 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v206
  %v208 = add i64 %v149, %v181
  %v209 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v208
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v209, ptr addrspace(1) %v207)
  %v210 = add i64 %v161, %v179
  %v211 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v210
  %v212 = add i64 %v163, %v181
  %v213 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v212
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v213, ptr addrspace(1) %v211)
  %v214 = add i64 %v172, %v180
  %v215 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v214
  %v216 = add i64 %v175, %v181
  %v217 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v216
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v217, ptr addrspace(1) %v215)
  call void @llvm.nvvm.cp.async.commit.group()
  %v218 = mul i64 1, 16
  %v219 = mul i64 %v218, 1
  %v220 = mul i64 %v218, 1024
  %v221 = mul i64 1, 3200
  %v222 = add i64 %v63, %v219
  %v223 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v222
  %v224 = add i64 %v65, %v221
  %v225 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v224
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v225, ptr addrspace(1) %v223)
  %v226 = add i64 %v77, %v219
  %v227 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v226
  %v228 = add i64 %v79, %v221
  %v229 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v228
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v229, ptr addrspace(1) %v227)
  %v230 = add i64 %v91, %v219
  %v231 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v230
  %v232 = add i64 %v93, %v221
  %v233 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v232
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v233, ptr addrspace(1) %v231)
  %v234 = add i64 %v105, %v219
  %v235 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v234
  %v236 = add i64 %v107, %v221
  %v237 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v236
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v237, ptr addrspace(1) %v235)
  %v238 = add i64 %v119, %v219
  %v239 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v238
  %v240 = add i64 %v121, %v221
  %v241 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v240
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v241, ptr addrspace(1) %v239)
  %v242 = add i64 %v133, %v219
  %v243 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v242
  %v244 = add i64 %v135, %v221
  %v245 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v244
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v245, ptr addrspace(1) %v243)
  %v246 = add i64 %v147, %v219
  %v247 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v246
  %v248 = add i64 %v149, %v221
  %v249 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v248
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v249, ptr addrspace(1) %v247)
  %v250 = add i64 %v161, %v219
  %v251 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v250
  %v252 = add i64 %v163, %v221
  %v253 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v252
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v253, ptr addrspace(1) %v251)
  %v254 = add i64 %v172, %v220
  %v255 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v254
  %v256 = add i64 %v175, %v221
  %v257 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v256
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v257, ptr addrspace(1) %v255)
  call void @llvm.nvvm.cp.async.commit.group()
  br label %kt
kt:
  %v258 = phi i64 [0, %entry], [%v259, %ktl]
  call void @llvm.nvvm.cp.async.wait.group(i32 1)
  call void @llvm.nvvm.barrier0()
  %v260 = add i64 %v258, 2
  %v261 = icmp ult i64 %v260, 64
  br i1 %v261, label %issue, label %issued
issue:
  %v262 = urem i64 %v260, 3
  %v263 = mul i64 %v260, 16
  %v264 = mul i64 %v263, 1
  %v265 = mul i64 %v263, 1024
  %v266 = mul i64 %v262, 3200
  %v267 = add i64 %v63, %v264
  %v268 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v267
  %v269 = add i64 %v65, %v266
  %v270 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v269
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v270, ptr addrspace(1) %v268)
  %v271 = add i64 %v77, %v264
  %v272 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v271
  %v273 = add i64 %v79, %v266
  %v274 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v273
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v274, ptr addrspace(1) %v272)
  %v275 = add i64 %v91, %v264
  %v276 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v275
  %v277 = add i64 %v93, %v266
  %v278 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v277
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v278, ptr addrspace(1) %v276)
  %v279 = add i64 %v105, %v264
  %v280 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v279
  %v281 = add i64 %v107, %v266
  %v282 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v281
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v282, ptr addrspace(1) %v280)
  %v283 = add i64 %v119, %v264
  %v284 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v283
  %v285 = add i64 %v121, %v266
  %v286 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v285
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v286, ptr addrspace(1) %v284)
  %v287 = add i64 %v133, %v264
  %v288 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v287
  %v289 = add i64 %v135, %v266
  %v290 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v289
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v290, ptr addrspace(1) %v288)
  %v291 = add i64 %v147, %v264
  %v292 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v291
  %v293 = add i64 %v149, %v266
  %v294 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v293
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v294, ptr addrspace(1) %v292)
  %v295 = add i64 %v161, %v264
  %v296 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v295
  %v297 = add i64 %v163, %v266
  %v298 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v297
  call void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3) %v298, ptr addrspace(1) %v296)
  %v299 = add i64 %v172, %v265
  %v300 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v299
  %v301 = add i64 %v175, %v266
  %v302 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v301
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v302, ptr addrspace(1) %v300)
  br label %issued
issued:
  call void @llvm.nvvm.cp.async.commit.group()
  %v303 = urem i64 %v258, 3
  %v304 = mul i64 %v303, 3200
  br label %kk
kk:
  %v305 = phi i64 [0, %issued], [%v306, %kk]
  %v307 = mul i64 %v305, 136
  %v308 = add i64 %v307, %v176
  %v309 = add i64 %v308, 0
  %v310 = add i64 %v309, %v304
  %v311 = add i64 %v310, 0
  %v312 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v311
  %v313 = load <4 x float>, ptr addrspace(3) %v312, align 16
  %v314 = extractelement <4 x float> %v313, i64 0
  %v315 = extractelement <4 x float> %v313, i64 1
  %v316 = extractelement <4 x float> %v313, i64 2
  %v317 = extractelement <4 x float> %v313, i64 3
  %v318 = add i64 %v310, 64
  %v319 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v318
  %v320 = load <4 x float>, ptr addrspace(3) %v319, align 16
  %v321 = extractelement <4 x float> %v320, i64 0
  %v322 = extractelement <4 x float> %v320, i64 1
  %v323 = extractelement <4 x float> %v320, i64 2
  %v324 = extractelement <4 x float> %v320, i64 3
  %v325 = mul i64 %v305, 64
  %v326 = add i64 %v325, %v177
  %v327 = add i64 %v326, 2176
  %v328 = add i64 %v327, %v304
  %v329 = add i64 %v328, 0
  %v330 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v329
  %v331 = load <4 x float>, ptr addrspace(3) %v330, align 16
  %v332 = extractelement <4 x float> %v331, i64 0
  %v333 = extractelement <4 x float> %v331, i64 1
  %v334 = extractelement <4 x float> %v331, i64 2
  %v335 = extractelement <4 x float> %v331, i64 3
  %v336 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 0
  %v337 = load float, ptr %v336, align 4
  %v338 = call float @llvm.fma.f32(float %v314, float %v332, float %v337)
  store float %v338, ptr %v336, align 4
  %v339 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 1
  %v340 = load float, ptr %v339, align 4
  %v341 = call float @llvm.fma.f32(float %v314, float %v333, float %v340)
  store float %v341, ptr %v339, align 4
  %v342 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 2
  %v343 = load float, ptr %v342, align 4
  %v344 = call float @llvm.fma.f32(float %v314, float %v334, float %v343)
  store float %v344, ptr %v342, align 4
  %v345 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 3
  %v346 = load float, ptr %v345, align 4
  %v347 = call float @llvm.fma.f32(float %v314, float %v335, float %v346)
  store float %v347, ptr %v345, align 4
  %v348 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 4
  %v349 = load float, ptr %v348, align 4
  %v350 = call float @llvm.fma.f32(float %v315, float %v332, float %v349)
  store float %v350, ptr %v348, align 4
  %v351 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 5
  %v352 = load float, ptr %v351, align 4
  %v353 = call float @llvm.fma.f32(float %v315, float %v333, float %v352)
  store float %v353, ptr %v351, align 4
  %v354 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 6
  %v355 = load float, ptr %v354, align 4
  %v356 = call float @llvm.fma.f32(float %v315, float %v334, float %v355)
  store float %v356, ptr %v354, align 4
  %v357 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 7
  %v358 = load float, ptr %v357, align 4
  %v359 = call float @llvm.fma.f32(float %v315, float %v335, float %v358)
  store float %v359, ptr %v357, align 4
  %v360 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 8
  %v361 = load float, ptr %v360, align 4
  %v362 = call float @llvm.fma.f32(float %v316, float %v332, float %v361)
  store float %v362, ptr %v360, align 4
  %v363 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 9
  %v364 = load float, ptr %v363, align 4
  %v365 = call float @llvm.fma.f32(float %v316, float %v333, float %v364)
  store float %v365, ptr %v363, align 4
  %v366 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 10
  %v367 = load float, ptr %v366, align 4
  %v368 = call float @llvm.fma.f32(float %v316, float %v334, float %v367)
  store float %v368, ptr %v366, align 4
  %v369 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 11
  %v370 = load float, ptr %v369, align 4
  %v371 = call float @llvm.fma.f32(float %v316, float %v335, float %v370)
  store float %v371, ptr %v369, align 4
  %v372 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 12
  %v373 = load float, ptr %v372, align 4
  %v374 = call float @llvm.fma.f32(float %v317, float %v332, float %v373)
  store float %v374, ptr %v372, align 4
  %v375 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 13
  %v376 = load float, ptr %v375, align 4
  %v377 = call float @llvm.fma.f32(float %v317, float %v333, float %v376)
  store float %v377, ptr %v375, align 4
  %v378 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 14
  %v379 = load float, ptr %v378, align 4
  %v380 = call float @llvm.fma.f32(float %v317, float %v334, float %v379)
  store float %v380, ptr %v378, align 4
  %v381 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 15
  %v382 = load float, ptr %v381, align 4
  %v383 = call float @llvm.fma.f32(float %v317, float %v335, float %v382)
  store float %v383, ptr %v381, align 4
  %v384 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 16
  %v385 = load float, ptr %v384, align 4
  %v386 = call float @llvm.fma.f32(float %v321, float %v332, float %v385)
  store float %v386, ptr %v384, align 4
  %v387 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 17
  %v388 = load float, ptr %v387, align 4
  %v389 = call float @llvm.fma.f32(float %v321, float %v333, float %v388)
  store float %v389, ptr %v387, align 4
  %v390 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 18
  %v391 = load float, ptr %v390, align 4
  %v392 = call float @llvm.fma.f32(float %v321, float %v334, float %v391)
  store float %v392, ptr %v390, align 4
  %v393 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 19
  %v394 = load float, ptr %v393, align 4
  %v395 = call float @llvm.fma.f32(float %v321, float %v335, float %v394)
  store float %v395, ptr %v393, align 4
  %v396 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 20
  %v397 = load float, ptr %v396, align 4
  %v398 = call float @llvm.fma.f32(float %v322, float %v332, float %v397)
  store float %v398, ptr %v396, align 4
  %v399 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 21
  %v400 = load float, ptr %v399, align 4
  %v401 = call float @llvm.fma.f32(float %v322, float %v333, float %v400)
  store float %v401, ptr %v399, align 4
  %v402 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 22
  %v403 = load float, ptr %v402, align 4
  %v404 = call float @llvm.fma.f32(float %v322, float %v334, float %v403)
  store float %v404, ptr %v402, align 4
  %v405 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 23
  %v406 = load float, ptr %v405, align 4
  %v407 = call float @llvm.fma.f32(float %v322, float %v335, float %v406)
  store float %v407, ptr %v405, align 4
  %v408 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 24
  %v409 = load float, ptr %v408, align 4
  %v410 = call float @llvm.fma.f32(float %v323, float %v332, float %v409)
  store float %v410, ptr %v408, align 4
  %v411 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 25
  %v412 = load float, ptr %v411, align 4
  %v413 = call float @llvm.fma.f32(float %v323, float %v333, float %v412)
  store float %v413, ptr %v411, align 4
  %v414 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 26
  %v415 = load float, ptr %v414, align 4
  %v416 = call float @llvm.fma.f32(float %v323, float %v334, float %v415)
  store float %v416, ptr %v414, align 4
  %v417 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 27
  %v418 = load float, ptr %v417, align 4
  %v419 = call float @llvm.fma.f32(float %v323, float %v335, float %v418)
  store float %v419, ptr %v417, align 4
  %v420 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 28
  %v421 = load float, ptr %v420, align 4
  %v422 = call float @llvm.fma.f32(float %v324, float %v332, float %v421)
  store float %v422, ptr %v420, align 4
  %v423 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 29
  %v424 = load float, ptr %v423, align 4
  %v425 = call float @llvm.fma.f32(float %v324, float %v333, float %v424)
  store float %v425, ptr %v423, align 4
  %v426 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 30
  %v427 = load float, ptr %v426, align 4
  %v428 = call float @llvm.fma.f32(float %v324, float %v334, float %v427)
  store float %v428, ptr %v426, align 4
  %v429 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 31
  %v430 = load float, ptr %v429, align 4
  %v431 = call float @llvm.fma.f32(float %v324, float %v335, float %v430)
  store float %v431, ptr %v429, align 4
  %v306 = add i64 %v305, 1
  %v432 = icmp eq i64 %v306, 16
  br i1 %v432, label %ktl, label %kk, !llvm.loop !0
ktl:
  %v259 = add i64 %v258, 1
  %v433 = icmp eq i64 %v259, 64
  br i1 %v433, label %done, label %kt
done:
  %v434 = add i64 %v17, %v176
  %v435 = add i64 %v434, 0
  %v436 = mul i64 %v435, 1024
  %v437 = add i64 %v436, %v18
  %v438 = add i64 %v437, %v177
  %v439 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 0
  %v440 = load float, ptr %v439, align 4
  %v441 = insertelement <4 x float> poison, float %v440, i64 0
  %v442 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 1
  %v443 = load float, ptr %v442, align 4
  %v444 = insertelement <4 x float> %v441, float %v443, i64 1
  %v445 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 2
  %v446 = load float, ptr %v445, align 4
  %v447 = insertelement <4 x float> %v444, float %v446, i64 2
  %v448 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 3
  %v449 = load float, ptr %v448, align 4
  %v450 = insertelement <4 x float> %v447, float %v449, i64 3
  %v451 = add i64 %v438, 0
  %v452 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v451
  store <4 x float> %v450, ptr addrspace(1) %v452, align 16
  %v453 = add i64 %v17, %v176
  %v454 = add i64 %v453, 1
  %v455 = mul i64 %v454, 1024
  %v456 = add i64 %v455, %v18
  %v457 = add i64 %v456, %v177
  %v458 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 4
  %v459 = load float, ptr %v458, align 4
  %v460 = insertelement <4 x float> poison, float %v459, i64 0
  %v461 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 5
  %v462 = load float, ptr %v461, align 4
  %v463 = insertelement <4 x float> %v460, float %v462, i64 1
  %v464 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 6
  %v465 = load float, ptr %v464, align 4
  %v466 = insertelement <4 x float> %v463, float %v465, i64 2
  %v467 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 7
  %v468 = load float, ptr %v467, align 4
  %v469 = insertelement <4 x float> %v466, float %v468, i64 3
  %v470 = add i64 %v457, 0
  %v471 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v470
  store <4 x float> %v469, ptr addrspace(1) %v471, align 16
  %v472 = add i64 %v17, %v176
  %v473 = add i64 %v472, 2
  %v474 = mul i64 %v473, 1024
  %v475 = add i64 %v474, %v18
  %v476 = add i64 %v475, %v177
  %v477 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 8
  %v478 = load float, ptr %v477, align 4
  %v479 = insertelement <4 x float> poison, float %v478, i64 0
  %v480 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 9
  %v481 = load float, ptr %v480, align 4
  %v482 = insertelement <4 x float> %v479, float %v481, i64 1
  %v483 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 10
  %v484 = load float, ptr %v483, align 4
  %v485 = insertelement <4 x float> %v482, float %v484, i64 2
  %v486 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 11
  %v487 = load float, ptr %v486, align 4
  %v488 = insertelement <4 x float> %v485, float %v487, i64 3
  %v489 = add i64 %v476, 0
  %v490 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v489
  store <4 x float> %v488, ptr addrspace(1) %v490, align 16
  %v491 = add i64 %v17, %v176
  %v492 = add i64 %v491, 3
  %v493 = mul i64 %v492, 1024
  %v494 = add i64 %v493, %v18
  %v495 = add i64 %v494, %v177
  %v496 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 12
  %v497 = load float, ptr %v496, align 4
  %v498 = insertelement <4 x float> poison, float %v497, i64 0
  %v499 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 13
  %v500 = load float, ptr %v499, align 4
  %v501 = insertelement <4 x float> %v498, float %v500, i64 1
  %v502 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 14
  %v503 = load float, ptr %v502, align 4
  %v504 = insertelement <4 x float> %v501, float %v503, i64 2
  %v505 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 15
  %v506 = load float, ptr %v505, align 4
  %v507 = insertelement <4 x float> %v504, float %v506, i64 3
  %v508 = add i64 %v495, 0
  %v509 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v508
  store <4 x float> %v507, ptr addrspace(1) %v509, align 16
  %v510 = add i64 %v17, %v176
  %v511 = add i64 %v510, 64
  %v512 = mul i64 %v511, 1024
  %v513 = add i64 %v512, %v18
  %v514 = add i64 %v513, %v177
  %v515 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 16
  %v516 = load float, ptr %v515, align 4
  %v517 = insertelement <4 x float> poison, float %v516, i64 0
  %v518 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 17
  %v519 = load float, ptr %v518, align 4
  %v520 = insertelement <4 x float> %v517, float %v519, i64 1
  %v521 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 18
  %v522 = load float, ptr %v521, align 4
  %v523 = insertelement <4 x float> %v520, float %v522, i64 2
  %v524 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 19
  %v525 = load float, ptr %v524, align 4
  %v526 = insertelement <4 x float> %v523, float %v525, i64 3
  %v527 = add i64 %v514, 0
  %v528 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v527
  store <4 x float> %v526, ptr addrspace(1) %v528, align 16
  %v529 = add i64 %v17, %v176
  %v530 = add i64 %v529, 65
  %v531 = mul i64 %v530, 1024
  %v532 = add i64 %v531, %v18
  %v533 = add i64 %v532, %v177
  %v534 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 20
  %v535 = load float, ptr %v534, align 4
  %v536 = insertelement <4 x float> poison, float %v535, i64 0
  %v537 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 21
  %v538 = load float, ptr %v537, align 4
  %v539 = insertelement <4 x float> %v536, float %v538, i64 1
  %v540 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 22
  %v541 = load float, ptr %v540, align 4
  %v542 = insertelement <4 x float> %v539, float %v541, i64 2
  %v543 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 23
  %v544 = load float, ptr %v543, align 4
  %v545 = insertelement <4 x float> %v542, float %v544, i64 3
  %v546 = add i64 %v533, 0
  %v547 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v546
  store <4 x float> %v545, ptr addrspace(1) %v547, align 16
  %v548 = add i64 %v17, %v176
  %v549 = add i64 %v548, 66
  %v550 = mul i64 %v549, 1024
  %v551 = add i64 %v550, %v18
  %v552 = add i64 %v551, %v177
  %v553 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 24
  %v554 = load float, ptr %v553, align 4
  %v555 = insertelement <4 x float> poison, float %v554, i64 0
  %v556 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 25
  %v557 = load float, ptr %v556, align 4
  %v558 = insertelement <4 x float> %v555, float %v557, i64 1
  %v559 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 26
  %v560 = load float, ptr %v559, align 4
  %v561 = insertelement <4 x float> %v558, float %v560, i64 2
  %v562 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 27
  %v563 = load float, ptr %v562, align 4
  %v564 = insertelement <4 x float> %v561, float %v563, i64 3
  %v565 = add i64 %v552, 0
  %v566 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v565
  store <4 x float> %v564, ptr addrspace(1) %v566, align 16
  %v567 = add i64 %v17, %v176
  %v568 = add i64 %v567, 67
  %v569 = mul i64 %v568, 1024
  %v570 = add i64 %v569, %v18
  %v571 = add i64 %v570, %v177
  %v572 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 28
  %v573 = load float, ptr %v572, align 4
  %v574 = insertelement <4 x float> poison, float %v573, i64 0
  %v575 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 29
  %v576 = load float, ptr %v575, align 4
  %v577 = insertelement <4 x float> %v574, float %v576, i64 1
  %v578 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 30
  %v579 = load float, ptr %v578, align 4
  %v580 = insertelement <4 x float> %v577, float %v579, i64 2
  %v581 = getelementptr inbounds [32 x float], ptr %v19, i64 0, i64 31
  %v582 = load float, ptr %v581, align 4
  %v583 = insertelement <4 x float> %v580, float %v582, i64 3
  %v584 = add i64 %v571, 0
  %v585 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v584
  store <4 x float> %v583, ptr addrspace(1) %v585, align 16
  ret void
}

define internal float @fn1(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 7, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 13, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 101, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 50, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to float
  store float %t33, ptr %o1
  %t34 = load float, ptr %o1
  ret float %t34
}

define ptx_kernel void @mapal_gen_7a2ade86c804ef09(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call float @fn1(i32 %x)
  %p = getelementptr inbounds float, ptr addrspace(1) %o, i64 %i
  store float %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

define internal float @fn2(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 7, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 57, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 101, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 50, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to float
  store float %t33, ptr %o1
  %t34 = load float, ptr %o1
  ret float %t34
}

define ptx_kernel void @mapal_gen_1aeae5b5ba14d87e(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call float @fn2(i32 %x)
  %p = getelementptr inbounds float, ptr addrspace(1) %o, i64 %i
  store float %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

!0 = distinct !{!0, !1}
!1 = !{!"llvm.loop.unroll.full"}
