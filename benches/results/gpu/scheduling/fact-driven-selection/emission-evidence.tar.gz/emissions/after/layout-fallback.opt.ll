; ModuleID = '/private/tmp/mapal-gpu-schedule-facts/emissions/after/layout-fallback.device.ll'
source_filename = "/private/tmp/mapal-gpu-schedule-facts/emissions/after/layout-fallback.device.ll"
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@mapal_smem = external local_unnamed_addr addrspace(3) global [0 x i8], align 16

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.nvvm.read.ptx.sreg.tid.x() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 2147483647) i32 @llvm.nvvm.read.ptx.sreg.ctaid.x() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 65535) i32 @llvm.nvvm.read.ptx.sreg.ctaid.y() #0

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.fma.f32(float, float, float) #1

; Function Attrs: norecurse nounwind
define ptx_kernel void @mapal_tile_5dccd94ababd20c9(ptr addrspace(1) noalias readonly align 16 captures(none) %a, ptr addrspace(1) noalias readonly align 16 captures(none) %b, ptr addrspace(1) noalias writeonly align 16 captures(none) %o) local_unnamed_addr #2 {
entry:
  %v1 = tail call range(i32 0, 32) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = zext nneg i32 %v1 to i64
  %v3 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v4 = zext nneg i32 %v3 to i64
  %v5 = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %0 = shl nuw nsw i32 %v5, 6
  %v9 = zext nneg i32 %0 to i64
  %v10 = shl nuw nsw i64 %v4, 5
  %v86 = or disjoint i64 %v2, 32
  %v1572 = lshr i64 %v2, 3
  %v158 = shl nuw nsw i64 %v2, 2
  %v159 = and i64 %v158, 28
  %1 = shl nuw nsw i64 %v2, 1
  %v168 = and i64 %1, 56
  %v8 = shl nuw nsw i64 %v2, 3
  %v169 = and i64 %v8, 24
  %2 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v9
  %v173 = getelementptr inbounds nuw float, ptr addrspace(1) %2, i64 %v2
  %v174 = load float, ptr addrspace(1) %v173, align 4
  %3 = getelementptr inbounds nuw float, ptr addrspace(1) %a, i64 %v86
  %v176 = getelementptr inbounds nuw float, ptr addrspace(1) %3, i64 %v9
  %v177 = load float, ptr addrspace(1) %v176, align 4
  %v179 = getelementptr inbounds nuw i8, ptr addrspace(1) %v173, i64 1024
  %v180 = load float, ptr addrspace(1) %v179, align 4
  %v182 = getelementptr inbounds nuw i8, ptr addrspace(1) %v173, i64 1152
  %v183 = load float, ptr addrspace(1) %v182, align 4
  %v185 = getelementptr inbounds nuw i8, ptr addrspace(1) %v173, i64 2048
  %v186 = load float, ptr addrspace(1) %v185, align 4
  %v188 = getelementptr inbounds nuw i8, ptr addrspace(1) %v173, i64 2176
  %v189 = load float, ptr addrspace(1) %v188, align 4
  %v191 = getelementptr inbounds nuw i8, ptr addrspace(1) %v173, i64 3072
  %v192 = load float, ptr addrspace(1) %v191, align 4
  %v194 = getelementptr inbounds nuw i8, ptr addrspace(1) %v173, i64 3200
  %v195 = load float, ptr addrspace(1) %v194, align 4
  %.idx3 = shl nuw nsw i64 %v1572, 10
  %4 = getelementptr inbounds nuw i8, ptr addrspace(1) %b, i64 %.idx3
  %5 = getelementptr inbounds nuw float, ptr addrspace(1) %4, i64 %v10
  %v197 = getelementptr inbounds nuw float, ptr addrspace(1) %5, i64 %v159
  %v198 = load <4 x float>, ptr addrspace(1) %v197, align 16
  %v210 = getelementptr inbounds nuw float, ptr addrspace(3) @mapal_smem, i64 %v2
  %v211 = getelementptr inbounds nuw float, ptr addrspace(3) @mapal_smem, i64 %v86
  %v212 = getelementptr inbounds nuw i8, ptr addrspace(3) %v210, i64 256
  %v213 = getelementptr inbounds nuw i8, ptr addrspace(3) %v210, i64 384
  %v214 = getelementptr inbounds nuw i8, ptr addrspace(3) %v210, i64 512
  %v215 = getelementptr inbounds nuw i8, ptr addrspace(3) %v210, i64 640
  %v216 = getelementptr inbounds nuw i8, ptr addrspace(3) %v210, i64 768
  %v217 = getelementptr inbounds nuw i8, ptr addrspace(3) %v210, i64 896
  %.idx = shl nuw nsw i64 %v1572, 7
  %6 = getelementptr inbounds nuw i8, ptr addrspace(3) @mapal_smem, i64 %.idx
  %7 = getelementptr inbounds nuw float, ptr addrspace(3) %6, i64 %v159
  %v218 = getelementptr inbounds nuw i8, ptr addrspace(3) %7, i64 1024
  %invariant.gep = getelementptr float, ptr addrspace(3) @mapal_smem, i64 %v168
  %invariant.gep6 = getelementptr float, ptr addrspace(3) @mapal_smem, i64 %v169
  %8 = getelementptr inbounds nuw i8, ptr addrspace(3) %invariant.gep, i64 4
  %9 = getelementptr inbounds nuw i8, ptr addrspace(3) %invariant.gep, i64 8
  %10 = getelementptr inbounds nuw i8, ptr addrspace(3) %invariant.gep, i64 12
  %v265 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 16
  %11 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 20
  %12 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 24
  %13 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 28
  %v276 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1024
  %14 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1028
  %15 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1032
  %16 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1036
  %v283 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1040
  %17 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1044
  %18 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1048
  %19 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1052
  %gep.1 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 256
  %20 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 260
  %21 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 264
  %22 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 268
  %v265.1 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 272
  %23 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 276
  %24 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 280
  %25 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 284
  %v276.1 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1152
  %26 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1156
  %27 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1160
  %28 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1164
  %v283.1 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1168
  %29 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1172
  %30 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1176
  %31 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1180
  %gep.2 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 512
  %32 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 516
  %33 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 520
  %34 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 524
  %v265.2 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 528
  %35 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 532
  %36 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 536
  %37 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 540
  %v276.2 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1280
  %38 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1284
  %39 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1288
  %40 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1292
  %v283.2 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1296
  %41 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1300
  %42 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1304
  %43 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1308
  %gep.3 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 768
  %44 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 772
  %45 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 776
  %46 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 780
  %v265.3 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 784
  %47 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 788
  %48 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 792
  %49 = getelementptr i8, ptr addrspace(3) %invariant.gep, i64 796
  %v276.3 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1408
  %50 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1412
  %51 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1416
  %52 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1420
  %v283.3 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1424
  %53 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1428
  %54 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1432
  %55 = getelementptr i8, ptr addrspace(3) %invariant.gep6, i64 1436
  br label %kt

kt:                                               ; preds = %kt, %entry
  %v11.sroa.252.0 = phi float [ 0.000000e+00, %entry ], [ %v480.3, %kt ]
  %v11.sroa.248.0 = phi float [ 0.000000e+00, %entry ], [ %v477.3, %kt ]
  %v11.sroa.244.0 = phi float [ 0.000000e+00, %entry ], [ %v474.3, %kt ]
  %v11.sroa.240.0 = phi float [ 0.000000e+00, %entry ], [ %v471.3, %kt ]
  %v11.sroa.236.0 = phi float [ 0.000000e+00, %entry ], [ %v468.3, %kt ]
  %v11.sroa.232.0 = phi float [ 0.000000e+00, %entry ], [ %v465.3, %kt ]
  %v11.sroa.228.0 = phi float [ 0.000000e+00, %entry ], [ %v462.3, %kt ]
  %v11.sroa.224.0 = phi float [ 0.000000e+00, %entry ], [ %v459.3, %kt ]
  %v11.sroa.220.0 = phi float [ 0.000000e+00, %entry ], [ %v456.3, %kt ]
  %v11.sroa.216.0 = phi float [ 0.000000e+00, %entry ], [ %v453.3, %kt ]
  %v11.sroa.212.0 = phi float [ 0.000000e+00, %entry ], [ %v450.3, %kt ]
  %v11.sroa.208.0 = phi float [ 0.000000e+00, %entry ], [ %v447.3, %kt ]
  %v11.sroa.204.0 = phi float [ 0.000000e+00, %entry ], [ %v444.3, %kt ]
  %v11.sroa.200.0 = phi float [ 0.000000e+00, %entry ], [ %v441.3, %kt ]
  %v11.sroa.196.0 = phi float [ 0.000000e+00, %entry ], [ %v438.3, %kt ]
  %v11.sroa.192.0 = phi float [ 0.000000e+00, %entry ], [ %v435.3, %kt ]
  %v11.sroa.188.0 = phi float [ 0.000000e+00, %entry ], [ %v432.3, %kt ]
  %v11.sroa.184.0 = phi float [ 0.000000e+00, %entry ], [ %v429.3, %kt ]
  %v11.sroa.180.0 = phi float [ 0.000000e+00, %entry ], [ %v426.3, %kt ]
  %v11.sroa.176.0 = phi float [ 0.000000e+00, %entry ], [ %v423.3, %kt ]
  %v11.sroa.172.0 = phi float [ 0.000000e+00, %entry ], [ %v420.3, %kt ]
  %v11.sroa.168.0 = phi float [ 0.000000e+00, %entry ], [ %v417.3, %kt ]
  %v11.sroa.164.0 = phi float [ 0.000000e+00, %entry ], [ %v414.3, %kt ]
  %v11.sroa.160.0 = phi float [ 0.000000e+00, %entry ], [ %v411.3, %kt ]
  %v11.sroa.156.0 = phi float [ 0.000000e+00, %entry ], [ %v408.3, %kt ]
  %v11.sroa.152.0 = phi float [ 0.000000e+00, %entry ], [ %v405.3, %kt ]
  %v11.sroa.148.0 = phi float [ 0.000000e+00, %entry ], [ %v402.3, %kt ]
  %v11.sroa.144.0 = phi float [ 0.000000e+00, %entry ], [ %v399.3, %kt ]
  %v11.sroa.140.0 = phi float [ 0.000000e+00, %entry ], [ %v396.3, %kt ]
  %v11.sroa.136.0 = phi float [ 0.000000e+00, %entry ], [ %v393.3, %kt ]
  %v11.sroa.132.0 = phi float [ 0.000000e+00, %entry ], [ %v390.3, %kt ]
  %v11.sroa.128.0 = phi float [ 0.000000e+00, %entry ], [ %v387.3, %kt ]
  %v11.sroa.124.0 = phi float [ 0.000000e+00, %entry ], [ %v384.3, %kt ]
  %v11.sroa.120.0 = phi float [ 0.000000e+00, %entry ], [ %v381.3, %kt ]
  %v11.sroa.116.0 = phi float [ 0.000000e+00, %entry ], [ %v378.3, %kt ]
  %v11.sroa.112.0 = phi float [ 0.000000e+00, %entry ], [ %v375.3, %kt ]
  %v11.sroa.108.0 = phi float [ 0.000000e+00, %entry ], [ %v372.3, %kt ]
  %v11.sroa.104.0 = phi float [ 0.000000e+00, %entry ], [ %v369.3, %kt ]
  %v11.sroa.100.0 = phi float [ 0.000000e+00, %entry ], [ %v366.3, %kt ]
  %v11.sroa.96.0 = phi float [ 0.000000e+00, %entry ], [ %v363.3, %kt ]
  %v11.sroa.92.0 = phi float [ 0.000000e+00, %entry ], [ %v360.3, %kt ]
  %v11.sroa.88.0 = phi float [ 0.000000e+00, %entry ], [ %v357.3, %kt ]
  %v11.sroa.84.0 = phi float [ 0.000000e+00, %entry ], [ %v354.3, %kt ]
  %v11.sroa.80.0 = phi float [ 0.000000e+00, %entry ], [ %v351.3, %kt ]
  %v11.sroa.76.0 = phi float [ 0.000000e+00, %entry ], [ %v348.3, %kt ]
  %v11.sroa.72.0 = phi float [ 0.000000e+00, %entry ], [ %v345.3, %kt ]
  %v11.sroa.68.0 = phi float [ 0.000000e+00, %entry ], [ %v342.3, %kt ]
  %v11.sroa.64.0 = phi float [ 0.000000e+00, %entry ], [ %v339.3, %kt ]
  %v11.sroa.60.0 = phi float [ 0.000000e+00, %entry ], [ %v336.3, %kt ]
  %v11.sroa.56.0 = phi float [ 0.000000e+00, %entry ], [ %v333.3, %kt ]
  %v11.sroa.52.0 = phi float [ 0.000000e+00, %entry ], [ %v330.3, %kt ]
  %v11.sroa.48.0 = phi float [ 0.000000e+00, %entry ], [ %v327.3, %kt ]
  %v11.sroa.44.0 = phi float [ 0.000000e+00, %entry ], [ %v324.3, %kt ]
  %v11.sroa.40.0 = phi float [ 0.000000e+00, %entry ], [ %v321.3, %kt ]
  %v11.sroa.36.0 = phi float [ 0.000000e+00, %entry ], [ %v318.3, %kt ]
  %v11.sroa.32.0 = phi float [ 0.000000e+00, %entry ], [ %v315.3, %kt ]
  %v11.sroa.28.0 = phi float [ 0.000000e+00, %entry ], [ %v312.3, %kt ]
  %v11.sroa.24.0 = phi float [ 0.000000e+00, %entry ], [ %v309.3, %kt ]
  %v11.sroa.20.0 = phi float [ 0.000000e+00, %entry ], [ %v306.3, %kt ]
  %v11.sroa.16.0 = phi float [ 0.000000e+00, %entry ], [ %v303.3, %kt ]
  %v11.sroa.12.0 = phi float [ 0.000000e+00, %entry ], [ %v300.3, %kt ]
  %v11.sroa.8.0 = phi float [ 0.000000e+00, %entry ], [ %v297.3, %kt ]
  %v11.sroa.4.0 = phi float [ 0.000000e+00, %entry ], [ %v294.3, %kt ]
  %v11.sroa.0.0 = phi float [ 0.000000e+00, %entry ], [ %v291.3, %kt ]
  %v199 = phi i64 [ 0, %entry ], [ %v219, %kt ]
  %v201 = phi float [ %v174, %entry ], [ %v226, %kt ]
  %v202 = phi float [ %v177, %entry ], [ %v229, %kt ]
  %v203 = phi float [ %v180, %entry ], [ %v232, %kt ]
  %v204 = phi float [ %v183, %entry ], [ %v235, %kt ]
  %v205 = phi float [ %v186, %entry ], [ %v238, %kt ]
  %v206 = phi float [ %v189, %entry ], [ %v241, %kt ]
  %v207 = phi float [ %v192, %entry ], [ %v244, %kt ]
  %v208 = phi float [ %v195, %entry ], [ %v247, %kt ]
  %v209 = phi <4 x float> [ %v198, %entry ], [ %v250, %kt ]
  store float %v201, ptr addrspace(3) %v210, align 4
  store float %v202, ptr addrspace(3) %v211, align 4
  store float %v203, ptr addrspace(3) %v212, align 4
  store float %v204, ptr addrspace(3) %v213, align 4
  store float %v205, ptr addrspace(3) %v214, align 4
  store float %v206, ptr addrspace(3) %v215, align 4
  store float %v207, ptr addrspace(3) %v216, align 4
  store float %v208, ptr addrspace(3) %v217, align 4
  store <4 x float> %v209, ptr addrspace(3) %v218, align 16
  tail call void @llvm.nvvm.barrier.cta.sync.aligned.all(i32 0)
  %v219 = add nuw nsw i64 %v199, 4
  %v220 = icmp samesign ult i64 %v199, 124
  %v221 = select i1 %v220, i64 %v219, i64 %v199
  %v222 = shl i64 %v221, 8
  %v225 = getelementptr float, ptr addrspace(1) %v173, i64 %v222
  %v226 = load float, ptr addrspace(1) %v225, align 4
  %v228 = getelementptr float, ptr addrspace(1) %v176, i64 %v222
  %v229 = load float, ptr addrspace(1) %v228, align 4
  %v231 = getelementptr float, ptr addrspace(1) %v179, i64 %v222
  %v232 = load float, ptr addrspace(1) %v231, align 4
  %v234 = getelementptr float, ptr addrspace(1) %v182, i64 %v222
  %v235 = load float, ptr addrspace(1) %v234, align 4
  %v237 = getelementptr float, ptr addrspace(1) %v185, i64 %v222
  %v238 = load float, ptr addrspace(1) %v237, align 4
  %v240 = getelementptr float, ptr addrspace(1) %v188, i64 %v222
  %v241 = load float, ptr addrspace(1) %v240, align 4
  %v243 = getelementptr float, ptr addrspace(1) %v191, i64 %v222
  %v244 = load float, ptr addrspace(1) %v243, align 4
  %v246 = getelementptr float, ptr addrspace(1) %v194, i64 %v222
  %v247 = load float, ptr addrspace(1) %v246, align 4
  %v249 = getelementptr float, ptr addrspace(1) %v197, i64 %v222
  %v250 = load <4 x float>, ptr addrspace(1) %v249, align 16
  %v260 = load float, ptr addrspace(3) %invariant.gep, align 16
  %v261 = load float, ptr addrspace(3) %8, align 4
  %v262 = load float, ptr addrspace(3) %9, align 8
  %v263 = load float, ptr addrspace(3) %10, align 4
  %v267 = load float, ptr addrspace(3) %v265, align 16
  %v268 = load float, ptr addrspace(3) %11, align 4
  %v269 = load float, ptr addrspace(3) %12, align 8
  %v270 = load float, ptr addrspace(3) %13, align 4
  %v278 = load float, ptr addrspace(3) %v276, align 16
  %v279 = load float, ptr addrspace(3) %14, align 4
  %v280 = load float, ptr addrspace(3) %15, align 8
  %v281 = load float, ptr addrspace(3) %16, align 4
  %v285 = load float, ptr addrspace(3) %v283, align 16
  %v286 = load float, ptr addrspace(3) %17, align 4
  %v287 = load float, ptr addrspace(3) %18, align 8
  %v288 = load float, ptr addrspace(3) %19, align 4
  %v291 = tail call float @llvm.fma.f32(float %v260, float %v278, float %v11.sroa.0.0)
  %v294 = tail call float @llvm.fma.f32(float %v260, float %v279, float %v11.sroa.4.0)
  %v297 = tail call float @llvm.fma.f32(float %v260, float %v280, float %v11.sroa.8.0)
  %v300 = tail call float @llvm.fma.f32(float %v260, float %v281, float %v11.sroa.12.0)
  %v303 = tail call float @llvm.fma.f32(float %v260, float %v285, float %v11.sroa.16.0)
  %v306 = tail call float @llvm.fma.f32(float %v260, float %v286, float %v11.sroa.20.0)
  %v309 = tail call float @llvm.fma.f32(float %v260, float %v287, float %v11.sroa.24.0)
  %v312 = tail call float @llvm.fma.f32(float %v260, float %v288, float %v11.sroa.28.0)
  %v315 = tail call float @llvm.fma.f32(float %v261, float %v278, float %v11.sroa.32.0)
  %v318 = tail call float @llvm.fma.f32(float %v261, float %v279, float %v11.sroa.36.0)
  %v321 = tail call float @llvm.fma.f32(float %v261, float %v280, float %v11.sroa.40.0)
  %v324 = tail call float @llvm.fma.f32(float %v261, float %v281, float %v11.sroa.44.0)
  %v327 = tail call float @llvm.fma.f32(float %v261, float %v285, float %v11.sroa.48.0)
  %v330 = tail call float @llvm.fma.f32(float %v261, float %v286, float %v11.sroa.52.0)
  %v333 = tail call float @llvm.fma.f32(float %v261, float %v287, float %v11.sroa.56.0)
  %v336 = tail call float @llvm.fma.f32(float %v261, float %v288, float %v11.sroa.60.0)
  %v339 = tail call float @llvm.fma.f32(float %v262, float %v278, float %v11.sroa.64.0)
  %v342 = tail call float @llvm.fma.f32(float %v262, float %v279, float %v11.sroa.68.0)
  %v345 = tail call float @llvm.fma.f32(float %v262, float %v280, float %v11.sroa.72.0)
  %v348 = tail call float @llvm.fma.f32(float %v262, float %v281, float %v11.sroa.76.0)
  %v351 = tail call float @llvm.fma.f32(float %v262, float %v285, float %v11.sroa.80.0)
  %v354 = tail call float @llvm.fma.f32(float %v262, float %v286, float %v11.sroa.84.0)
  %v357 = tail call float @llvm.fma.f32(float %v262, float %v287, float %v11.sroa.88.0)
  %v360 = tail call float @llvm.fma.f32(float %v262, float %v288, float %v11.sroa.92.0)
  %v363 = tail call float @llvm.fma.f32(float %v263, float %v278, float %v11.sroa.96.0)
  %v366 = tail call float @llvm.fma.f32(float %v263, float %v279, float %v11.sroa.100.0)
  %v369 = tail call float @llvm.fma.f32(float %v263, float %v280, float %v11.sroa.104.0)
  %v372 = tail call float @llvm.fma.f32(float %v263, float %v281, float %v11.sroa.108.0)
  %v375 = tail call float @llvm.fma.f32(float %v263, float %v285, float %v11.sroa.112.0)
  %v378 = tail call float @llvm.fma.f32(float %v263, float %v286, float %v11.sroa.116.0)
  %v381 = tail call float @llvm.fma.f32(float %v263, float %v287, float %v11.sroa.120.0)
  %v384 = tail call float @llvm.fma.f32(float %v263, float %v288, float %v11.sroa.124.0)
  %v387 = tail call float @llvm.fma.f32(float %v267, float %v278, float %v11.sroa.128.0)
  %v390 = tail call float @llvm.fma.f32(float %v267, float %v279, float %v11.sroa.132.0)
  %v393 = tail call float @llvm.fma.f32(float %v267, float %v280, float %v11.sroa.136.0)
  %v396 = tail call float @llvm.fma.f32(float %v267, float %v281, float %v11.sroa.140.0)
  %v399 = tail call float @llvm.fma.f32(float %v267, float %v285, float %v11.sroa.144.0)
  %v402 = tail call float @llvm.fma.f32(float %v267, float %v286, float %v11.sroa.148.0)
  %v405 = tail call float @llvm.fma.f32(float %v267, float %v287, float %v11.sroa.152.0)
  %v408 = tail call float @llvm.fma.f32(float %v267, float %v288, float %v11.sroa.156.0)
  %v411 = tail call float @llvm.fma.f32(float %v268, float %v278, float %v11.sroa.160.0)
  %v414 = tail call float @llvm.fma.f32(float %v268, float %v279, float %v11.sroa.164.0)
  %v417 = tail call float @llvm.fma.f32(float %v268, float %v280, float %v11.sroa.168.0)
  %v420 = tail call float @llvm.fma.f32(float %v268, float %v281, float %v11.sroa.172.0)
  %v423 = tail call float @llvm.fma.f32(float %v268, float %v285, float %v11.sroa.176.0)
  %v426 = tail call float @llvm.fma.f32(float %v268, float %v286, float %v11.sroa.180.0)
  %v429 = tail call float @llvm.fma.f32(float %v268, float %v287, float %v11.sroa.184.0)
  %v432 = tail call float @llvm.fma.f32(float %v268, float %v288, float %v11.sroa.188.0)
  %v435 = tail call float @llvm.fma.f32(float %v269, float %v278, float %v11.sroa.192.0)
  %v438 = tail call float @llvm.fma.f32(float %v269, float %v279, float %v11.sroa.196.0)
  %v441 = tail call float @llvm.fma.f32(float %v269, float %v280, float %v11.sroa.200.0)
  %v444 = tail call float @llvm.fma.f32(float %v269, float %v281, float %v11.sroa.204.0)
  %v447 = tail call float @llvm.fma.f32(float %v269, float %v285, float %v11.sroa.208.0)
  %v450 = tail call float @llvm.fma.f32(float %v269, float %v286, float %v11.sroa.212.0)
  %v453 = tail call float @llvm.fma.f32(float %v269, float %v287, float %v11.sroa.216.0)
  %v456 = tail call float @llvm.fma.f32(float %v269, float %v288, float %v11.sroa.220.0)
  %v459 = tail call float @llvm.fma.f32(float %v270, float %v278, float %v11.sroa.224.0)
  %v462 = tail call float @llvm.fma.f32(float %v270, float %v279, float %v11.sroa.228.0)
  %v465 = tail call float @llvm.fma.f32(float %v270, float %v280, float %v11.sroa.232.0)
  %v468 = tail call float @llvm.fma.f32(float %v270, float %v281, float %v11.sroa.236.0)
  %v471 = tail call float @llvm.fma.f32(float %v270, float %v285, float %v11.sroa.240.0)
  %v474 = tail call float @llvm.fma.f32(float %v270, float %v286, float %v11.sroa.244.0)
  %v477 = tail call float @llvm.fma.f32(float %v270, float %v287, float %v11.sroa.248.0)
  %v480 = tail call float @llvm.fma.f32(float %v270, float %v288, float %v11.sroa.252.0)
  %v260.1 = load float, ptr addrspace(3) %gep.1, align 16
  %v261.1 = load float, ptr addrspace(3) %20, align 4
  %v262.1 = load float, ptr addrspace(3) %21, align 8
  %v263.1 = load float, ptr addrspace(3) %22, align 4
  %v267.1 = load float, ptr addrspace(3) %v265.1, align 16
  %v268.1 = load float, ptr addrspace(3) %23, align 4
  %v269.1 = load float, ptr addrspace(3) %24, align 8
  %v270.1 = load float, ptr addrspace(3) %25, align 4
  %v278.1 = load float, ptr addrspace(3) %v276.1, align 16
  %v279.1 = load float, ptr addrspace(3) %26, align 4
  %v280.1 = load float, ptr addrspace(3) %27, align 8
  %v281.1 = load float, ptr addrspace(3) %28, align 4
  %v285.1 = load float, ptr addrspace(3) %v283.1, align 16
  %v286.1 = load float, ptr addrspace(3) %29, align 4
  %v287.1 = load float, ptr addrspace(3) %30, align 8
  %v288.1 = load float, ptr addrspace(3) %31, align 4
  %v291.1 = tail call float @llvm.fma.f32(float %v260.1, float %v278.1, float %v291)
  %v294.1 = tail call float @llvm.fma.f32(float %v260.1, float %v279.1, float %v294)
  %v297.1 = tail call float @llvm.fma.f32(float %v260.1, float %v280.1, float %v297)
  %v300.1 = tail call float @llvm.fma.f32(float %v260.1, float %v281.1, float %v300)
  %v303.1 = tail call float @llvm.fma.f32(float %v260.1, float %v285.1, float %v303)
  %v306.1 = tail call float @llvm.fma.f32(float %v260.1, float %v286.1, float %v306)
  %v309.1 = tail call float @llvm.fma.f32(float %v260.1, float %v287.1, float %v309)
  %v312.1 = tail call float @llvm.fma.f32(float %v260.1, float %v288.1, float %v312)
  %v315.1 = tail call float @llvm.fma.f32(float %v261.1, float %v278.1, float %v315)
  %v318.1 = tail call float @llvm.fma.f32(float %v261.1, float %v279.1, float %v318)
  %v321.1 = tail call float @llvm.fma.f32(float %v261.1, float %v280.1, float %v321)
  %v324.1 = tail call float @llvm.fma.f32(float %v261.1, float %v281.1, float %v324)
  %v327.1 = tail call float @llvm.fma.f32(float %v261.1, float %v285.1, float %v327)
  %v330.1 = tail call float @llvm.fma.f32(float %v261.1, float %v286.1, float %v330)
  %v333.1 = tail call float @llvm.fma.f32(float %v261.1, float %v287.1, float %v333)
  %v336.1 = tail call float @llvm.fma.f32(float %v261.1, float %v288.1, float %v336)
  %v339.1 = tail call float @llvm.fma.f32(float %v262.1, float %v278.1, float %v339)
  %v342.1 = tail call float @llvm.fma.f32(float %v262.1, float %v279.1, float %v342)
  %v345.1 = tail call float @llvm.fma.f32(float %v262.1, float %v280.1, float %v345)
  %v348.1 = tail call float @llvm.fma.f32(float %v262.1, float %v281.1, float %v348)
  %v351.1 = tail call float @llvm.fma.f32(float %v262.1, float %v285.1, float %v351)
  %v354.1 = tail call float @llvm.fma.f32(float %v262.1, float %v286.1, float %v354)
  %v357.1 = tail call float @llvm.fma.f32(float %v262.1, float %v287.1, float %v357)
  %v360.1 = tail call float @llvm.fma.f32(float %v262.1, float %v288.1, float %v360)
  %v363.1 = tail call float @llvm.fma.f32(float %v263.1, float %v278.1, float %v363)
  %v366.1 = tail call float @llvm.fma.f32(float %v263.1, float %v279.1, float %v366)
  %v369.1 = tail call float @llvm.fma.f32(float %v263.1, float %v280.1, float %v369)
  %v372.1 = tail call float @llvm.fma.f32(float %v263.1, float %v281.1, float %v372)
  %v375.1 = tail call float @llvm.fma.f32(float %v263.1, float %v285.1, float %v375)
  %v378.1 = tail call float @llvm.fma.f32(float %v263.1, float %v286.1, float %v378)
  %v381.1 = tail call float @llvm.fma.f32(float %v263.1, float %v287.1, float %v381)
  %v384.1 = tail call float @llvm.fma.f32(float %v263.1, float %v288.1, float %v384)
  %v387.1 = tail call float @llvm.fma.f32(float %v267.1, float %v278.1, float %v387)
  %v390.1 = tail call float @llvm.fma.f32(float %v267.1, float %v279.1, float %v390)
  %v393.1 = tail call float @llvm.fma.f32(float %v267.1, float %v280.1, float %v393)
  %v396.1 = tail call float @llvm.fma.f32(float %v267.1, float %v281.1, float %v396)
  %v399.1 = tail call float @llvm.fma.f32(float %v267.1, float %v285.1, float %v399)
  %v402.1 = tail call float @llvm.fma.f32(float %v267.1, float %v286.1, float %v402)
  %v405.1 = tail call float @llvm.fma.f32(float %v267.1, float %v287.1, float %v405)
  %v408.1 = tail call float @llvm.fma.f32(float %v267.1, float %v288.1, float %v408)
  %v411.1 = tail call float @llvm.fma.f32(float %v268.1, float %v278.1, float %v411)
  %v414.1 = tail call float @llvm.fma.f32(float %v268.1, float %v279.1, float %v414)
  %v417.1 = tail call float @llvm.fma.f32(float %v268.1, float %v280.1, float %v417)
  %v420.1 = tail call float @llvm.fma.f32(float %v268.1, float %v281.1, float %v420)
  %v423.1 = tail call float @llvm.fma.f32(float %v268.1, float %v285.1, float %v423)
  %v426.1 = tail call float @llvm.fma.f32(float %v268.1, float %v286.1, float %v426)
  %v429.1 = tail call float @llvm.fma.f32(float %v268.1, float %v287.1, float %v429)
  %v432.1 = tail call float @llvm.fma.f32(float %v268.1, float %v288.1, float %v432)
  %v435.1 = tail call float @llvm.fma.f32(float %v269.1, float %v278.1, float %v435)
  %v438.1 = tail call float @llvm.fma.f32(float %v269.1, float %v279.1, float %v438)
  %v441.1 = tail call float @llvm.fma.f32(float %v269.1, float %v280.1, float %v441)
  %v444.1 = tail call float @llvm.fma.f32(float %v269.1, float %v281.1, float %v444)
  %v447.1 = tail call float @llvm.fma.f32(float %v269.1, float %v285.1, float %v447)
  %v450.1 = tail call float @llvm.fma.f32(float %v269.1, float %v286.1, float %v450)
  %v453.1 = tail call float @llvm.fma.f32(float %v269.1, float %v287.1, float %v453)
  %v456.1 = tail call float @llvm.fma.f32(float %v269.1, float %v288.1, float %v456)
  %v459.1 = tail call float @llvm.fma.f32(float %v270.1, float %v278.1, float %v459)
  %v462.1 = tail call float @llvm.fma.f32(float %v270.1, float %v279.1, float %v462)
  %v465.1 = tail call float @llvm.fma.f32(float %v270.1, float %v280.1, float %v465)
  %v468.1 = tail call float @llvm.fma.f32(float %v270.1, float %v281.1, float %v468)
  %v471.1 = tail call float @llvm.fma.f32(float %v270.1, float %v285.1, float %v471)
  %v474.1 = tail call float @llvm.fma.f32(float %v270.1, float %v286.1, float %v474)
  %v477.1 = tail call float @llvm.fma.f32(float %v270.1, float %v287.1, float %v477)
  %v480.1 = tail call float @llvm.fma.f32(float %v270.1, float %v288.1, float %v480)
  %v260.2 = load float, ptr addrspace(3) %gep.2, align 16
  %v261.2 = load float, ptr addrspace(3) %32, align 4
  %v262.2 = load float, ptr addrspace(3) %33, align 8
  %v263.2 = load float, ptr addrspace(3) %34, align 4
  %v267.2 = load float, ptr addrspace(3) %v265.2, align 16
  %v268.2 = load float, ptr addrspace(3) %35, align 4
  %v269.2 = load float, ptr addrspace(3) %36, align 8
  %v270.2 = load float, ptr addrspace(3) %37, align 4
  %v278.2 = load float, ptr addrspace(3) %v276.2, align 16
  %v279.2 = load float, ptr addrspace(3) %38, align 4
  %v280.2 = load float, ptr addrspace(3) %39, align 8
  %v281.2 = load float, ptr addrspace(3) %40, align 4
  %v285.2 = load float, ptr addrspace(3) %v283.2, align 16
  %v286.2 = load float, ptr addrspace(3) %41, align 4
  %v287.2 = load float, ptr addrspace(3) %42, align 8
  %v288.2 = load float, ptr addrspace(3) %43, align 4
  %v291.2 = tail call float @llvm.fma.f32(float %v260.2, float %v278.2, float %v291.1)
  %v294.2 = tail call float @llvm.fma.f32(float %v260.2, float %v279.2, float %v294.1)
  %v297.2 = tail call float @llvm.fma.f32(float %v260.2, float %v280.2, float %v297.1)
  %v300.2 = tail call float @llvm.fma.f32(float %v260.2, float %v281.2, float %v300.1)
  %v303.2 = tail call float @llvm.fma.f32(float %v260.2, float %v285.2, float %v303.1)
  %v306.2 = tail call float @llvm.fma.f32(float %v260.2, float %v286.2, float %v306.1)
  %v309.2 = tail call float @llvm.fma.f32(float %v260.2, float %v287.2, float %v309.1)
  %v312.2 = tail call float @llvm.fma.f32(float %v260.2, float %v288.2, float %v312.1)
  %v315.2 = tail call float @llvm.fma.f32(float %v261.2, float %v278.2, float %v315.1)
  %v318.2 = tail call float @llvm.fma.f32(float %v261.2, float %v279.2, float %v318.1)
  %v321.2 = tail call float @llvm.fma.f32(float %v261.2, float %v280.2, float %v321.1)
  %v324.2 = tail call float @llvm.fma.f32(float %v261.2, float %v281.2, float %v324.1)
  %v327.2 = tail call float @llvm.fma.f32(float %v261.2, float %v285.2, float %v327.1)
  %v330.2 = tail call float @llvm.fma.f32(float %v261.2, float %v286.2, float %v330.1)
  %v333.2 = tail call float @llvm.fma.f32(float %v261.2, float %v287.2, float %v333.1)
  %v336.2 = tail call float @llvm.fma.f32(float %v261.2, float %v288.2, float %v336.1)
  %v339.2 = tail call float @llvm.fma.f32(float %v262.2, float %v278.2, float %v339.1)
  %v342.2 = tail call float @llvm.fma.f32(float %v262.2, float %v279.2, float %v342.1)
  %v345.2 = tail call float @llvm.fma.f32(float %v262.2, float %v280.2, float %v345.1)
  %v348.2 = tail call float @llvm.fma.f32(float %v262.2, float %v281.2, float %v348.1)
  %v351.2 = tail call float @llvm.fma.f32(float %v262.2, float %v285.2, float %v351.1)
  %v354.2 = tail call float @llvm.fma.f32(float %v262.2, float %v286.2, float %v354.1)
  %v357.2 = tail call float @llvm.fma.f32(float %v262.2, float %v287.2, float %v357.1)
  %v360.2 = tail call float @llvm.fma.f32(float %v262.2, float %v288.2, float %v360.1)
  %v363.2 = tail call float @llvm.fma.f32(float %v263.2, float %v278.2, float %v363.1)
  %v366.2 = tail call float @llvm.fma.f32(float %v263.2, float %v279.2, float %v366.1)
  %v369.2 = tail call float @llvm.fma.f32(float %v263.2, float %v280.2, float %v369.1)
  %v372.2 = tail call float @llvm.fma.f32(float %v263.2, float %v281.2, float %v372.1)
  %v375.2 = tail call float @llvm.fma.f32(float %v263.2, float %v285.2, float %v375.1)
  %v378.2 = tail call float @llvm.fma.f32(float %v263.2, float %v286.2, float %v378.1)
  %v381.2 = tail call float @llvm.fma.f32(float %v263.2, float %v287.2, float %v381.1)
  %v384.2 = tail call float @llvm.fma.f32(float %v263.2, float %v288.2, float %v384.1)
  %v387.2 = tail call float @llvm.fma.f32(float %v267.2, float %v278.2, float %v387.1)
  %v390.2 = tail call float @llvm.fma.f32(float %v267.2, float %v279.2, float %v390.1)
  %v393.2 = tail call float @llvm.fma.f32(float %v267.2, float %v280.2, float %v393.1)
  %v396.2 = tail call float @llvm.fma.f32(float %v267.2, float %v281.2, float %v396.1)
  %v399.2 = tail call float @llvm.fma.f32(float %v267.2, float %v285.2, float %v399.1)
  %v402.2 = tail call float @llvm.fma.f32(float %v267.2, float %v286.2, float %v402.1)
  %v405.2 = tail call float @llvm.fma.f32(float %v267.2, float %v287.2, float %v405.1)
  %v408.2 = tail call float @llvm.fma.f32(float %v267.2, float %v288.2, float %v408.1)
  %v411.2 = tail call float @llvm.fma.f32(float %v268.2, float %v278.2, float %v411.1)
  %v414.2 = tail call float @llvm.fma.f32(float %v268.2, float %v279.2, float %v414.1)
  %v417.2 = tail call float @llvm.fma.f32(float %v268.2, float %v280.2, float %v417.1)
  %v420.2 = tail call float @llvm.fma.f32(float %v268.2, float %v281.2, float %v420.1)
  %v423.2 = tail call float @llvm.fma.f32(float %v268.2, float %v285.2, float %v423.1)
  %v426.2 = tail call float @llvm.fma.f32(float %v268.2, float %v286.2, float %v426.1)
  %v429.2 = tail call float @llvm.fma.f32(float %v268.2, float %v287.2, float %v429.1)
  %v432.2 = tail call float @llvm.fma.f32(float %v268.2, float %v288.2, float %v432.1)
  %v435.2 = tail call float @llvm.fma.f32(float %v269.2, float %v278.2, float %v435.1)
  %v438.2 = tail call float @llvm.fma.f32(float %v269.2, float %v279.2, float %v438.1)
  %v441.2 = tail call float @llvm.fma.f32(float %v269.2, float %v280.2, float %v441.1)
  %v444.2 = tail call float @llvm.fma.f32(float %v269.2, float %v281.2, float %v444.1)
  %v447.2 = tail call float @llvm.fma.f32(float %v269.2, float %v285.2, float %v447.1)
  %v450.2 = tail call float @llvm.fma.f32(float %v269.2, float %v286.2, float %v450.1)
  %v453.2 = tail call float @llvm.fma.f32(float %v269.2, float %v287.2, float %v453.1)
  %v456.2 = tail call float @llvm.fma.f32(float %v269.2, float %v288.2, float %v456.1)
  %v459.2 = tail call float @llvm.fma.f32(float %v270.2, float %v278.2, float %v459.1)
  %v462.2 = tail call float @llvm.fma.f32(float %v270.2, float %v279.2, float %v462.1)
  %v465.2 = tail call float @llvm.fma.f32(float %v270.2, float %v280.2, float %v465.1)
  %v468.2 = tail call float @llvm.fma.f32(float %v270.2, float %v281.2, float %v468.1)
  %v471.2 = tail call float @llvm.fma.f32(float %v270.2, float %v285.2, float %v471.1)
  %v474.2 = tail call float @llvm.fma.f32(float %v270.2, float %v286.2, float %v474.1)
  %v477.2 = tail call float @llvm.fma.f32(float %v270.2, float %v287.2, float %v477.1)
  %v480.2 = tail call float @llvm.fma.f32(float %v270.2, float %v288.2, float %v480.1)
  %v260.3 = load float, ptr addrspace(3) %gep.3, align 16
  %v261.3 = load float, ptr addrspace(3) %44, align 4
  %v262.3 = load float, ptr addrspace(3) %45, align 8
  %v263.3 = load float, ptr addrspace(3) %46, align 4
  %v267.3 = load float, ptr addrspace(3) %v265.3, align 16
  %v268.3 = load float, ptr addrspace(3) %47, align 4
  %v269.3 = load float, ptr addrspace(3) %48, align 8
  %v270.3 = load float, ptr addrspace(3) %49, align 4
  %v278.3 = load float, ptr addrspace(3) %v276.3, align 16
  %v279.3 = load float, ptr addrspace(3) %50, align 4
  %v280.3 = load float, ptr addrspace(3) %51, align 8
  %v281.3 = load float, ptr addrspace(3) %52, align 4
  %v285.3 = load float, ptr addrspace(3) %v283.3, align 16
  %v286.3 = load float, ptr addrspace(3) %53, align 4
  %v287.3 = load float, ptr addrspace(3) %54, align 8
  %v288.3 = load float, ptr addrspace(3) %55, align 4
  %v291.3 = tail call float @llvm.fma.f32(float %v260.3, float %v278.3, float %v291.2)
  %v294.3 = tail call float @llvm.fma.f32(float %v260.3, float %v279.3, float %v294.2)
  %v297.3 = tail call float @llvm.fma.f32(float %v260.3, float %v280.3, float %v297.2)
  %v300.3 = tail call float @llvm.fma.f32(float %v260.3, float %v281.3, float %v300.2)
  %v303.3 = tail call float @llvm.fma.f32(float %v260.3, float %v285.3, float %v303.2)
  %v306.3 = tail call float @llvm.fma.f32(float %v260.3, float %v286.3, float %v306.2)
  %v309.3 = tail call float @llvm.fma.f32(float %v260.3, float %v287.3, float %v309.2)
  %v312.3 = tail call float @llvm.fma.f32(float %v260.3, float %v288.3, float %v312.2)
  %v315.3 = tail call float @llvm.fma.f32(float %v261.3, float %v278.3, float %v315.2)
  %v318.3 = tail call float @llvm.fma.f32(float %v261.3, float %v279.3, float %v318.2)
  %v321.3 = tail call float @llvm.fma.f32(float %v261.3, float %v280.3, float %v321.2)
  %v324.3 = tail call float @llvm.fma.f32(float %v261.3, float %v281.3, float %v324.2)
  %v327.3 = tail call float @llvm.fma.f32(float %v261.3, float %v285.3, float %v327.2)
  %v330.3 = tail call float @llvm.fma.f32(float %v261.3, float %v286.3, float %v330.2)
  %v333.3 = tail call float @llvm.fma.f32(float %v261.3, float %v287.3, float %v333.2)
  %v336.3 = tail call float @llvm.fma.f32(float %v261.3, float %v288.3, float %v336.2)
  %v339.3 = tail call float @llvm.fma.f32(float %v262.3, float %v278.3, float %v339.2)
  %v342.3 = tail call float @llvm.fma.f32(float %v262.3, float %v279.3, float %v342.2)
  %v345.3 = tail call float @llvm.fma.f32(float %v262.3, float %v280.3, float %v345.2)
  %v348.3 = tail call float @llvm.fma.f32(float %v262.3, float %v281.3, float %v348.2)
  %v351.3 = tail call float @llvm.fma.f32(float %v262.3, float %v285.3, float %v351.2)
  %v354.3 = tail call float @llvm.fma.f32(float %v262.3, float %v286.3, float %v354.2)
  %v357.3 = tail call float @llvm.fma.f32(float %v262.3, float %v287.3, float %v357.2)
  %v360.3 = tail call float @llvm.fma.f32(float %v262.3, float %v288.3, float %v360.2)
  %v363.3 = tail call float @llvm.fma.f32(float %v263.3, float %v278.3, float %v363.2)
  %v366.3 = tail call float @llvm.fma.f32(float %v263.3, float %v279.3, float %v366.2)
  %v369.3 = tail call float @llvm.fma.f32(float %v263.3, float %v280.3, float %v369.2)
  %v372.3 = tail call float @llvm.fma.f32(float %v263.3, float %v281.3, float %v372.2)
  %v375.3 = tail call float @llvm.fma.f32(float %v263.3, float %v285.3, float %v375.2)
  %v378.3 = tail call float @llvm.fma.f32(float %v263.3, float %v286.3, float %v378.2)
  %v381.3 = tail call float @llvm.fma.f32(float %v263.3, float %v287.3, float %v381.2)
  %v384.3 = tail call float @llvm.fma.f32(float %v263.3, float %v288.3, float %v384.2)
  %v387.3 = tail call float @llvm.fma.f32(float %v267.3, float %v278.3, float %v387.2)
  %v390.3 = tail call float @llvm.fma.f32(float %v267.3, float %v279.3, float %v390.2)
  %v393.3 = tail call float @llvm.fma.f32(float %v267.3, float %v280.3, float %v393.2)
  %v396.3 = tail call float @llvm.fma.f32(float %v267.3, float %v281.3, float %v396.2)
  %v399.3 = tail call float @llvm.fma.f32(float %v267.3, float %v285.3, float %v399.2)
  %v402.3 = tail call float @llvm.fma.f32(float %v267.3, float %v286.3, float %v402.2)
  %v405.3 = tail call float @llvm.fma.f32(float %v267.3, float %v287.3, float %v405.2)
  %v408.3 = tail call float @llvm.fma.f32(float %v267.3, float %v288.3, float %v408.2)
  %v411.3 = tail call float @llvm.fma.f32(float %v268.3, float %v278.3, float %v411.2)
  %v414.3 = tail call float @llvm.fma.f32(float %v268.3, float %v279.3, float %v414.2)
  %v417.3 = tail call float @llvm.fma.f32(float %v268.3, float %v280.3, float %v417.2)
  %v420.3 = tail call float @llvm.fma.f32(float %v268.3, float %v281.3, float %v420.2)
  %v423.3 = tail call float @llvm.fma.f32(float %v268.3, float %v285.3, float %v423.2)
  %v426.3 = tail call float @llvm.fma.f32(float %v268.3, float %v286.3, float %v426.2)
  %v429.3 = tail call float @llvm.fma.f32(float %v268.3, float %v287.3, float %v429.2)
  %v432.3 = tail call float @llvm.fma.f32(float %v268.3, float %v288.3, float %v432.2)
  %v435.3 = tail call float @llvm.fma.f32(float %v269.3, float %v278.3, float %v435.2)
  %v438.3 = tail call float @llvm.fma.f32(float %v269.3, float %v279.3, float %v438.2)
  %v441.3 = tail call float @llvm.fma.f32(float %v269.3, float %v280.3, float %v441.2)
  %v444.3 = tail call float @llvm.fma.f32(float %v269.3, float %v281.3, float %v444.2)
  %v447.3 = tail call float @llvm.fma.f32(float %v269.3, float %v285.3, float %v447.2)
  %v450.3 = tail call float @llvm.fma.f32(float %v269.3, float %v286.3, float %v450.2)
  %v453.3 = tail call float @llvm.fma.f32(float %v269.3, float %v287.3, float %v453.2)
  %v456.3 = tail call float @llvm.fma.f32(float %v269.3, float %v288.3, float %v456.2)
  %v459.3 = tail call float @llvm.fma.f32(float %v270.3, float %v278.3, float %v459.2)
  %v462.3 = tail call float @llvm.fma.f32(float %v270.3, float %v279.3, float %v462.2)
  %v465.3 = tail call float @llvm.fma.f32(float %v270.3, float %v280.3, float %v465.2)
  %v468.3 = tail call float @llvm.fma.f32(float %v270.3, float %v281.3, float %v468.2)
  %v471.3 = tail call float @llvm.fma.f32(float %v270.3, float %v285.3, float %v471.2)
  %v474.3 = tail call float @llvm.fma.f32(float %v270.3, float %v286.3, float %v474.2)
  %v477.3 = tail call float @llvm.fma.f32(float %v270.3, float %v287.3, float %v477.2)
  %v480.3 = tail call float @llvm.fma.f32(float %v270.3, float %v288.3, float %v480.2)
  tail call void @llvm.nvvm.barrier.cta.sync.aligned.all(i32 0)
  %v482 = icmp eq i64 %v219, 128
  br i1 %v482, label %done, label %kt

done:                                             ; preds = %kt
  %v483 = or disjoint i64 %v168, %v9
  %v490 = insertelement <4 x float> poison, float %v291.3, i64 0
  %v493 = insertelement <4 x float> %v490, float %v294.3, i64 1
  %v496 = insertelement <4 x float> %v493, float %v297.3, i64 2
  %v499 = insertelement <4 x float> %v496, float %v300.3, i64 3
  %.idx8 = shl nuw nsw i64 %v483, 10
  %56 = getelementptr inbounds nuw i8, ptr addrspace(1) %o, i64 %.idx8
  %57 = getelementptr inbounds nuw float, ptr addrspace(1) %56, i64 %v10
  %v501 = getelementptr inbounds nuw float, ptr addrspace(1) %57, i64 %v169
  store <4 x float> %v499, ptr addrspace(1) %v501, align 16
  %v504 = insertelement <4 x float> poison, float %v303.3, i64 0
  %v507 = insertelement <4 x float> %v504, float %v306.3, i64 1
  %v510 = insertelement <4 x float> %v507, float %v309.3, i64 2
  %v513 = insertelement <4 x float> %v510, float %v312.3, i64 3
  %v515 = getelementptr inbounds nuw i8, ptr addrspace(1) %v501, i64 16
  store <4 x float> %v513, ptr addrspace(1) %v515, align 16
  %v523 = insertelement <4 x float> poison, float %v315.3, i64 0
  %v526 = insertelement <4 x float> %v523, float %v318.3, i64 1
  %v529 = insertelement <4 x float> %v526, float %v321.3, i64 2
  %v532 = insertelement <4 x float> %v529, float %v324.3, i64 3
  %58 = getelementptr inbounds nuw i8, ptr addrspace(1) %56, i64 1024
  %59 = getelementptr inbounds nuw float, ptr addrspace(1) %58, i64 %v10
  %v534 = getelementptr inbounds nuw float, ptr addrspace(1) %59, i64 %v169
  store <4 x float> %v532, ptr addrspace(1) %v534, align 16
  %v537 = insertelement <4 x float> poison, float %v327.3, i64 0
  %v540 = insertelement <4 x float> %v537, float %v330.3, i64 1
  %v543 = insertelement <4 x float> %v540, float %v333.3, i64 2
  %v546 = insertelement <4 x float> %v543, float %v336.3, i64 3
  %v548 = getelementptr inbounds nuw i8, ptr addrspace(1) %v534, i64 16
  store <4 x float> %v546, ptr addrspace(1) %v548, align 16
  %v556 = insertelement <4 x float> poison, float %v339.3, i64 0
  %v559 = insertelement <4 x float> %v556, float %v342.3, i64 1
  %v562 = insertelement <4 x float> %v559, float %v345.3, i64 2
  %v565 = insertelement <4 x float> %v562, float %v348.3, i64 3
  %60 = getelementptr inbounds nuw i8, ptr addrspace(1) %56, i64 2048
  %61 = getelementptr inbounds nuw float, ptr addrspace(1) %60, i64 %v10
  %v567 = getelementptr inbounds nuw float, ptr addrspace(1) %61, i64 %v169
  store <4 x float> %v565, ptr addrspace(1) %v567, align 16
  %v570 = insertelement <4 x float> poison, float %v351.3, i64 0
  %v573 = insertelement <4 x float> %v570, float %v354.3, i64 1
  %v576 = insertelement <4 x float> %v573, float %v357.3, i64 2
  %v579 = insertelement <4 x float> %v576, float %v360.3, i64 3
  %v581 = getelementptr inbounds nuw i8, ptr addrspace(1) %v567, i64 16
  store <4 x float> %v579, ptr addrspace(1) %v581, align 16
  %v589 = insertelement <4 x float> poison, float %v363.3, i64 0
  %v592 = insertelement <4 x float> %v589, float %v366.3, i64 1
  %v595 = insertelement <4 x float> %v592, float %v369.3, i64 2
  %v598 = insertelement <4 x float> %v595, float %v372.3, i64 3
  %62 = getelementptr inbounds nuw i8, ptr addrspace(1) %56, i64 3072
  %63 = getelementptr inbounds nuw float, ptr addrspace(1) %62, i64 %v10
  %v600 = getelementptr inbounds nuw float, ptr addrspace(1) %63, i64 %v169
  store <4 x float> %v598, ptr addrspace(1) %v600, align 16
  %v603 = insertelement <4 x float> poison, float %v375.3, i64 0
  %v606 = insertelement <4 x float> %v603, float %v378.3, i64 1
  %v609 = insertelement <4 x float> %v606, float %v381.3, i64 2
  %v612 = insertelement <4 x float> %v609, float %v384.3, i64 3
  %v614 = getelementptr inbounds nuw i8, ptr addrspace(1) %v600, i64 16
  store <4 x float> %v612, ptr addrspace(1) %v614, align 16
  %v622 = insertelement <4 x float> poison, float %v387.3, i64 0
  %v625 = insertelement <4 x float> %v622, float %v390.3, i64 1
  %v628 = insertelement <4 x float> %v625, float %v393.3, i64 2
  %v631 = insertelement <4 x float> %v628, float %v396.3, i64 3
  %64 = getelementptr inbounds nuw i8, ptr addrspace(1) %56, i64 4096
  %65 = getelementptr inbounds nuw float, ptr addrspace(1) %64, i64 %v10
  %v633 = getelementptr inbounds nuw float, ptr addrspace(1) %65, i64 %v169
  store <4 x float> %v631, ptr addrspace(1) %v633, align 16
  %v636 = insertelement <4 x float> poison, float %v399.3, i64 0
  %v639 = insertelement <4 x float> %v636, float %v402.3, i64 1
  %v642 = insertelement <4 x float> %v639, float %v405.3, i64 2
  %v645 = insertelement <4 x float> %v642, float %v408.3, i64 3
  %v647 = getelementptr inbounds nuw i8, ptr addrspace(1) %v633, i64 16
  store <4 x float> %v645, ptr addrspace(1) %v647, align 16
  %v655 = insertelement <4 x float> poison, float %v411.3, i64 0
  %v658 = insertelement <4 x float> %v655, float %v414.3, i64 1
  %v661 = insertelement <4 x float> %v658, float %v417.3, i64 2
  %v664 = insertelement <4 x float> %v661, float %v420.3, i64 3
  %66 = getelementptr inbounds nuw i8, ptr addrspace(1) %56, i64 5120
  %67 = getelementptr inbounds nuw float, ptr addrspace(1) %66, i64 %v10
  %v666 = getelementptr inbounds nuw float, ptr addrspace(1) %67, i64 %v169
  store <4 x float> %v664, ptr addrspace(1) %v666, align 16
  %v669 = insertelement <4 x float> poison, float %v423.3, i64 0
  %v672 = insertelement <4 x float> %v669, float %v426.3, i64 1
  %v675 = insertelement <4 x float> %v672, float %v429.3, i64 2
  %v678 = insertelement <4 x float> %v675, float %v432.3, i64 3
  %v680 = getelementptr inbounds nuw i8, ptr addrspace(1) %v666, i64 16
  store <4 x float> %v678, ptr addrspace(1) %v680, align 16
  %v688 = insertelement <4 x float> poison, float %v435.3, i64 0
  %v691 = insertelement <4 x float> %v688, float %v438.3, i64 1
  %v694 = insertelement <4 x float> %v691, float %v441.3, i64 2
  %v697 = insertelement <4 x float> %v694, float %v444.3, i64 3
  %68 = getelementptr inbounds nuw i8, ptr addrspace(1) %56, i64 6144
  %69 = getelementptr inbounds nuw float, ptr addrspace(1) %68, i64 %v10
  %v699 = getelementptr inbounds nuw float, ptr addrspace(1) %69, i64 %v169
  store <4 x float> %v697, ptr addrspace(1) %v699, align 16
  %v702 = insertelement <4 x float> poison, float %v447.3, i64 0
  %v705 = insertelement <4 x float> %v702, float %v450.3, i64 1
  %v708 = insertelement <4 x float> %v705, float %v453.3, i64 2
  %v711 = insertelement <4 x float> %v708, float %v456.3, i64 3
  %v713 = getelementptr inbounds nuw i8, ptr addrspace(1) %v699, i64 16
  store <4 x float> %v711, ptr addrspace(1) %v713, align 16
  %v721 = insertelement <4 x float> poison, float %v459.3, i64 0
  %v724 = insertelement <4 x float> %v721, float %v462.3, i64 1
  %v727 = insertelement <4 x float> %v724, float %v465.3, i64 2
  %v730 = insertelement <4 x float> %v727, float %v468.3, i64 3
  %70 = getelementptr inbounds nuw i8, ptr addrspace(1) %56, i64 7168
  %71 = getelementptr inbounds nuw float, ptr addrspace(1) %70, i64 %v10
  %v732 = getelementptr inbounds nuw float, ptr addrspace(1) %71, i64 %v169
  store <4 x float> %v730, ptr addrspace(1) %v732, align 16
  %v735 = insertelement <4 x float> poison, float %v471.3, i64 0
  %v738 = insertelement <4 x float> %v735, float %v474.3, i64 1
  %v741 = insertelement <4 x float> %v738, float %v477.3, i64 2
  %v744 = insertelement <4 x float> %v741, float %v480.3, i64 3
  %v746 = getelementptr inbounds nuw i8, ptr addrspace(1) %v732, i64 16
  store <4 x float> %v744, ptr addrspace(1) %v746, align 16
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_8ffe47670bd33645(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #3 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %x = trunc i64 %i to i32
  %t7.i = mul i32 %x, 7
  %t15.i = add i32 %t7.i, 13
  %t23.i = srem i32 %t15.i, 101
  %t31.i = add nsw i32 %t23.i, -50
  %t33.i = sitofp i32 %t31.i to float
  %t41.i = fdiv float %t33.i, 7.000000e+00
  %p = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %i
  store float %t41.i, ptr addrspace(1) %p, align 4
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define ptx_kernel void @mapal_gen_df380f056691f9de(ptr addrspace(1) writeonly captures(none) %o, i64 %n) local_unnamed_addr #3 {
entry:
  %t = tail call range(i32 0, 256) i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = tail call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext nneg i32 %t to i64
  %b64 = zext nneg i32 %b to i64
  %base = shl nuw nsw i64 %b64, 8
  %i = or disjoint i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done

body:                                             ; preds = %entry
  %x = trunc i64 %i to i32
  %t7.i = mul i32 %x, 11
  %t15.i = add i32 %t7.i, 57
  %t23.i = srem i32 %t15.i, 103
  %t31.i = add nsw i32 %t23.i, -51
  %t33.i = sitofp i32 %t31.i to float
  %t41.i = fdiv float %t33.i, 9.000000e+00
  %p = getelementptr inbounds nuw float, ptr addrspace(1) %o, i64 %i
  store float %t41.i, ptr addrspace(1) %p, align 4
  br label %done

done:                                             ; preds = %body, %entry
  ret void
}

; Function Attrs: convergent nocallback nounwind
declare void @llvm.nvvm.barrier.cta.sync.aligned.all(i32) #4

attributes #0 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { norecurse nounwind "nvvm.maxntid"="32" "nvvm.minctasm"="16" }
attributes #3 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) "nvvm.maxntid"="256" }
attributes #4 = { convergent nocallback nounwind }
