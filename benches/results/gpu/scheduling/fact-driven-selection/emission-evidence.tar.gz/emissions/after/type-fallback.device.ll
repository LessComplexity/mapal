; mapal-backend-llvm device module
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@mapal_smem = external addrspace(3) global [0 x i8], align 16
declare i32 @llvm.nvvm.read.ptx.sreg.tid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
declare void @llvm.nvvm.barrier0()
declare void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.8(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.commit.group()
declare void @llvm.nvvm.cp.async.wait.group(i32 immarg)
declare float @llvm.fma.f32(float, float, float)
declare double @llvm.fma.f64(double, double, double)

define ptx_kernel void @mapal_tile_61d2fbbfcaf906b7(ptr addrspace(1) noalias readonly align 16 %a, ptr addrspace(1) noalias readonly align 16 %b, ptr addrspace(1) noalias align 16 %o) "nvvm.maxntid"="32" "nvvm.minctasm"="16" {
entry:
  %v1 = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = zext i32 %v1 to i64
  %v3 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v4 = zext i32 %v3 to i64
  %v5 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v6 = zext i32 %v5 to i64
  %v7 = udiv i64 %v2, 8
  %v8 = urem i64 %v2, 8
  %v9 = mul i64 %v6, 16
  %v10 = mul i64 %v4, 32
  %v11 = alloca [16 x double], align 16
  %v12 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 0
  store double 0x0000000000000000, ptr %v12, align 8
  %v13 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 1
  store double 0x0000000000000000, ptr %v13, align 8
  %v14 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 2
  store double 0x0000000000000000, ptr %v14, align 8
  %v15 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 3
  store double 0x0000000000000000, ptr %v15, align 8
  %v16 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 4
  store double 0x0000000000000000, ptr %v16, align 8
  %v17 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 5
  store double 0x0000000000000000, ptr %v17, align 8
  %v18 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 6
  store double 0x0000000000000000, ptr %v18, align 8
  %v19 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 7
  store double 0x0000000000000000, ptr %v19, align 8
  %v20 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 8
  store double 0x0000000000000000, ptr %v20, align 8
  %v21 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 9
  store double 0x0000000000000000, ptr %v21, align 8
  %v22 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 10
  store double 0x0000000000000000, ptr %v22, align 8
  %v23 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 11
  store double 0x0000000000000000, ptr %v23, align 8
  %v24 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 12
  store double 0x0000000000000000, ptr %v24, align 8
  %v25 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 13
  store double 0x0000000000000000, ptr %v25, align 8
  %v26 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 14
  store double 0x0000000000000000, ptr %v26, align 8
  %v27 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 15
  store double 0x0000000000000000, ptr %v27, align 8
  %v28 = add i64 %v2, 0
  %v29 = udiv i64 %v28, 2
  %v30 = urem i64 %v28, 2
  %v31 = mul i64 %v30, 2
  %v32 = add i64 %v9, %v29
  %v33 = mul i64 %v32, 128
  %v34 = mul i64 %v31, 1
  %v35 = add i64 %v33, %v34
  %v36 = add i64 %v35, 0
  %v37 = mul i64 %v31, 16
  %v38 = add i64 %v37, %v29
  %v39 = add i64 %v2, 0
  %v40 = udiv i64 %v39, 16
  %v41 = urem i64 %v39, 16
  %v42 = mul i64 %v41, 2
  %v43 = mul i64 %v40, 128
  %v44 = add i64 %v10, %v42
  %v45 = mul i64 %v44, 1
  %v46 = add i64 %v43, %v45
  %v47 = add i64 %v46, 0
  %v48 = mul i64 %v40, 32
  %v49 = add i64 %v48, %v42
  %v50 = add i64 %v49, 64
  %v51 = add i64 %v2, 32
  %v52 = udiv i64 %v51, 16
  %v53 = urem i64 %v51, 16
  %v54 = mul i64 %v53, 2
  %v55 = mul i64 %v52, 128
  %v56 = add i64 %v10, %v54
  %v57 = mul i64 %v56, 1
  %v58 = add i64 %v55, %v57
  %v59 = add i64 %v58, 0
  %v60 = mul i64 %v52, 32
  %v61 = add i64 %v60, %v54
  %v62 = add i64 %v61, 64
  %v63 = mul i64 %v7, 4
  %v64 = mul i64 %v8, 4
  %v65 = mul i64 0, 1
  %v66 = mul i64 0, 128
  %v67 = add i64 %v36, %v65
  %v68 = getelementptr inbounds double, ptr addrspace(1) %a, i64 %v67
  %v69 = load <2 x double>, ptr addrspace(1) %v68, align 16
  %v70 = add i64 %v47, %v66
  %v71 = getelementptr inbounds double, ptr addrspace(1) %b, i64 %v70
  %v72 = load <2 x double>, ptr addrspace(1) %v71, align 16
  %v73 = add i64 %v59, %v66
  %v74 = getelementptr inbounds double, ptr addrspace(1) %b, i64 %v73
  %v75 = load <2 x double>, ptr addrspace(1) %v74, align 16
  br label %kt
kt:
  %v76 = phi i64 [0, %entry], [%v77, %ktl]
  %v78 = phi <2 x double> [%v69, %entry], [%v96, %ktl]
  %v79 = phi <2 x double> [%v72, %entry], [%v99, %ktl]
  %v80 = phi <2 x double> [%v75, %entry], [%v102, %ktl]
  %v81 = extractelement <2 x double> %v78, i64 0
  %v82 = add i64 %v38, 0
  %v83 = getelementptr inbounds double, ptr addrspace(3) @mapal_smem, i64 %v82
  store double %v81, ptr addrspace(3) %v83, align 8
  %v84 = extractelement <2 x double> %v78, i64 1
  %v85 = add i64 %v38, 16
  %v86 = getelementptr inbounds double, ptr addrspace(3) @mapal_smem, i64 %v85
  store double %v84, ptr addrspace(3) %v86, align 8
  %v87 = getelementptr inbounds double, ptr addrspace(3) @mapal_smem, i64 %v50
  store <2 x double> %v79, ptr addrspace(3) %v87, align 16
  %v88 = getelementptr inbounds double, ptr addrspace(3) @mapal_smem, i64 %v62
  store <2 x double> %v80, ptr addrspace(3) %v88, align 16
  call void @llvm.nvvm.barrier0()
  %v89 = add i64 %v76, 4
  %v90 = icmp ult i64 %v89, 128
  %v91 = select i1 %v90, i64 %v89, i64 %v76
  %v92 = mul i64 %v91, 1
  %v93 = mul i64 %v91, 128
  %v94 = add i64 %v36, %v92
  %v95 = getelementptr inbounds double, ptr addrspace(1) %a, i64 %v94
  %v96 = load <2 x double>, ptr addrspace(1) %v95, align 16
  %v97 = add i64 %v47, %v93
  %v98 = getelementptr inbounds double, ptr addrspace(1) %b, i64 %v97
  %v99 = load <2 x double>, ptr addrspace(1) %v98, align 16
  %v100 = add i64 %v59, %v93
  %v101 = getelementptr inbounds double, ptr addrspace(1) %b, i64 %v100
  %v102 = load <2 x double>, ptr addrspace(1) %v101, align 16
  br label %kk
kk:
  %v103 = phi i64 [0, %kt], [%v104, %kk]
  %v105 = mul i64 %v103, 16
  %v106 = add i64 %v105, %v63
  %v107 = add i64 %v106, 0
  %v108 = add i64 %v107, 0
  %v109 = add i64 %v108, 0
  %v110 = getelementptr inbounds double, ptr addrspace(3) @mapal_smem, i64 %v109
  %v111 = load <2 x double>, ptr addrspace(3) %v110, align 16
  %v112 = extractelement <2 x double> %v111, i64 0
  %v113 = extractelement <2 x double> %v111, i64 1
  %v114 = add i64 %v108, 2
  %v115 = getelementptr inbounds double, ptr addrspace(3) @mapal_smem, i64 %v114
  %v116 = load <2 x double>, ptr addrspace(3) %v115, align 16
  %v117 = extractelement <2 x double> %v116, i64 0
  %v118 = extractelement <2 x double> %v116, i64 1
  %v119 = mul i64 %v103, 32
  %v120 = add i64 %v119, %v64
  %v121 = add i64 %v120, 64
  %v122 = add i64 %v121, 0
  %v123 = add i64 %v122, 0
  %v124 = getelementptr inbounds double, ptr addrspace(3) @mapal_smem, i64 %v123
  %v125 = load <2 x double>, ptr addrspace(3) %v124, align 16
  %v126 = extractelement <2 x double> %v125, i64 0
  %v127 = extractelement <2 x double> %v125, i64 1
  %v128 = add i64 %v122, 2
  %v129 = getelementptr inbounds double, ptr addrspace(3) @mapal_smem, i64 %v128
  %v130 = load <2 x double>, ptr addrspace(3) %v129, align 16
  %v131 = extractelement <2 x double> %v130, i64 0
  %v132 = extractelement <2 x double> %v130, i64 1
  %v133 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 0
  %v134 = load double, ptr %v133, align 8
  %v135 = call double @llvm.fma.f64(double %v112, double %v126, double %v134)
  store double %v135, ptr %v133, align 8
  %v136 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 1
  %v137 = load double, ptr %v136, align 8
  %v138 = call double @llvm.fma.f64(double %v112, double %v127, double %v137)
  store double %v138, ptr %v136, align 8
  %v139 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 2
  %v140 = load double, ptr %v139, align 8
  %v141 = call double @llvm.fma.f64(double %v112, double %v131, double %v140)
  store double %v141, ptr %v139, align 8
  %v142 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 3
  %v143 = load double, ptr %v142, align 8
  %v144 = call double @llvm.fma.f64(double %v112, double %v132, double %v143)
  store double %v144, ptr %v142, align 8
  %v145 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 4
  %v146 = load double, ptr %v145, align 8
  %v147 = call double @llvm.fma.f64(double %v113, double %v126, double %v146)
  store double %v147, ptr %v145, align 8
  %v148 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 5
  %v149 = load double, ptr %v148, align 8
  %v150 = call double @llvm.fma.f64(double %v113, double %v127, double %v149)
  store double %v150, ptr %v148, align 8
  %v151 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 6
  %v152 = load double, ptr %v151, align 8
  %v153 = call double @llvm.fma.f64(double %v113, double %v131, double %v152)
  store double %v153, ptr %v151, align 8
  %v154 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 7
  %v155 = load double, ptr %v154, align 8
  %v156 = call double @llvm.fma.f64(double %v113, double %v132, double %v155)
  store double %v156, ptr %v154, align 8
  %v157 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 8
  %v158 = load double, ptr %v157, align 8
  %v159 = call double @llvm.fma.f64(double %v117, double %v126, double %v158)
  store double %v159, ptr %v157, align 8
  %v160 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 9
  %v161 = load double, ptr %v160, align 8
  %v162 = call double @llvm.fma.f64(double %v117, double %v127, double %v161)
  store double %v162, ptr %v160, align 8
  %v163 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 10
  %v164 = load double, ptr %v163, align 8
  %v165 = call double @llvm.fma.f64(double %v117, double %v131, double %v164)
  store double %v165, ptr %v163, align 8
  %v166 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 11
  %v167 = load double, ptr %v166, align 8
  %v168 = call double @llvm.fma.f64(double %v117, double %v132, double %v167)
  store double %v168, ptr %v166, align 8
  %v169 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 12
  %v170 = load double, ptr %v169, align 8
  %v171 = call double @llvm.fma.f64(double %v118, double %v126, double %v170)
  store double %v171, ptr %v169, align 8
  %v172 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 13
  %v173 = load double, ptr %v172, align 8
  %v174 = call double @llvm.fma.f64(double %v118, double %v127, double %v173)
  store double %v174, ptr %v172, align 8
  %v175 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 14
  %v176 = load double, ptr %v175, align 8
  %v177 = call double @llvm.fma.f64(double %v118, double %v131, double %v176)
  store double %v177, ptr %v175, align 8
  %v178 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 15
  %v179 = load double, ptr %v178, align 8
  %v180 = call double @llvm.fma.f64(double %v118, double %v132, double %v179)
  store double %v180, ptr %v178, align 8
  %v104 = add i64 %v103, 1
  %v181 = icmp eq i64 %v104, 4
  br i1 %v181, label %ktl, label %kk, !llvm.loop !0
ktl:
  call void @llvm.nvvm.barrier0()
  %v77 = add i64 %v76, 4
  %v182 = icmp eq i64 %v77, 128
  br i1 %v182, label %done, label %kt
done:
  %v183 = add i64 %v9, %v63
  %v184 = add i64 %v183, 0
  %v185 = mul i64 %v184, 128
  %v186 = add i64 %v185, %v10
  %v187 = add i64 %v186, %v64
  %v188 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 0
  %v189 = load double, ptr %v188, align 8
  %v190 = insertelement <2 x double> poison, double %v189, i64 0
  %v191 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 1
  %v192 = load double, ptr %v191, align 8
  %v193 = insertelement <2 x double> %v190, double %v192, i64 1
  %v194 = add i64 %v187, 0
  %v195 = getelementptr inbounds double, ptr addrspace(1) %o, i64 %v194
  store <2 x double> %v193, ptr addrspace(1) %v195, align 16
  %v196 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 2
  %v197 = load double, ptr %v196, align 8
  %v198 = insertelement <2 x double> poison, double %v197, i64 0
  %v199 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 3
  %v200 = load double, ptr %v199, align 8
  %v201 = insertelement <2 x double> %v198, double %v200, i64 1
  %v202 = add i64 %v187, 2
  %v203 = getelementptr inbounds double, ptr addrspace(1) %o, i64 %v202
  store <2 x double> %v201, ptr addrspace(1) %v203, align 16
  %v204 = add i64 %v9, %v63
  %v205 = add i64 %v204, 1
  %v206 = mul i64 %v205, 128
  %v207 = add i64 %v206, %v10
  %v208 = add i64 %v207, %v64
  %v209 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 4
  %v210 = load double, ptr %v209, align 8
  %v211 = insertelement <2 x double> poison, double %v210, i64 0
  %v212 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 5
  %v213 = load double, ptr %v212, align 8
  %v214 = insertelement <2 x double> %v211, double %v213, i64 1
  %v215 = add i64 %v208, 0
  %v216 = getelementptr inbounds double, ptr addrspace(1) %o, i64 %v215
  store <2 x double> %v214, ptr addrspace(1) %v216, align 16
  %v217 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 6
  %v218 = load double, ptr %v217, align 8
  %v219 = insertelement <2 x double> poison, double %v218, i64 0
  %v220 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 7
  %v221 = load double, ptr %v220, align 8
  %v222 = insertelement <2 x double> %v219, double %v221, i64 1
  %v223 = add i64 %v208, 2
  %v224 = getelementptr inbounds double, ptr addrspace(1) %o, i64 %v223
  store <2 x double> %v222, ptr addrspace(1) %v224, align 16
  %v225 = add i64 %v9, %v63
  %v226 = add i64 %v225, 2
  %v227 = mul i64 %v226, 128
  %v228 = add i64 %v227, %v10
  %v229 = add i64 %v228, %v64
  %v230 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 8
  %v231 = load double, ptr %v230, align 8
  %v232 = insertelement <2 x double> poison, double %v231, i64 0
  %v233 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 9
  %v234 = load double, ptr %v233, align 8
  %v235 = insertelement <2 x double> %v232, double %v234, i64 1
  %v236 = add i64 %v229, 0
  %v237 = getelementptr inbounds double, ptr addrspace(1) %o, i64 %v236
  store <2 x double> %v235, ptr addrspace(1) %v237, align 16
  %v238 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 10
  %v239 = load double, ptr %v238, align 8
  %v240 = insertelement <2 x double> poison, double %v239, i64 0
  %v241 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 11
  %v242 = load double, ptr %v241, align 8
  %v243 = insertelement <2 x double> %v240, double %v242, i64 1
  %v244 = add i64 %v229, 2
  %v245 = getelementptr inbounds double, ptr addrspace(1) %o, i64 %v244
  store <2 x double> %v243, ptr addrspace(1) %v245, align 16
  %v246 = add i64 %v9, %v63
  %v247 = add i64 %v246, 3
  %v248 = mul i64 %v247, 128
  %v249 = add i64 %v248, %v10
  %v250 = add i64 %v249, %v64
  %v251 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 12
  %v252 = load double, ptr %v251, align 8
  %v253 = insertelement <2 x double> poison, double %v252, i64 0
  %v254 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 13
  %v255 = load double, ptr %v254, align 8
  %v256 = insertelement <2 x double> %v253, double %v255, i64 1
  %v257 = add i64 %v250, 0
  %v258 = getelementptr inbounds double, ptr addrspace(1) %o, i64 %v257
  store <2 x double> %v256, ptr addrspace(1) %v258, align 16
  %v259 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 14
  %v260 = load double, ptr %v259, align 8
  %v261 = insertelement <2 x double> poison, double %v260, i64 0
  %v262 = getelementptr inbounds [16 x double], ptr %v11, i64 0, i64 15
  %v263 = load double, ptr %v262, align 8
  %v264 = insertelement <2 x double> %v261, double %v263, i64 1
  %v265 = add i64 %v250, 2
  %v266 = getelementptr inbounds double, ptr addrspace(1) %o, i64 %v265
  store <2 x double> %v264, ptr addrspace(1) %v266, align 16
  ret void
}

define internal double @fn1(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca double
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  %o10 = alloca double
  %o11 = alloca { double, double }
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 7, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 13, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 101, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 50, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to double
  store double %t33, ptr %o10
  %t34 = load double, ptr %o10
  %t35 = getelementptr { double, double }, ptr %o11, i32 0, i32 0
  store double %t34, ptr %t35
  %t36 = getelementptr { double, double }, ptr %o11, i32 0, i32 1
  store double 0x401C000000000000, ptr %t36
  %t37 = getelementptr { double, double }, ptr %o11, i32 0, i32 0
  %t38 = load double, ptr %t37
  %t39 = getelementptr { double, double }, ptr %o11, i32 0, i32 1
  %t40 = load double, ptr %t39
  %t41 = fdiv double %t38, %t40
  store double %t41, ptr %o1
  %t42 = load double, ptr %o1
  ret double %t42
}

define ptx_kernel void @mapal_gen_34fc01898169adc9(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call double @fn1(i32 %x)
  %p = getelementptr inbounds double, ptr addrspace(1) %o, i64 %i
  store double %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

define internal double @fn2(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca double
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  %o10 = alloca double
  %o11 = alloca { double, double }
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 11, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 57, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 103, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 51, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to double
  store double %t33, ptr %o10
  %t34 = load double, ptr %o10
  %t35 = getelementptr { double, double }, ptr %o11, i32 0, i32 0
  store double %t34, ptr %t35
  %t36 = getelementptr { double, double }, ptr %o11, i32 0, i32 1
  store double 0x4022000000000000, ptr %t36
  %t37 = getelementptr { double, double }, ptr %o11, i32 0, i32 0
  %t38 = load double, ptr %t37
  %t39 = getelementptr { double, double }, ptr %o11, i32 0, i32 1
  %t40 = load double, ptr %t39
  %t41 = fdiv double %t38, %t40
  store double %t41, ptr %o1
  %t42 = load double, ptr %o1
  ret double %t42
}

define ptx_kernel void @mapal_gen_e1cb74ac3c460016(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call double @fn2(i32 %x)
  %p = getelementptr inbounds double, ptr addrspace(1) %o, i64 %i
  store double %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

!0 = distinct !{!0, !1}
!1 = !{!"llvm.loop.unroll.full"}
