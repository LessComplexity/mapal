; mapal-backend-llvm emitted module
declare void @mapal_print_i32(i32, i1 zeroext)
declare void @mapal_print_i64(i64, i1 zeroext)
declare void @mapal_print_u8(i8 zeroext, i1 zeroext)
declare void @mapal_print_bool(i1 zeroext, i1 zeroext)
declare void @mapal_print_f32(float, i1 zeroext)
declare void @mapal_print_f64(double, i1 zeroext)
declare void @mapal_print_str(ptr, i64, i1 zeroext)
declare double @mapal_time_ms()
declare void @mapal_trap(i32) noreturn
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @mapal_gpu_init(i32)
declare i64 @mapal_gpu_alloc(ptr, i64)
declare void @mapal_gpu_h2d(i64, ptr, i64)
declare void @mapal_gpu_d2h(ptr, i64, i64, i64)
declare void @mapal_gpu_launch(i64, i64, i64, i64, i32, i32, i32, i32)
declare void @mapal_gpu_gen(i64, i64, i64)
declare void @mapal_gpu_free(ptr)
declare i64 @mapal_gpu_arena(ptr, i64)

define internal void @mapal_main() {
entry:
  %darena = alloca i64
  store i64 0, ptr %darena
  %o8 = alloca { ptr, ptr, ptr, ptr }
  %o9 = alloca [16384 x double]
  %o10 = alloca { double, ptr }
  %o11 = alloca double
  %o12 = alloca double
  %o14 = alloca { ptr, i32 }
  %o15 = alloca double
  %o16 = alloca double
  %o18 = alloca { ptr, i32 }
  %o19 = alloca double
  %o20 = alloca double
  %d0 = alloca i64
  store i64 0, ptr %d0
  %d4 = alloca i64
  store i64 0, ptr %d4
  %d12 = alloca i64
  store i64 0, ptr %d12
  %s21 = alloca double
  %s22 = alloca i64
  %s31 = alloca { double, double }
  %t2 = call i64 @mapal_gpu_arena(ptr %darena, i64 393216)
  %t1 = add i64 %t2, 0
  store i64 %t1, ptr %d0
  call void @mapal_gpu_gen(i64 3817928274196671945, i64 %t1, i64 16384)
  %t3 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o8, i32 0, i32 1
  store ptr null, ptr %t3
  %t6 = call i64 @mapal_gpu_arena(ptr %darena, i64 393216)
  %t5 = add i64 %t6, 131072
  store i64 %t5, ptr %d4
  call void @mapal_gpu_gen(i64 -2176517711809085418, i64 %t5, i64 16384)
  %t7 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o8, i32 0, i32 2
  store ptr null, ptr %t7
  %t8 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o8, i32 0, i32 0
  store ptr null, ptr %t8
  %t9 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o8, i32 0, i32 3
  store ptr null, ptr %t9
  %t10 = load i64, ptr %d0
  %t11 = load i64, ptr %d4
  %t14 = call i64 @mapal_gpu_arena(ptr %darena, i64 393216)
  %t13 = add i64 %t14, 262144
  store i64 %t13, ptr %d12
  call void @mapal_gpu_launch(i64 7048973167950890679, i64 %t10, i64 %t11, i64 %t13, i32 4, i32 8, i32 32, i32 1536)
  call void @mapal_gpu_d2h(ptr %o9, i64 %t13, i64 0, i64 131072)
  %t15 = getelementptr { double, ptr }, ptr %o10, i32 0, i32 1
  store ptr %o9, ptr %t15
  %t16 = getelementptr { ptr, i32 }, ptr %o14, i32 0, i32 0
  store ptr %o9, ptr %t16
  %t17 = getelementptr { ptr, i32 }, ptr %o18, i32 0, i32 0
  store ptr %o9, ptr %t17
  %t18 = getelementptr { double, ptr }, ptr %o10, i32 0, i32 0
  store double 0x0000000000000000, ptr %t18
  %t19 = getelementptr { double, ptr }, ptr %o10, i32 0, i32 0
  %t20 = load double, ptr %t19
  store double %t20, ptr %s21
  store i64 0, ptr %s22
  br label %bb23
bb23:
  %t26 = load i64, ptr %s22
  %t27 = icmp uge i64 %t26, 16384
  br i1 %t27, label %bb25, label %bb24
bb24:
  %t28 = getelementptr [16384 x double], ptr %o9, i64 0, i64 %t26
  %t29 = load double, ptr %t28
  %t30 = load double, ptr %s21
  %t32 = getelementptr { double, double }, ptr %s31, i32 0, i32 0
  store double %t30, ptr %t32
  %t33 = getelementptr { double, double }, ptr %s31, i32 0, i32 1
  store double %t29, ptr %t33
  %t34 = load { double, double }, ptr %s31
  %t35 = call double @fn5({ double, double } %t34)
  store double %t35, ptr %s21
  %t36 = add i64 %t26, 1
  store i64 %t36, ptr %s22
  br label %bb23
bb25:
  %t37 = load double, ptr %s21
  store double %t37, ptr %o11
  %t38 = load double, ptr %o11
  store double %t38, ptr %o12
  %t39 = load double, ptr %o12
  call void @mapal_print_f64(double %t39, i1 zeroext true)
  %t40 = getelementptr { ptr, i32 }, ptr %o14, i32 0, i32 1
  store i32 0, ptr %t40
  %t41 = getelementptr { ptr, i32 }, ptr %o14, i32 0, i32 1
  %t42 = load i32, ptr %t41
  %t43 = sext i32 %t42 to i64
  %t44 = getelementptr [16384 x double], ptr %o9, i64 0, i64 %t43
  %t45 = load double, ptr %t44
  store double %t45, ptr %o15
  %t46 = load double, ptr %o15
  store double %t46, ptr %o16
  %t47 = load double, ptr %o16
  call void @mapal_print_f64(double %t47, i1 zeroext true)
  %t48 = getelementptr { ptr, i32 }, ptr %o18, i32 0, i32 1
  store i32 16383, ptr %t48
  %t49 = getelementptr { ptr, i32 }, ptr %o18, i32 0, i32 1
  %t50 = load i32, ptr %t49
  %t51 = sext i32 %t50 to i64
  %t52 = getelementptr [16384 x double], ptr %o9, i64 0, i64 %t51
  %t53 = load double, ptr %t52
  store double %t53, ptr %o19
  %t54 = load double, ptr %o19
  store double %t54, ptr %o20
  %t55 = load double, ptr %o20
  call void @mapal_print_f64(double %t55, i1 zeroext true)
  call void @mapal_gpu_free(ptr %darena)
  ret void
}

define internal double @fn1(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca double
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  %o10 = alloca double
  %o11 = alloca { double, double }
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 7, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 13, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 101, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 50, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to double
  store double %t33, ptr %o10
  %t34 = load double, ptr %o10
  %t35 = getelementptr { double, double }, ptr %o11, i32 0, i32 0
  store double %t34, ptr %t35
  %t36 = getelementptr { double, double }, ptr %o11, i32 0, i32 1
  store double 0x401C000000000000, ptr %t36
  %t37 = getelementptr { double, double }, ptr %o11, i32 0, i32 0
  %t38 = load double, ptr %t37
  %t39 = getelementptr { double, double }, ptr %o11, i32 0, i32 1
  %t40 = load double, ptr %t39
  %t41 = fdiv double %t38, %t40
  store double %t41, ptr %o1
  %t42 = load double, ptr %o1
  ret double %t42
}

define internal double @fn2(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca double
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  %o10 = alloca double
  %o11 = alloca { double, double }
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 11, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 57, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 103, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 51, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to double
  store double %t33, ptr %o10
  %t34 = load double, ptr %o10
  %t35 = getelementptr { double, double }, ptr %o11, i32 0, i32 0
  store double %t34, ptr %t35
  %t36 = getelementptr { double, double }, ptr %o11, i32 0, i32 1
  store double 0x4022000000000000, ptr %t36
  %t37 = getelementptr { double, double }, ptr %o11, i32 0, i32 0
  %t38 = load double, ptr %t37
  %t39 = getelementptr { double, double }, ptr %o11, i32 0, i32 1
  %t40 = load double, ptr %t39
  %t41 = fdiv double %t38, %t40
  store double %t41, ptr %o1
  %t42 = load double, ptr %o1
  ret double %t42
}

define internal double @fn3({ ptr, i32, ptr, i32, double, i32 } %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca { ptr, i32, ptr, i32, double, i32 }
  %o1 = alloca double
  %o2 = alloca ptr
  %o3 = alloca i32
  %o4 = alloca ptr
  %o5 = alloca i32
  %o6 = alloca double
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  %o10 = alloca { i32, i32 }
  %o11 = alloca i32
  %o12 = alloca { ptr, i32 }
  %o13 = alloca double
  %o14 = alloca { i32, i32 }
  %o15 = alloca i32
  %o16 = alloca { i32, i32 }
  %o17 = alloca i32
  %o18 = alloca { ptr, i32 }
  %o19 = alloca double
  %o20 = alloca { double, double }
  %o21 = alloca double
  %o22 = alloca { double, double }
  store { ptr, i32, ptr, i32, double, i32 } %arg, ptr %o0
  %t0 = getelementptr { ptr, i32, ptr, i32, double, i32 }, ptr %o0, i32 0, i32 0
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %o2
  %t2 = getelementptr { ptr, i32, ptr, i32, double, i32 }, ptr %o0, i32 0, i32 1
  %t3 = load i32, ptr %t2
  store i32 %t3, ptr %o3
  %t4 = getelementptr { ptr, i32, ptr, i32, double, i32 }, ptr %o0, i32 0, i32 2
  %t5 = load ptr, ptr %t4
  store ptr %t5, ptr %o4
  %t6 = getelementptr { ptr, i32, ptr, i32, double, i32 }, ptr %o0, i32 0, i32 3
  %t7 = load i32, ptr %t6
  store i32 %t7, ptr %o5
  %t8 = getelementptr { ptr, i32, ptr, i32, double, i32 }, ptr %o0, i32 0, i32 4
  %t9 = load double, ptr %t8
  store double %t9, ptr %o6
  %t10 = getelementptr { ptr, i32, ptr, i32, double, i32 }, ptr %o0, i32 0, i32 5
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %o7
  %t12 = load ptr, ptr %o2
  %t13 = getelementptr { ptr, i32 }, ptr %o12, i32 0, i32 0
  store ptr %t12, ptr %t13
  %t14 = load i32, ptr %o3
  %t15 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t14, ptr %t15
  %t16 = load ptr, ptr %o4
  %t17 = getelementptr { ptr, i32 }, ptr %o18, i32 0, i32 0
  store ptr %t16, ptr %t17
  %t18 = load i32, ptr %o5
  %t19 = getelementptr { i32, i32 }, ptr %o16, i32 0, i32 1
  store i32 %t18, ptr %t19
  %t20 = load double, ptr %o6
  %t21 = getelementptr { double, double }, ptr %o22, i32 0, i32 0
  store double %t20, ptr %t21
  %t22 = load i32, ptr %o7
  %t23 = getelementptr { i32, i32 }, ptr %o10, i32 0, i32 1
  store i32 %t22, ptr %t23
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o14, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 128, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = mul i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = getelementptr { i32, i32 }, ptr %o10, i32 0, i32 0
  store i32 %t32, ptr %t33
  %t34 = getelementptr { i32, i32 }, ptr %o10, i32 0, i32 0
  %t35 = load i32, ptr %t34
  %t36 = getelementptr { i32, i32 }, ptr %o10, i32 0, i32 1
  %t37 = load i32, ptr %t36
  %t38 = add i32 %t35, %t37
  store i32 %t38, ptr %o11
  %t39 = load i32, ptr %o11
  %t40 = getelementptr { ptr, i32 }, ptr %o12, i32 0, i32 1
  store i32 %t39, ptr %t40
  %t41 = load ptr, ptr %o2
  %t42 = getelementptr { ptr, i32 }, ptr %o12, i32 0, i32 1
  %t43 = load i32, ptr %t42
  %t44 = sext i32 %t43 to i64
  %t45 = getelementptr [16384 x double], ptr %t41, i64 0, i64 %t44
  %t46 = load double, ptr %t45
  store double %t46, ptr %o13
  %t47 = load double, ptr %o13
  %t48 = getelementptr { double, double }, ptr %o20, i32 0, i32 0
  store double %t47, ptr %t48
  %t49 = getelementptr { i32, i32 }, ptr %o14, i32 0, i32 1
  store i32 128, ptr %t49
  %t50 = getelementptr { i32, i32 }, ptr %o14, i32 0, i32 0
  %t51 = load i32, ptr %t50
  %t52 = getelementptr { i32, i32 }, ptr %o14, i32 0, i32 1
  %t53 = load i32, ptr %t52
  %t54 = mul i32 %t51, %t53
  store i32 %t54, ptr %o15
  %t55 = load i32, ptr %o15
  %t56 = getelementptr { i32, i32 }, ptr %o16, i32 0, i32 0
  store i32 %t55, ptr %t56
  %t57 = getelementptr { i32, i32 }, ptr %o16, i32 0, i32 0
  %t58 = load i32, ptr %t57
  %t59 = getelementptr { i32, i32 }, ptr %o16, i32 0, i32 1
  %t60 = load i32, ptr %t59
  %t61 = add i32 %t58, %t60
  store i32 %t61, ptr %o17
  %t62 = load i32, ptr %o17
  %t63 = getelementptr { ptr, i32 }, ptr %o18, i32 0, i32 1
  store i32 %t62, ptr %t63
  %t64 = load ptr, ptr %o4
  %t65 = getelementptr { ptr, i32 }, ptr %o18, i32 0, i32 1
  %t66 = load i32, ptr %t65
  %t67 = sext i32 %t66 to i64
  %t68 = getelementptr [16384 x double], ptr %t64, i64 0, i64 %t67
  %t69 = load double, ptr %t68
  store double %t69, ptr %o19
  %t70 = load double, ptr %o19
  %t71 = getelementptr { double, double }, ptr %o20, i32 0, i32 1
  store double %t70, ptr %t71
  %t72 = getelementptr { double, double }, ptr %o20, i32 0, i32 0
  %t73 = load double, ptr %t72
  %t74 = getelementptr { double, double }, ptr %o20, i32 0, i32 1
  %t75 = load double, ptr %t74
  %t76 = fmul double %t73, %t75
  store double %t76, ptr %o21
  %t77 = load double, ptr %o21
  %t78 = getelementptr { double, double }, ptr %o22, i32 0, i32 1
  store double %t77, ptr %t78
  %t79 = getelementptr { double, double }, ptr %o22, i32 0, i32 0
  %t80 = load double, ptr %t79
  %t81 = getelementptr { double, double }, ptr %o22, i32 0, i32 1
  %t82 = load double, ptr %t81
  %t83 = fadd double %t80, %t82
  store double %t83, ptr %o1
  %t84 = load double, ptr %o1
  ret double %t84
}

define internal double @fn4({ ptr, ptr, ptr, i32 } %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca { ptr, ptr, ptr, i32 }
  %o1 = alloca double
  %o2 = alloca ptr
  %o3 = alloca ptr
  %o4 = alloca ptr
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  %o10 = alloca { ptr, i32, ptr, i32, double, ptr }
  %s38 = alloca double
  %s39 = alloca i64
  %s48 = alloca { ptr, i32, ptr, i32, double, i32 }
  store { ptr, ptr, ptr, i32 } %arg, ptr %o0
  %t0 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 0
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %o2
  %t2 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 1
  %t3 = load ptr, ptr %t2
  store ptr %t3, ptr %o3
  %t4 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 2
  %t5 = load ptr, ptr %t4
  store ptr %t5, ptr %o4
  %t6 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 3
  %t7 = load i32, ptr %t6
  store i32 %t7, ptr %o5
  %t8 = load ptr, ptr %o2
  %t9 = getelementptr { ptr, i32, ptr, i32, double, ptr }, ptr %o10, i32 0, i32 5
  store ptr %t8, ptr %t9
  %t10 = load ptr, ptr %o3
  %t11 = getelementptr { ptr, i32, ptr, i32, double, ptr }, ptr %o10, i32 0, i32 0
  store ptr %t10, ptr %t11
  %t12 = load ptr, ptr %o4
  %t13 = getelementptr { ptr, i32, ptr, i32, double, ptr }, ptr %o10, i32 0, i32 2
  store ptr %t12, ptr %t13
  %t14 = load i32, ptr %o5
  %t15 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t14, ptr %t15
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 128, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = sdiv i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { ptr, i32, ptr, i32, double, ptr }, ptr %o10, i32 0, i32 1
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 128, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = srem i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = getelementptr { ptr, i32, ptr, i32, double, ptr }, ptr %o10, i32 0, i32 3
  store i32 %t32, ptr %t33
  %t34 = getelementptr { ptr, i32, ptr, i32, double, ptr }, ptr %o10, i32 0, i32 4
  store double 0x0000000000000000, ptr %t34
  %t35 = getelementptr { ptr, i32, ptr, i32, double, ptr }, ptr %o10, i32 0, i32 4
  %t36 = load double, ptr %t35
  %t37 = load ptr, ptr %o2
  store double %t36, ptr %s38
  store i64 0, ptr %s39
  br label %bb40
bb40:
  %t43 = load i64, ptr %s39
  %t44 = icmp uge i64 %t43, 128
  br i1 %t44, label %bb42, label %bb41
bb41:
  %t45 = getelementptr [128 x i32], ptr %t37, i64 0, i64 %t43
  %t46 = load i32, ptr %t45
  %t47 = load double, ptr %s38
  %t49 = load ptr, ptr %o3
  %t50 = getelementptr { ptr, i32, ptr, i32, double, i32 }, ptr %s48, i32 0, i32 0
  store ptr %t49, ptr %t50
  %t51 = getelementptr { ptr, i32, ptr, i32, double, ptr }, ptr %o10, i32 0, i32 1
  %t52 = load i32, ptr %t51
  %t53 = getelementptr { ptr, i32, ptr, i32, double, i32 }, ptr %s48, i32 0, i32 1
  store i32 %t52, ptr %t53
  %t54 = load ptr, ptr %o4
  %t55 = getelementptr { ptr, i32, ptr, i32, double, i32 }, ptr %s48, i32 0, i32 2
  store ptr %t54, ptr %t55
  %t56 = getelementptr { ptr, i32, ptr, i32, double, ptr }, ptr %o10, i32 0, i32 3
  %t57 = load i32, ptr %t56
  %t58 = getelementptr { ptr, i32, ptr, i32, double, i32 }, ptr %s48, i32 0, i32 3
  store i32 %t57, ptr %t58
  %t59 = getelementptr { ptr, i32, ptr, i32, double, i32 }, ptr %s48, i32 0, i32 4
  store double %t47, ptr %t59
  %t60 = getelementptr { ptr, i32, ptr, i32, double, i32 }, ptr %s48, i32 0, i32 5
  store i32 %t46, ptr %t60
  %t61 = load { ptr, i32, ptr, i32, double, i32 }, ptr %s48
  %t62 = call double @fn3({ ptr, i32, ptr, i32, double, i32 } %t61)
  store double %t62, ptr %s38
  %t63 = add i64 %t43, 1
  store i64 %t63, ptr %s39
  br label %bb40
bb42:
  %t64 = load double, ptr %s38
  store double %t64, ptr %o1
  %t65 = load double, ptr %o1
  ret double %t65
}

define internal double @fn5({ double, double } %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca { double, double }
  %o1 = alloca double
  %o2 = alloca double
  %o3 = alloca double
  %o4 = alloca { double, double }
  store { double, double } %arg, ptr %o0
  %t0 = getelementptr { double, double }, ptr %o0, i32 0, i32 0
  %t1 = load double, ptr %t0
  store double %t1, ptr %o2
  %t2 = getelementptr { double, double }, ptr %o0, i32 0, i32 1
  %t3 = load double, ptr %t2
  store double %t3, ptr %o3
  %t4 = load double, ptr %o2
  %t5 = getelementptr { double, double }, ptr %o4, i32 0, i32 0
  store double %t4, ptr %t5
  %t6 = load double, ptr %o3
  %t7 = getelementptr { double, double }, ptr %o4, i32 0, i32 1
  store double %t6, ptr %t7
  %t8 = getelementptr { double, double }, ptr %o4, i32 0, i32 0
  %t9 = load double, ptr %t8
  %t10 = getelementptr { double, double }, ptr %o4, i32 0, i32 1
  %t11 = load double, ptr %t10
  %t12 = fadd double %t9, %t11
  store double %t12, ptr %o1
  %t13 = load double, ptr %o1
  ret double %t13
}

define i32 @main() {
entry:
  call void @mapal_gpu_init(i32 1)
  call void @mapal_main()
  ret i32 0
}
