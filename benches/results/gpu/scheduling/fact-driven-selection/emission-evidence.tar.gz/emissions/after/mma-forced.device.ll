; mapal-backend-llvm device module
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@mapal_smem = external addrspace(3) global [0 x i8], align 16
declare i32 @llvm.nvvm.read.ptx.sreg.tid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
declare void @llvm.nvvm.barrier0()
declare void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.8(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.commit.group()
declare void @llvm.nvvm.cp.async.wait.group(i32 immarg)
declare float @llvm.fma.f32(float, float, float)
declare double @llvm.fma.f64(double, double, double)

define ptx_kernel void @mapal_tile_d0cfb9881535775e(ptr addrspace(1) noalias readonly align 16 %a, ptr addrspace(1) noalias readonly align 16 %b, ptr addrspace(1) noalias align 16 %o) "nvvm.maxntid"="128" "nvvm.minctasm"="2" {
entry:
  %v1 = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = zext i32 %v1 to i64
  %v3 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v4 = zext i32 %v3 to i64
  %v5 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v6 = zext i32 %v5 to i64
  %v7 = udiv i64 %v2, 32
  %v8 = urem i64 %v2, 32
  %v9 = udiv i64 %v7, 2
  %v10 = urem i64 %v7, 2
  %v11 = udiv i64 %v8, 4
  %v12 = urem i64 %v8, 4
  %v13 = mul i64 %v6, 64
  %v14 = mul i64 %v4, 64
  %v15 = alloca [32 x float], align 16
  %v16 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 0
  store float 0x0000000000000000, ptr %v16, align 4
  %v17 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 1
  store float 0x0000000000000000, ptr %v17, align 4
  %v18 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 2
  store float 0x0000000000000000, ptr %v18, align 4
  %v19 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 3
  store float 0x0000000000000000, ptr %v19, align 4
  %v20 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 4
  store float 0x0000000000000000, ptr %v20, align 4
  %v21 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 5
  store float 0x0000000000000000, ptr %v21, align 4
  %v22 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 6
  store float 0x0000000000000000, ptr %v22, align 4
  %v23 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 7
  store float 0x0000000000000000, ptr %v23, align 4
  %v24 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 8
  store float 0x0000000000000000, ptr %v24, align 4
  %v25 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 9
  store float 0x0000000000000000, ptr %v25, align 4
  %v26 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 10
  store float 0x0000000000000000, ptr %v26, align 4
  %v27 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 11
  store float 0x0000000000000000, ptr %v27, align 4
  %v28 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 12
  store float 0x0000000000000000, ptr %v28, align 4
  %v29 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 13
  store float 0x0000000000000000, ptr %v29, align 4
  %v30 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 14
  store float 0x0000000000000000, ptr %v30, align 4
  %v31 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 15
  store float 0x0000000000000000, ptr %v31, align 4
  %v32 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 16
  store float 0x0000000000000000, ptr %v32, align 4
  %v33 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 17
  store float 0x0000000000000000, ptr %v33, align 4
  %v34 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 18
  store float 0x0000000000000000, ptr %v34, align 4
  %v35 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 19
  store float 0x0000000000000000, ptr %v35, align 4
  %v36 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 20
  store float 0x0000000000000000, ptr %v36, align 4
  %v37 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 21
  store float 0x0000000000000000, ptr %v37, align 4
  %v38 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 22
  store float 0x0000000000000000, ptr %v38, align 4
  %v39 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 23
  store float 0x0000000000000000, ptr %v39, align 4
  %v40 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 24
  store float 0x0000000000000000, ptr %v40, align 4
  %v41 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 25
  store float 0x0000000000000000, ptr %v41, align 4
  %v42 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 26
  store float 0x0000000000000000, ptr %v42, align 4
  %v43 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 27
  store float 0x0000000000000000, ptr %v43, align 4
  %v44 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 28
  store float 0x0000000000000000, ptr %v44, align 4
  %v45 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 29
  store float 0x0000000000000000, ptr %v45, align 4
  %v46 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 30
  store float 0x0000000000000000, ptr %v46, align 4
  %v47 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 31
  store float 0x0000000000000000, ptr %v47, align 4
  %v48 = add i64 %v2, 0
  %v49 = udiv i64 %v48, 8
  %v50 = urem i64 %v48, 8
  %v51 = mul i64 %v50, 4
  %v52 = add i64 %v13, %v49
  %v53 = mul i64 %v52, 1024
  %v54 = add i64 %v53, %v51
  %v55 = add i64 %v54, 0
  %v56 = mul i64 %v49, 36
  %v57 = add i64 %v56, %v51
  %v58 = add i64 %v2, 128
  %v59 = udiv i64 %v58, 8
  %v60 = urem i64 %v58, 8
  %v61 = mul i64 %v60, 4
  %v62 = add i64 %v13, %v59
  %v63 = mul i64 %v62, 1024
  %v64 = add i64 %v63, %v61
  %v65 = add i64 %v64, 0
  %v66 = mul i64 %v59, 36
  %v67 = add i64 %v66, %v61
  %v68 = add i64 %v2, 256
  %v69 = udiv i64 %v68, 8
  %v70 = urem i64 %v68, 8
  %v71 = mul i64 %v70, 4
  %v72 = add i64 %v13, %v69
  %v73 = mul i64 %v72, 1024
  %v74 = add i64 %v73, %v71
  %v75 = add i64 %v74, 0
  %v76 = mul i64 %v69, 36
  %v77 = add i64 %v76, %v71
  %v78 = add i64 %v2, 384
  %v79 = udiv i64 %v78, 8
  %v80 = urem i64 %v78, 8
  %v81 = mul i64 %v80, 4
  %v82 = add i64 %v13, %v79
  %v83 = mul i64 %v82, 1024
  %v84 = add i64 %v83, %v81
  %v85 = add i64 %v84, 0
  %v86 = mul i64 %v79, 36
  %v87 = add i64 %v86, %v81
  %v88 = add i64 %v2, 0
  %v89 = udiv i64 %v88, 16
  %v90 = urem i64 %v88, 16
  %v91 = mul i64 %v90, 4
  %v92 = mul i64 %v89, 1024
  %v93 = add i64 %v14, %v91
  %v94 = add i64 %v92, %v93
  %v95 = add i64 %v94, 0
  %v96 = mul i64 %v89, 72
  %v97 = add i64 %v96, %v91
  %v98 = add i64 %v97, 2304
  %v99 = add i64 %v2, 128
  %v100 = udiv i64 %v99, 16
  %v101 = urem i64 %v99, 16
  %v102 = mul i64 %v101, 4
  %v103 = mul i64 %v100, 1024
  %v104 = add i64 %v14, %v102
  %v105 = add i64 %v103, %v104
  %v106 = add i64 %v105, 0
  %v107 = mul i64 %v100, 72
  %v108 = add i64 %v107, %v102
  %v109 = add i64 %v108, 2304
  %v110 = add i64 %v2, 256
  %v111 = udiv i64 %v110, 16
  %v112 = urem i64 %v110, 16
  %v113 = mul i64 %v112, 4
  %v114 = mul i64 %v111, 1024
  %v115 = add i64 %v14, %v113
  %v116 = add i64 %v114, %v115
  %v117 = add i64 %v116, 0
  %v118 = mul i64 %v111, 72
  %v119 = add i64 %v118, %v113
  %v120 = add i64 %v119, 2304
  %v121 = add i64 %v2, 384
  %v122 = udiv i64 %v121, 16
  %v123 = urem i64 %v121, 16
  %v124 = mul i64 %v123, 4
  %v125 = mul i64 %v122, 1024
  %v126 = add i64 %v14, %v124
  %v127 = add i64 %v125, %v126
  %v128 = add i64 %v127, 0
  %v129 = mul i64 %v122, 72
  %v130 = add i64 %v129, %v124
  %v131 = add i64 %v130, 2304
  %v132 = mul i64 0, 32
  %v133 = mul i64 %v132, 1
  %v134 = mul i64 %v132, 1024
  %v135 = mul i64 0, 4608
  %v136 = add i64 %v55, %v133
  %v137 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v136
  %v138 = add i64 %v57, %v135
  %v139 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v138
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v139, ptr addrspace(1) %v137)
  %v140 = add i64 %v65, %v133
  %v141 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v140
  %v142 = add i64 %v67, %v135
  %v143 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v142
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v143, ptr addrspace(1) %v141)
  %v144 = add i64 %v75, %v133
  %v145 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v144
  %v146 = add i64 %v77, %v135
  %v147 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v146
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v147, ptr addrspace(1) %v145)
  %v148 = add i64 %v85, %v133
  %v149 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v148
  %v150 = add i64 %v87, %v135
  %v151 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v150
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v151, ptr addrspace(1) %v149)
  %v152 = add i64 %v95, %v134
  %v153 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v152
  %v154 = add i64 %v98, %v135
  %v155 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v154
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v155, ptr addrspace(1) %v153)
  %v156 = add i64 %v106, %v134
  %v157 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v156
  %v158 = add i64 %v109, %v135
  %v159 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v158
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v159, ptr addrspace(1) %v157)
  %v160 = add i64 %v117, %v134
  %v161 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v160
  %v162 = add i64 %v120, %v135
  %v163 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v162
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v163, ptr addrspace(1) %v161)
  %v164 = add i64 %v128, %v134
  %v165 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v164
  %v166 = add i64 %v131, %v135
  %v167 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v166
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v167, ptr addrspace(1) %v165)
  call void @llvm.nvvm.cp.async.commit.group()
  %v168 = mul i64 %v9, 32
  %v169 = add i64 %v168, %v11
  %v170 = mul i64 %v169, 36
  %v171 = add i64 %v170, %v12
  %v172 = mul i64 %v12, 72
  %v173 = mul i64 %v10, 32
  %v174 = add i64 %v172, %v173
  %v175 = add i64 %v174, %v11
  %v176 = add i64 %v175, 2304
  br label %kt
kt:
  %v177 = phi i64 [0, %entry], [%v178, %issued]
  call void @llvm.nvvm.cp.async.wait.group(i32 0)
  call void @llvm.nvvm.barrier0()
  %v179 = add i64 %v177, 1
  %v180 = icmp ult i64 %v179, 32
  br i1 %v180, label %issue, label %issued
issue:
  %v181 = urem i64 %v179, 2
  %v182 = mul i64 %v179, 32
  %v183 = mul i64 %v182, 1
  %v184 = mul i64 %v182, 1024
  %v185 = mul i64 %v181, 4608
  %v186 = add i64 %v55, %v183
  %v187 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v186
  %v188 = add i64 %v57, %v185
  %v189 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v188
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v189, ptr addrspace(1) %v187)
  %v190 = add i64 %v65, %v183
  %v191 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v190
  %v192 = add i64 %v67, %v185
  %v193 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v192
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v193, ptr addrspace(1) %v191)
  %v194 = add i64 %v75, %v183
  %v195 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v194
  %v196 = add i64 %v77, %v185
  %v197 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v196
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v197, ptr addrspace(1) %v195)
  %v198 = add i64 %v85, %v183
  %v199 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v198
  %v200 = add i64 %v87, %v185
  %v201 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v200
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v201, ptr addrspace(1) %v199)
  %v202 = add i64 %v95, %v184
  %v203 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v202
  %v204 = add i64 %v98, %v185
  %v205 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v204
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v205, ptr addrspace(1) %v203)
  %v206 = add i64 %v106, %v184
  %v207 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v206
  %v208 = add i64 %v109, %v185
  %v209 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v208
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v209, ptr addrspace(1) %v207)
  %v210 = add i64 %v117, %v184
  %v211 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v210
  %v212 = add i64 %v120, %v185
  %v213 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v212
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v213, ptr addrspace(1) %v211)
  %v214 = add i64 %v128, %v184
  %v215 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v214
  %v216 = add i64 %v131, %v185
  %v217 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v216
  call void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3) %v217, ptr addrspace(1) %v215)
  br label %issued
issued:
  call void @llvm.nvvm.cp.async.commit.group()
  %v218 = urem i64 %v177, 2
  %v219 = mul i64 %v218, 4608
  %v220 = add i64 %v219, %v171
  %v221 = add i64 %v219, %v176
  %v222 = udiv i64 %v8, 8
  %v223 = urem i64 %v8, 8
  %v224 = urem i64 %v222, 2
  %v225 = udiv i64 %v222, 2
  %v226 = mul i64 %v224, 8
  %v227 = add i64 %v226, %v223
  %v228 = mul i64 %v9, 32
  %v229 = add i64 %v227, %v228
  %v230 = mul i64 %v229, 36
  %v231 = mul i64 %v225, 4
  %v232 = add i64 %v230, %v231
  %v233 = add i64 %v219, %v232
  %v234 = add i64 %v233, 0
  %v235 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v234
  %v236 = ptrtoint ptr addrspace(3) %v235 to i32
  %v237 = call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v236)
  %v238 = extractvalue { i32, i32, i32, i32 } %v237, 0
  %v239 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v238)
  %v240 = extractvalue { i32, i32, i32, i32 } %v237, 1
  %v241 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v240)
  %v242 = extractvalue { i32, i32, i32, i32 } %v237, 2
  %v243 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v242)
  %v244 = extractvalue { i32, i32, i32, i32 } %v237, 3
  %v245 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v244)
  %v246 = add i64 %v233, 576
  %v247 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v246
  %v248 = ptrtoint ptr addrspace(3) %v247 to i32
  %v249 = call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v248)
  %v250 = extractvalue { i32, i32, i32, i32 } %v249, 0
  %v251 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v250)
  %v252 = extractvalue { i32, i32, i32, i32 } %v249, 1
  %v253 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v252)
  %v254 = extractvalue { i32, i32, i32, i32 } %v249, 2
  %v255 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v254)
  %v256 = extractvalue { i32, i32, i32, i32 } %v249, 3
  %v257 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v256)
  %v258 = add i64 %v221, 0
  %v259 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v258
  %v260 = load float, ptr addrspace(3) %v259, align 4
  %v261 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v260)
  %v262 = add i64 %v221, 288
  %v263 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v262
  %v264 = load float, ptr addrspace(3) %v263, align 4
  %v265 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v264)
  %v266 = add i64 %v221, 8
  %v267 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v266
  %v268 = load float, ptr addrspace(3) %v267, align 4
  %v269 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v268)
  %v270 = add i64 %v221, 296
  %v271 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v270
  %v272 = load float, ptr addrspace(3) %v271, align 4
  %v273 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v272)
  %v274 = add i64 %v221, 16
  %v275 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v274
  %v276 = load float, ptr addrspace(3) %v275, align 4
  %v277 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v276)
  %v278 = add i64 %v221, 304
  %v279 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v278
  %v280 = load float, ptr addrspace(3) %v279, align 4
  %v281 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v280)
  %v282 = add i64 %v221, 24
  %v283 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v282
  %v284 = load float, ptr addrspace(3) %v283, align 4
  %v285 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v284)
  %v286 = add i64 %v221, 312
  %v287 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v286
  %v288 = load float, ptr addrspace(3) %v287, align 4
  %v289 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v288)
  %v290 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 0
  %v291 = load float, ptr %v290, align 4
  %v292 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 1
  %v293 = load float, ptr %v292, align 4
  %v294 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 2
  %v295 = load float, ptr %v294, align 4
  %v296 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 3
  %v297 = load float, ptr %v296, align 4
  %v298 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v239, i32 %v241, i32 %v243, i32 %v245, i32 %v261, i32 %v265, float %v291, float %v293, float %v295, float %v297)
  %v299 = extractvalue { float, float, float, float } %v298, 0
  store float %v299, ptr %v290, align 4
  %v300 = extractvalue { float, float, float, float } %v298, 1
  store float %v300, ptr %v292, align 4
  %v301 = extractvalue { float, float, float, float } %v298, 2
  store float %v301, ptr %v294, align 4
  %v302 = extractvalue { float, float, float, float } %v298, 3
  store float %v302, ptr %v296, align 4
  %v303 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 4
  %v304 = load float, ptr %v303, align 4
  %v305 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 5
  %v306 = load float, ptr %v305, align 4
  %v307 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 6
  %v308 = load float, ptr %v307, align 4
  %v309 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 7
  %v310 = load float, ptr %v309, align 4
  %v311 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v239, i32 %v241, i32 %v243, i32 %v245, i32 %v269, i32 %v273, float %v304, float %v306, float %v308, float %v310)
  %v312 = extractvalue { float, float, float, float } %v311, 0
  store float %v312, ptr %v303, align 4
  %v313 = extractvalue { float, float, float, float } %v311, 1
  store float %v313, ptr %v305, align 4
  %v314 = extractvalue { float, float, float, float } %v311, 2
  store float %v314, ptr %v307, align 4
  %v315 = extractvalue { float, float, float, float } %v311, 3
  store float %v315, ptr %v309, align 4
  %v316 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 8
  %v317 = load float, ptr %v316, align 4
  %v318 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 9
  %v319 = load float, ptr %v318, align 4
  %v320 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 10
  %v321 = load float, ptr %v320, align 4
  %v322 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 11
  %v323 = load float, ptr %v322, align 4
  %v324 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v239, i32 %v241, i32 %v243, i32 %v245, i32 %v277, i32 %v281, float %v317, float %v319, float %v321, float %v323)
  %v325 = extractvalue { float, float, float, float } %v324, 0
  store float %v325, ptr %v316, align 4
  %v326 = extractvalue { float, float, float, float } %v324, 1
  store float %v326, ptr %v318, align 4
  %v327 = extractvalue { float, float, float, float } %v324, 2
  store float %v327, ptr %v320, align 4
  %v328 = extractvalue { float, float, float, float } %v324, 3
  store float %v328, ptr %v322, align 4
  %v329 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 12
  %v330 = load float, ptr %v329, align 4
  %v331 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 13
  %v332 = load float, ptr %v331, align 4
  %v333 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 14
  %v334 = load float, ptr %v333, align 4
  %v335 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 15
  %v336 = load float, ptr %v335, align 4
  %v337 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v239, i32 %v241, i32 %v243, i32 %v245, i32 %v285, i32 %v289, float %v330, float %v332, float %v334, float %v336)
  %v338 = extractvalue { float, float, float, float } %v337, 0
  store float %v338, ptr %v329, align 4
  %v339 = extractvalue { float, float, float, float } %v337, 1
  store float %v339, ptr %v331, align 4
  %v340 = extractvalue { float, float, float, float } %v337, 2
  store float %v340, ptr %v333, align 4
  %v341 = extractvalue { float, float, float, float } %v337, 3
  store float %v341, ptr %v335, align 4
  %v342 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 16
  %v343 = load float, ptr %v342, align 4
  %v344 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 17
  %v345 = load float, ptr %v344, align 4
  %v346 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 18
  %v347 = load float, ptr %v346, align 4
  %v348 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 19
  %v349 = load float, ptr %v348, align 4
  %v350 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v251, i32 %v253, i32 %v255, i32 %v257, i32 %v261, i32 %v265, float %v343, float %v345, float %v347, float %v349)
  %v351 = extractvalue { float, float, float, float } %v350, 0
  store float %v351, ptr %v342, align 4
  %v352 = extractvalue { float, float, float, float } %v350, 1
  store float %v352, ptr %v344, align 4
  %v353 = extractvalue { float, float, float, float } %v350, 2
  store float %v353, ptr %v346, align 4
  %v354 = extractvalue { float, float, float, float } %v350, 3
  store float %v354, ptr %v348, align 4
  %v355 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 20
  %v356 = load float, ptr %v355, align 4
  %v357 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 21
  %v358 = load float, ptr %v357, align 4
  %v359 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 22
  %v360 = load float, ptr %v359, align 4
  %v361 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 23
  %v362 = load float, ptr %v361, align 4
  %v363 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v251, i32 %v253, i32 %v255, i32 %v257, i32 %v269, i32 %v273, float %v356, float %v358, float %v360, float %v362)
  %v364 = extractvalue { float, float, float, float } %v363, 0
  store float %v364, ptr %v355, align 4
  %v365 = extractvalue { float, float, float, float } %v363, 1
  store float %v365, ptr %v357, align 4
  %v366 = extractvalue { float, float, float, float } %v363, 2
  store float %v366, ptr %v359, align 4
  %v367 = extractvalue { float, float, float, float } %v363, 3
  store float %v367, ptr %v361, align 4
  %v368 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 24
  %v369 = load float, ptr %v368, align 4
  %v370 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 25
  %v371 = load float, ptr %v370, align 4
  %v372 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 26
  %v373 = load float, ptr %v372, align 4
  %v374 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 27
  %v375 = load float, ptr %v374, align 4
  %v376 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v251, i32 %v253, i32 %v255, i32 %v257, i32 %v277, i32 %v281, float %v369, float %v371, float %v373, float %v375)
  %v377 = extractvalue { float, float, float, float } %v376, 0
  store float %v377, ptr %v368, align 4
  %v378 = extractvalue { float, float, float, float } %v376, 1
  store float %v378, ptr %v370, align 4
  %v379 = extractvalue { float, float, float, float } %v376, 2
  store float %v379, ptr %v372, align 4
  %v380 = extractvalue { float, float, float, float } %v376, 3
  store float %v380, ptr %v374, align 4
  %v381 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 28
  %v382 = load float, ptr %v381, align 4
  %v383 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 29
  %v384 = load float, ptr %v383, align 4
  %v385 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 30
  %v386 = load float, ptr %v385, align 4
  %v387 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 31
  %v388 = load float, ptr %v387, align 4
  %v389 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v251, i32 %v253, i32 %v255, i32 %v257, i32 %v285, i32 %v289, float %v382, float %v384, float %v386, float %v388)
  %v390 = extractvalue { float, float, float, float } %v389, 0
  store float %v390, ptr %v381, align 4
  %v391 = extractvalue { float, float, float, float } %v389, 1
  store float %v391, ptr %v383, align 4
  %v392 = extractvalue { float, float, float, float } %v389, 2
  store float %v392, ptr %v385, align 4
  %v393 = extractvalue { float, float, float, float } %v389, 3
  store float %v393, ptr %v387, align 4
  %v394 = add i64 %v233, 8
  %v395 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v394
  %v396 = ptrtoint ptr addrspace(3) %v395 to i32
  %v397 = call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v396)
  %v398 = extractvalue { i32, i32, i32, i32 } %v397, 0
  %v399 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v398)
  %v400 = extractvalue { i32, i32, i32, i32 } %v397, 1
  %v401 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v400)
  %v402 = extractvalue { i32, i32, i32, i32 } %v397, 2
  %v403 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v402)
  %v404 = extractvalue { i32, i32, i32, i32 } %v397, 3
  %v405 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v404)
  %v406 = add i64 %v233, 584
  %v407 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v406
  %v408 = ptrtoint ptr addrspace(3) %v407 to i32
  %v409 = call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v408)
  %v410 = extractvalue { i32, i32, i32, i32 } %v409, 0
  %v411 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v410)
  %v412 = extractvalue { i32, i32, i32, i32 } %v409, 1
  %v413 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v412)
  %v414 = extractvalue { i32, i32, i32, i32 } %v409, 2
  %v415 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v414)
  %v416 = extractvalue { i32, i32, i32, i32 } %v409, 3
  %v417 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v416)
  %v418 = add i64 %v221, 576
  %v419 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v418
  %v420 = load float, ptr addrspace(3) %v419, align 4
  %v421 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v420)
  %v422 = add i64 %v221, 864
  %v423 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v422
  %v424 = load float, ptr addrspace(3) %v423, align 4
  %v425 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v424)
  %v426 = add i64 %v221, 584
  %v427 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v426
  %v428 = load float, ptr addrspace(3) %v427, align 4
  %v429 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v428)
  %v430 = add i64 %v221, 872
  %v431 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v430
  %v432 = load float, ptr addrspace(3) %v431, align 4
  %v433 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v432)
  %v434 = add i64 %v221, 592
  %v435 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v434
  %v436 = load float, ptr addrspace(3) %v435, align 4
  %v437 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v436)
  %v438 = add i64 %v221, 880
  %v439 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v438
  %v440 = load float, ptr addrspace(3) %v439, align 4
  %v441 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v440)
  %v442 = add i64 %v221, 600
  %v443 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v442
  %v444 = load float, ptr addrspace(3) %v443, align 4
  %v445 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v444)
  %v446 = add i64 %v221, 888
  %v447 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v446
  %v448 = load float, ptr addrspace(3) %v447, align 4
  %v449 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v448)
  %v450 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 0
  %v451 = load float, ptr %v450, align 4
  %v452 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 1
  %v453 = load float, ptr %v452, align 4
  %v454 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 2
  %v455 = load float, ptr %v454, align 4
  %v456 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 3
  %v457 = load float, ptr %v456, align 4
  %v458 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v399, i32 %v401, i32 %v403, i32 %v405, i32 %v421, i32 %v425, float %v451, float %v453, float %v455, float %v457)
  %v459 = extractvalue { float, float, float, float } %v458, 0
  store float %v459, ptr %v450, align 4
  %v460 = extractvalue { float, float, float, float } %v458, 1
  store float %v460, ptr %v452, align 4
  %v461 = extractvalue { float, float, float, float } %v458, 2
  store float %v461, ptr %v454, align 4
  %v462 = extractvalue { float, float, float, float } %v458, 3
  store float %v462, ptr %v456, align 4
  %v463 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 4
  %v464 = load float, ptr %v463, align 4
  %v465 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 5
  %v466 = load float, ptr %v465, align 4
  %v467 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 6
  %v468 = load float, ptr %v467, align 4
  %v469 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 7
  %v470 = load float, ptr %v469, align 4
  %v471 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v399, i32 %v401, i32 %v403, i32 %v405, i32 %v429, i32 %v433, float %v464, float %v466, float %v468, float %v470)
  %v472 = extractvalue { float, float, float, float } %v471, 0
  store float %v472, ptr %v463, align 4
  %v473 = extractvalue { float, float, float, float } %v471, 1
  store float %v473, ptr %v465, align 4
  %v474 = extractvalue { float, float, float, float } %v471, 2
  store float %v474, ptr %v467, align 4
  %v475 = extractvalue { float, float, float, float } %v471, 3
  store float %v475, ptr %v469, align 4
  %v476 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 8
  %v477 = load float, ptr %v476, align 4
  %v478 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 9
  %v479 = load float, ptr %v478, align 4
  %v480 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 10
  %v481 = load float, ptr %v480, align 4
  %v482 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 11
  %v483 = load float, ptr %v482, align 4
  %v484 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v399, i32 %v401, i32 %v403, i32 %v405, i32 %v437, i32 %v441, float %v477, float %v479, float %v481, float %v483)
  %v485 = extractvalue { float, float, float, float } %v484, 0
  store float %v485, ptr %v476, align 4
  %v486 = extractvalue { float, float, float, float } %v484, 1
  store float %v486, ptr %v478, align 4
  %v487 = extractvalue { float, float, float, float } %v484, 2
  store float %v487, ptr %v480, align 4
  %v488 = extractvalue { float, float, float, float } %v484, 3
  store float %v488, ptr %v482, align 4
  %v489 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 12
  %v490 = load float, ptr %v489, align 4
  %v491 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 13
  %v492 = load float, ptr %v491, align 4
  %v493 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 14
  %v494 = load float, ptr %v493, align 4
  %v495 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 15
  %v496 = load float, ptr %v495, align 4
  %v497 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v399, i32 %v401, i32 %v403, i32 %v405, i32 %v445, i32 %v449, float %v490, float %v492, float %v494, float %v496)
  %v498 = extractvalue { float, float, float, float } %v497, 0
  store float %v498, ptr %v489, align 4
  %v499 = extractvalue { float, float, float, float } %v497, 1
  store float %v499, ptr %v491, align 4
  %v500 = extractvalue { float, float, float, float } %v497, 2
  store float %v500, ptr %v493, align 4
  %v501 = extractvalue { float, float, float, float } %v497, 3
  store float %v501, ptr %v495, align 4
  %v502 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 16
  %v503 = load float, ptr %v502, align 4
  %v504 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 17
  %v505 = load float, ptr %v504, align 4
  %v506 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 18
  %v507 = load float, ptr %v506, align 4
  %v508 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 19
  %v509 = load float, ptr %v508, align 4
  %v510 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v411, i32 %v413, i32 %v415, i32 %v417, i32 %v421, i32 %v425, float %v503, float %v505, float %v507, float %v509)
  %v511 = extractvalue { float, float, float, float } %v510, 0
  store float %v511, ptr %v502, align 4
  %v512 = extractvalue { float, float, float, float } %v510, 1
  store float %v512, ptr %v504, align 4
  %v513 = extractvalue { float, float, float, float } %v510, 2
  store float %v513, ptr %v506, align 4
  %v514 = extractvalue { float, float, float, float } %v510, 3
  store float %v514, ptr %v508, align 4
  %v515 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 20
  %v516 = load float, ptr %v515, align 4
  %v517 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 21
  %v518 = load float, ptr %v517, align 4
  %v519 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 22
  %v520 = load float, ptr %v519, align 4
  %v521 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 23
  %v522 = load float, ptr %v521, align 4
  %v523 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v411, i32 %v413, i32 %v415, i32 %v417, i32 %v429, i32 %v433, float %v516, float %v518, float %v520, float %v522)
  %v524 = extractvalue { float, float, float, float } %v523, 0
  store float %v524, ptr %v515, align 4
  %v525 = extractvalue { float, float, float, float } %v523, 1
  store float %v525, ptr %v517, align 4
  %v526 = extractvalue { float, float, float, float } %v523, 2
  store float %v526, ptr %v519, align 4
  %v527 = extractvalue { float, float, float, float } %v523, 3
  store float %v527, ptr %v521, align 4
  %v528 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 24
  %v529 = load float, ptr %v528, align 4
  %v530 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 25
  %v531 = load float, ptr %v530, align 4
  %v532 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 26
  %v533 = load float, ptr %v532, align 4
  %v534 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 27
  %v535 = load float, ptr %v534, align 4
  %v536 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v411, i32 %v413, i32 %v415, i32 %v417, i32 %v437, i32 %v441, float %v529, float %v531, float %v533, float %v535)
  %v537 = extractvalue { float, float, float, float } %v536, 0
  store float %v537, ptr %v528, align 4
  %v538 = extractvalue { float, float, float, float } %v536, 1
  store float %v538, ptr %v530, align 4
  %v539 = extractvalue { float, float, float, float } %v536, 2
  store float %v539, ptr %v532, align 4
  %v540 = extractvalue { float, float, float, float } %v536, 3
  store float %v540, ptr %v534, align 4
  %v541 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 28
  %v542 = load float, ptr %v541, align 4
  %v543 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 29
  %v544 = load float, ptr %v543, align 4
  %v545 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 30
  %v546 = load float, ptr %v545, align 4
  %v547 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 31
  %v548 = load float, ptr %v547, align 4
  %v549 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v411, i32 %v413, i32 %v415, i32 %v417, i32 %v445, i32 %v449, float %v542, float %v544, float %v546, float %v548)
  %v550 = extractvalue { float, float, float, float } %v549, 0
  store float %v550, ptr %v541, align 4
  %v551 = extractvalue { float, float, float, float } %v549, 1
  store float %v551, ptr %v543, align 4
  %v552 = extractvalue { float, float, float, float } %v549, 2
  store float %v552, ptr %v545, align 4
  %v553 = extractvalue { float, float, float, float } %v549, 3
  store float %v553, ptr %v547, align 4
  %v554 = add i64 %v233, 16
  %v555 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v554
  %v556 = ptrtoint ptr addrspace(3) %v555 to i32
  %v557 = call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v556)
  %v558 = extractvalue { i32, i32, i32, i32 } %v557, 0
  %v559 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v558)
  %v560 = extractvalue { i32, i32, i32, i32 } %v557, 1
  %v561 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v560)
  %v562 = extractvalue { i32, i32, i32, i32 } %v557, 2
  %v563 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v562)
  %v564 = extractvalue { i32, i32, i32, i32 } %v557, 3
  %v565 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v564)
  %v566 = add i64 %v233, 592
  %v567 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v566
  %v568 = ptrtoint ptr addrspace(3) %v567 to i32
  %v569 = call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v568)
  %v570 = extractvalue { i32, i32, i32, i32 } %v569, 0
  %v571 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v570)
  %v572 = extractvalue { i32, i32, i32, i32 } %v569, 1
  %v573 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v572)
  %v574 = extractvalue { i32, i32, i32, i32 } %v569, 2
  %v575 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v574)
  %v576 = extractvalue { i32, i32, i32, i32 } %v569, 3
  %v577 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v576)
  %v578 = add i64 %v221, 1152
  %v579 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v578
  %v580 = load float, ptr addrspace(3) %v579, align 4
  %v581 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v580)
  %v582 = add i64 %v221, 1440
  %v583 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v582
  %v584 = load float, ptr addrspace(3) %v583, align 4
  %v585 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v584)
  %v586 = add i64 %v221, 1160
  %v587 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v586
  %v588 = load float, ptr addrspace(3) %v587, align 4
  %v589 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v588)
  %v590 = add i64 %v221, 1448
  %v591 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v590
  %v592 = load float, ptr addrspace(3) %v591, align 4
  %v593 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v592)
  %v594 = add i64 %v221, 1168
  %v595 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v594
  %v596 = load float, ptr addrspace(3) %v595, align 4
  %v597 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v596)
  %v598 = add i64 %v221, 1456
  %v599 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v598
  %v600 = load float, ptr addrspace(3) %v599, align 4
  %v601 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v600)
  %v602 = add i64 %v221, 1176
  %v603 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v602
  %v604 = load float, ptr addrspace(3) %v603, align 4
  %v605 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v604)
  %v606 = add i64 %v221, 1464
  %v607 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v606
  %v608 = load float, ptr addrspace(3) %v607, align 4
  %v609 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v608)
  %v610 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 0
  %v611 = load float, ptr %v610, align 4
  %v612 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 1
  %v613 = load float, ptr %v612, align 4
  %v614 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 2
  %v615 = load float, ptr %v614, align 4
  %v616 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 3
  %v617 = load float, ptr %v616, align 4
  %v618 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v559, i32 %v561, i32 %v563, i32 %v565, i32 %v581, i32 %v585, float %v611, float %v613, float %v615, float %v617)
  %v619 = extractvalue { float, float, float, float } %v618, 0
  store float %v619, ptr %v610, align 4
  %v620 = extractvalue { float, float, float, float } %v618, 1
  store float %v620, ptr %v612, align 4
  %v621 = extractvalue { float, float, float, float } %v618, 2
  store float %v621, ptr %v614, align 4
  %v622 = extractvalue { float, float, float, float } %v618, 3
  store float %v622, ptr %v616, align 4
  %v623 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 4
  %v624 = load float, ptr %v623, align 4
  %v625 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 5
  %v626 = load float, ptr %v625, align 4
  %v627 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 6
  %v628 = load float, ptr %v627, align 4
  %v629 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 7
  %v630 = load float, ptr %v629, align 4
  %v631 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v559, i32 %v561, i32 %v563, i32 %v565, i32 %v589, i32 %v593, float %v624, float %v626, float %v628, float %v630)
  %v632 = extractvalue { float, float, float, float } %v631, 0
  store float %v632, ptr %v623, align 4
  %v633 = extractvalue { float, float, float, float } %v631, 1
  store float %v633, ptr %v625, align 4
  %v634 = extractvalue { float, float, float, float } %v631, 2
  store float %v634, ptr %v627, align 4
  %v635 = extractvalue { float, float, float, float } %v631, 3
  store float %v635, ptr %v629, align 4
  %v636 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 8
  %v637 = load float, ptr %v636, align 4
  %v638 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 9
  %v639 = load float, ptr %v638, align 4
  %v640 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 10
  %v641 = load float, ptr %v640, align 4
  %v642 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 11
  %v643 = load float, ptr %v642, align 4
  %v644 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v559, i32 %v561, i32 %v563, i32 %v565, i32 %v597, i32 %v601, float %v637, float %v639, float %v641, float %v643)
  %v645 = extractvalue { float, float, float, float } %v644, 0
  store float %v645, ptr %v636, align 4
  %v646 = extractvalue { float, float, float, float } %v644, 1
  store float %v646, ptr %v638, align 4
  %v647 = extractvalue { float, float, float, float } %v644, 2
  store float %v647, ptr %v640, align 4
  %v648 = extractvalue { float, float, float, float } %v644, 3
  store float %v648, ptr %v642, align 4
  %v649 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 12
  %v650 = load float, ptr %v649, align 4
  %v651 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 13
  %v652 = load float, ptr %v651, align 4
  %v653 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 14
  %v654 = load float, ptr %v653, align 4
  %v655 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 15
  %v656 = load float, ptr %v655, align 4
  %v657 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v559, i32 %v561, i32 %v563, i32 %v565, i32 %v605, i32 %v609, float %v650, float %v652, float %v654, float %v656)
  %v658 = extractvalue { float, float, float, float } %v657, 0
  store float %v658, ptr %v649, align 4
  %v659 = extractvalue { float, float, float, float } %v657, 1
  store float %v659, ptr %v651, align 4
  %v660 = extractvalue { float, float, float, float } %v657, 2
  store float %v660, ptr %v653, align 4
  %v661 = extractvalue { float, float, float, float } %v657, 3
  store float %v661, ptr %v655, align 4
  %v662 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 16
  %v663 = load float, ptr %v662, align 4
  %v664 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 17
  %v665 = load float, ptr %v664, align 4
  %v666 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 18
  %v667 = load float, ptr %v666, align 4
  %v668 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 19
  %v669 = load float, ptr %v668, align 4
  %v670 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v571, i32 %v573, i32 %v575, i32 %v577, i32 %v581, i32 %v585, float %v663, float %v665, float %v667, float %v669)
  %v671 = extractvalue { float, float, float, float } %v670, 0
  store float %v671, ptr %v662, align 4
  %v672 = extractvalue { float, float, float, float } %v670, 1
  store float %v672, ptr %v664, align 4
  %v673 = extractvalue { float, float, float, float } %v670, 2
  store float %v673, ptr %v666, align 4
  %v674 = extractvalue { float, float, float, float } %v670, 3
  store float %v674, ptr %v668, align 4
  %v675 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 20
  %v676 = load float, ptr %v675, align 4
  %v677 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 21
  %v678 = load float, ptr %v677, align 4
  %v679 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 22
  %v680 = load float, ptr %v679, align 4
  %v681 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 23
  %v682 = load float, ptr %v681, align 4
  %v683 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v571, i32 %v573, i32 %v575, i32 %v577, i32 %v589, i32 %v593, float %v676, float %v678, float %v680, float %v682)
  %v684 = extractvalue { float, float, float, float } %v683, 0
  store float %v684, ptr %v675, align 4
  %v685 = extractvalue { float, float, float, float } %v683, 1
  store float %v685, ptr %v677, align 4
  %v686 = extractvalue { float, float, float, float } %v683, 2
  store float %v686, ptr %v679, align 4
  %v687 = extractvalue { float, float, float, float } %v683, 3
  store float %v687, ptr %v681, align 4
  %v688 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 24
  %v689 = load float, ptr %v688, align 4
  %v690 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 25
  %v691 = load float, ptr %v690, align 4
  %v692 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 26
  %v693 = load float, ptr %v692, align 4
  %v694 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 27
  %v695 = load float, ptr %v694, align 4
  %v696 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v571, i32 %v573, i32 %v575, i32 %v577, i32 %v597, i32 %v601, float %v689, float %v691, float %v693, float %v695)
  %v697 = extractvalue { float, float, float, float } %v696, 0
  store float %v697, ptr %v688, align 4
  %v698 = extractvalue { float, float, float, float } %v696, 1
  store float %v698, ptr %v690, align 4
  %v699 = extractvalue { float, float, float, float } %v696, 2
  store float %v699, ptr %v692, align 4
  %v700 = extractvalue { float, float, float, float } %v696, 3
  store float %v700, ptr %v694, align 4
  %v701 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 28
  %v702 = load float, ptr %v701, align 4
  %v703 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 29
  %v704 = load float, ptr %v703, align 4
  %v705 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 30
  %v706 = load float, ptr %v705, align 4
  %v707 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 31
  %v708 = load float, ptr %v707, align 4
  %v709 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v571, i32 %v573, i32 %v575, i32 %v577, i32 %v605, i32 %v609, float %v702, float %v704, float %v706, float %v708)
  %v710 = extractvalue { float, float, float, float } %v709, 0
  store float %v710, ptr %v701, align 4
  %v711 = extractvalue { float, float, float, float } %v709, 1
  store float %v711, ptr %v703, align 4
  %v712 = extractvalue { float, float, float, float } %v709, 2
  store float %v712, ptr %v705, align 4
  %v713 = extractvalue { float, float, float, float } %v709, 3
  store float %v713, ptr %v707, align 4
  %v714 = add i64 %v233, 24
  %v715 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v714
  %v716 = ptrtoint ptr addrspace(3) %v715 to i32
  %v717 = call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v716)
  %v718 = extractvalue { i32, i32, i32, i32 } %v717, 0
  %v719 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v718)
  %v720 = extractvalue { i32, i32, i32, i32 } %v717, 1
  %v721 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v720)
  %v722 = extractvalue { i32, i32, i32, i32 } %v717, 2
  %v723 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v722)
  %v724 = extractvalue { i32, i32, i32, i32 } %v717, 3
  %v725 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v724)
  %v726 = add i64 %v233, 600
  %v727 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v726
  %v728 = ptrtoint ptr addrspace(3) %v727 to i32
  %v729 = call { i32, i32, i32, i32 } asm sideeffect "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0,$1,$2,$3}, [$4];", "=r,=r,=r,=r,r"(i32 %v728)
  %v730 = extractvalue { i32, i32, i32, i32 } %v729, 0
  %v731 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v730)
  %v732 = extractvalue { i32, i32, i32, i32 } %v729, 1
  %v733 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v732)
  %v734 = extractvalue { i32, i32, i32, i32 } %v729, 2
  %v735 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v734)
  %v736 = extractvalue { i32, i32, i32, i32 } %v729, 3
  %v737 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,r"(i32 %v736)
  %v738 = add i64 %v221, 1728
  %v739 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v738
  %v740 = load float, ptr addrspace(3) %v739, align 4
  %v741 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v740)
  %v742 = add i64 %v221, 2016
  %v743 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v742
  %v744 = load float, ptr addrspace(3) %v743, align 4
  %v745 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v744)
  %v746 = add i64 %v221, 1736
  %v747 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v746
  %v748 = load float, ptr addrspace(3) %v747, align 4
  %v749 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v748)
  %v750 = add i64 %v221, 2024
  %v751 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v750
  %v752 = load float, ptr addrspace(3) %v751, align 4
  %v753 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v752)
  %v754 = add i64 %v221, 1744
  %v755 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v754
  %v756 = load float, ptr addrspace(3) %v755, align 4
  %v757 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v756)
  %v758 = add i64 %v221, 2032
  %v759 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v758
  %v760 = load float, ptr addrspace(3) %v759, align 4
  %v761 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v760)
  %v762 = add i64 %v221, 1752
  %v763 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v762
  %v764 = load float, ptr addrspace(3) %v763, align 4
  %v765 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v764)
  %v766 = add i64 %v221, 2040
  %v767 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v766
  %v768 = load float, ptr addrspace(3) %v767, align 4
  %v769 = call i32 asm "cvt.rna.tf32.f32 $0, $1;", "=r,f"(float %v768)
  %v770 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 0
  %v771 = load float, ptr %v770, align 4
  %v772 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 1
  %v773 = load float, ptr %v772, align 4
  %v774 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 2
  %v775 = load float, ptr %v774, align 4
  %v776 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 3
  %v777 = load float, ptr %v776, align 4
  %v778 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v719, i32 %v721, i32 %v723, i32 %v725, i32 %v741, i32 %v745, float %v771, float %v773, float %v775, float %v777)
  %v779 = extractvalue { float, float, float, float } %v778, 0
  store float %v779, ptr %v770, align 4
  %v780 = extractvalue { float, float, float, float } %v778, 1
  store float %v780, ptr %v772, align 4
  %v781 = extractvalue { float, float, float, float } %v778, 2
  store float %v781, ptr %v774, align 4
  %v782 = extractvalue { float, float, float, float } %v778, 3
  store float %v782, ptr %v776, align 4
  %v783 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 4
  %v784 = load float, ptr %v783, align 4
  %v785 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 5
  %v786 = load float, ptr %v785, align 4
  %v787 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 6
  %v788 = load float, ptr %v787, align 4
  %v789 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 7
  %v790 = load float, ptr %v789, align 4
  %v791 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v719, i32 %v721, i32 %v723, i32 %v725, i32 %v749, i32 %v753, float %v784, float %v786, float %v788, float %v790)
  %v792 = extractvalue { float, float, float, float } %v791, 0
  store float %v792, ptr %v783, align 4
  %v793 = extractvalue { float, float, float, float } %v791, 1
  store float %v793, ptr %v785, align 4
  %v794 = extractvalue { float, float, float, float } %v791, 2
  store float %v794, ptr %v787, align 4
  %v795 = extractvalue { float, float, float, float } %v791, 3
  store float %v795, ptr %v789, align 4
  %v796 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 8
  %v797 = load float, ptr %v796, align 4
  %v798 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 9
  %v799 = load float, ptr %v798, align 4
  %v800 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 10
  %v801 = load float, ptr %v800, align 4
  %v802 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 11
  %v803 = load float, ptr %v802, align 4
  %v804 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v719, i32 %v721, i32 %v723, i32 %v725, i32 %v757, i32 %v761, float %v797, float %v799, float %v801, float %v803)
  %v805 = extractvalue { float, float, float, float } %v804, 0
  store float %v805, ptr %v796, align 4
  %v806 = extractvalue { float, float, float, float } %v804, 1
  store float %v806, ptr %v798, align 4
  %v807 = extractvalue { float, float, float, float } %v804, 2
  store float %v807, ptr %v800, align 4
  %v808 = extractvalue { float, float, float, float } %v804, 3
  store float %v808, ptr %v802, align 4
  %v809 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 12
  %v810 = load float, ptr %v809, align 4
  %v811 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 13
  %v812 = load float, ptr %v811, align 4
  %v813 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 14
  %v814 = load float, ptr %v813, align 4
  %v815 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 15
  %v816 = load float, ptr %v815, align 4
  %v817 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v719, i32 %v721, i32 %v723, i32 %v725, i32 %v765, i32 %v769, float %v810, float %v812, float %v814, float %v816)
  %v818 = extractvalue { float, float, float, float } %v817, 0
  store float %v818, ptr %v809, align 4
  %v819 = extractvalue { float, float, float, float } %v817, 1
  store float %v819, ptr %v811, align 4
  %v820 = extractvalue { float, float, float, float } %v817, 2
  store float %v820, ptr %v813, align 4
  %v821 = extractvalue { float, float, float, float } %v817, 3
  store float %v821, ptr %v815, align 4
  %v822 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 16
  %v823 = load float, ptr %v822, align 4
  %v824 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 17
  %v825 = load float, ptr %v824, align 4
  %v826 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 18
  %v827 = load float, ptr %v826, align 4
  %v828 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 19
  %v829 = load float, ptr %v828, align 4
  %v830 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v731, i32 %v733, i32 %v735, i32 %v737, i32 %v741, i32 %v745, float %v823, float %v825, float %v827, float %v829)
  %v831 = extractvalue { float, float, float, float } %v830, 0
  store float %v831, ptr %v822, align 4
  %v832 = extractvalue { float, float, float, float } %v830, 1
  store float %v832, ptr %v824, align 4
  %v833 = extractvalue { float, float, float, float } %v830, 2
  store float %v833, ptr %v826, align 4
  %v834 = extractvalue { float, float, float, float } %v830, 3
  store float %v834, ptr %v828, align 4
  %v835 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 20
  %v836 = load float, ptr %v835, align 4
  %v837 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 21
  %v838 = load float, ptr %v837, align 4
  %v839 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 22
  %v840 = load float, ptr %v839, align 4
  %v841 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 23
  %v842 = load float, ptr %v841, align 4
  %v843 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v731, i32 %v733, i32 %v735, i32 %v737, i32 %v749, i32 %v753, float %v836, float %v838, float %v840, float %v842)
  %v844 = extractvalue { float, float, float, float } %v843, 0
  store float %v844, ptr %v835, align 4
  %v845 = extractvalue { float, float, float, float } %v843, 1
  store float %v845, ptr %v837, align 4
  %v846 = extractvalue { float, float, float, float } %v843, 2
  store float %v846, ptr %v839, align 4
  %v847 = extractvalue { float, float, float, float } %v843, 3
  store float %v847, ptr %v841, align 4
  %v848 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 24
  %v849 = load float, ptr %v848, align 4
  %v850 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 25
  %v851 = load float, ptr %v850, align 4
  %v852 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 26
  %v853 = load float, ptr %v852, align 4
  %v854 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 27
  %v855 = load float, ptr %v854, align 4
  %v856 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v731, i32 %v733, i32 %v735, i32 %v737, i32 %v757, i32 %v761, float %v849, float %v851, float %v853, float %v855)
  %v857 = extractvalue { float, float, float, float } %v856, 0
  store float %v857, ptr %v848, align 4
  %v858 = extractvalue { float, float, float, float } %v856, 1
  store float %v858, ptr %v850, align 4
  %v859 = extractvalue { float, float, float, float } %v856, 2
  store float %v859, ptr %v852, align 4
  %v860 = extractvalue { float, float, float, float } %v856, 3
  store float %v860, ptr %v854, align 4
  %v861 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 28
  %v862 = load float, ptr %v861, align 4
  %v863 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 29
  %v864 = load float, ptr %v863, align 4
  %v865 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 30
  %v866 = load float, ptr %v865, align 4
  %v867 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 31
  %v868 = load float, ptr %v867, align 4
  %v869 = call { float, float, float, float } asm "mma.sync.aligned.m16n8k8.row.col.f32.tf32.tf32.f32 {$0,$1,$2,$3}, {$4,$5,$6,$7}, {$8,$9}, {$10,$11,$12,$13};", "=f,=f,=f,=f,r,r,r,r,r,r,0,1,2,3"(i32 %v731, i32 %v733, i32 %v735, i32 %v737, i32 %v765, i32 %v769, float %v862, float %v864, float %v866, float %v868)
  %v870 = extractvalue { float, float, float, float } %v869, 0
  store float %v870, ptr %v861, align 4
  %v871 = extractvalue { float, float, float, float } %v869, 1
  store float %v871, ptr %v863, align 4
  %v872 = extractvalue { float, float, float, float } %v869, 2
  store float %v872, ptr %v865, align 4
  %v873 = extractvalue { float, float, float, float } %v869, 3
  store float %v873, ptr %v867, align 4
  %v178 = add i64 %v177, 1
  %v874 = icmp eq i64 %v178, 32
  br i1 %v874, label %done, label %kt
done:
  %v875 = mul i64 %v9, 32
  %v876 = add i64 %v875, %v13
  %v877 = add i64 %v876, %v11
  %v878 = mul i64 %v10, 32
  %v879 = add i64 %v878, %v14
  %v880 = mul i64 %v12, 2
  %v881 = add i64 %v879, %v880
  %v882 = add i64 %v877, 0
  %v883 = mul i64 %v882, 1024
  %v884 = add i64 %v883, %v881
  %v885 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 0
  %v886 = load float, ptr %v885, align 4
  %v887 = insertelement <2 x float> poison, float %v886, i64 0
  %v888 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 1
  %v889 = load float, ptr %v888, align 4
  %v890 = insertelement <2 x float> %v887, float %v889, i64 1
  %v891 = add i64 %v884, 0
  %v892 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v891
  store <2 x float> %v890, ptr addrspace(1) %v892, align 8
  %v893 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 4
  %v894 = load float, ptr %v893, align 4
  %v895 = insertelement <2 x float> poison, float %v894, i64 0
  %v896 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 5
  %v897 = load float, ptr %v896, align 4
  %v898 = insertelement <2 x float> %v895, float %v897, i64 1
  %v899 = add i64 %v884, 8
  %v900 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v899
  store <2 x float> %v898, ptr addrspace(1) %v900, align 8
  %v901 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 8
  %v902 = load float, ptr %v901, align 4
  %v903 = insertelement <2 x float> poison, float %v902, i64 0
  %v904 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 9
  %v905 = load float, ptr %v904, align 4
  %v906 = insertelement <2 x float> %v903, float %v905, i64 1
  %v907 = add i64 %v884, 16
  %v908 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v907
  store <2 x float> %v906, ptr addrspace(1) %v908, align 8
  %v909 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 12
  %v910 = load float, ptr %v909, align 4
  %v911 = insertelement <2 x float> poison, float %v910, i64 0
  %v912 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 13
  %v913 = load float, ptr %v912, align 4
  %v914 = insertelement <2 x float> %v911, float %v913, i64 1
  %v915 = add i64 %v884, 24
  %v916 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v915
  store <2 x float> %v914, ptr addrspace(1) %v916, align 8
  %v917 = add i64 %v877, 8
  %v918 = mul i64 %v917, 1024
  %v919 = add i64 %v918, %v881
  %v920 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 2
  %v921 = load float, ptr %v920, align 4
  %v922 = insertelement <2 x float> poison, float %v921, i64 0
  %v923 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 3
  %v924 = load float, ptr %v923, align 4
  %v925 = insertelement <2 x float> %v922, float %v924, i64 1
  %v926 = add i64 %v919, 0
  %v927 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v926
  store <2 x float> %v925, ptr addrspace(1) %v927, align 8
  %v928 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 6
  %v929 = load float, ptr %v928, align 4
  %v930 = insertelement <2 x float> poison, float %v929, i64 0
  %v931 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 7
  %v932 = load float, ptr %v931, align 4
  %v933 = insertelement <2 x float> %v930, float %v932, i64 1
  %v934 = add i64 %v919, 8
  %v935 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v934
  store <2 x float> %v933, ptr addrspace(1) %v935, align 8
  %v936 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 10
  %v937 = load float, ptr %v936, align 4
  %v938 = insertelement <2 x float> poison, float %v937, i64 0
  %v939 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 11
  %v940 = load float, ptr %v939, align 4
  %v941 = insertelement <2 x float> %v938, float %v940, i64 1
  %v942 = add i64 %v919, 16
  %v943 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v942
  store <2 x float> %v941, ptr addrspace(1) %v943, align 8
  %v944 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 14
  %v945 = load float, ptr %v944, align 4
  %v946 = insertelement <2 x float> poison, float %v945, i64 0
  %v947 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 15
  %v948 = load float, ptr %v947, align 4
  %v949 = insertelement <2 x float> %v946, float %v948, i64 1
  %v950 = add i64 %v919, 24
  %v951 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v950
  store <2 x float> %v949, ptr addrspace(1) %v951, align 8
  %v952 = add i64 %v877, 16
  %v953 = mul i64 %v952, 1024
  %v954 = add i64 %v953, %v881
  %v955 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 16
  %v956 = load float, ptr %v955, align 4
  %v957 = insertelement <2 x float> poison, float %v956, i64 0
  %v958 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 17
  %v959 = load float, ptr %v958, align 4
  %v960 = insertelement <2 x float> %v957, float %v959, i64 1
  %v961 = add i64 %v954, 0
  %v962 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v961
  store <2 x float> %v960, ptr addrspace(1) %v962, align 8
  %v963 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 20
  %v964 = load float, ptr %v963, align 4
  %v965 = insertelement <2 x float> poison, float %v964, i64 0
  %v966 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 21
  %v967 = load float, ptr %v966, align 4
  %v968 = insertelement <2 x float> %v965, float %v967, i64 1
  %v969 = add i64 %v954, 8
  %v970 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v969
  store <2 x float> %v968, ptr addrspace(1) %v970, align 8
  %v971 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 24
  %v972 = load float, ptr %v971, align 4
  %v973 = insertelement <2 x float> poison, float %v972, i64 0
  %v974 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 25
  %v975 = load float, ptr %v974, align 4
  %v976 = insertelement <2 x float> %v973, float %v975, i64 1
  %v977 = add i64 %v954, 16
  %v978 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v977
  store <2 x float> %v976, ptr addrspace(1) %v978, align 8
  %v979 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 28
  %v980 = load float, ptr %v979, align 4
  %v981 = insertelement <2 x float> poison, float %v980, i64 0
  %v982 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 29
  %v983 = load float, ptr %v982, align 4
  %v984 = insertelement <2 x float> %v981, float %v983, i64 1
  %v985 = add i64 %v954, 24
  %v986 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v985
  store <2 x float> %v984, ptr addrspace(1) %v986, align 8
  %v987 = add i64 %v877, 24
  %v988 = mul i64 %v987, 1024
  %v989 = add i64 %v988, %v881
  %v990 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 18
  %v991 = load float, ptr %v990, align 4
  %v992 = insertelement <2 x float> poison, float %v991, i64 0
  %v993 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 19
  %v994 = load float, ptr %v993, align 4
  %v995 = insertelement <2 x float> %v992, float %v994, i64 1
  %v996 = add i64 %v989, 0
  %v997 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v996
  store <2 x float> %v995, ptr addrspace(1) %v997, align 8
  %v998 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 22
  %v999 = load float, ptr %v998, align 4
  %v1000 = insertelement <2 x float> poison, float %v999, i64 0
  %v1001 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 23
  %v1002 = load float, ptr %v1001, align 4
  %v1003 = insertelement <2 x float> %v1000, float %v1002, i64 1
  %v1004 = add i64 %v989, 8
  %v1005 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v1004
  store <2 x float> %v1003, ptr addrspace(1) %v1005, align 8
  %v1006 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 26
  %v1007 = load float, ptr %v1006, align 4
  %v1008 = insertelement <2 x float> poison, float %v1007, i64 0
  %v1009 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 27
  %v1010 = load float, ptr %v1009, align 4
  %v1011 = insertelement <2 x float> %v1008, float %v1010, i64 1
  %v1012 = add i64 %v989, 16
  %v1013 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v1012
  store <2 x float> %v1011, ptr addrspace(1) %v1013, align 8
  %v1014 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 30
  %v1015 = load float, ptr %v1014, align 4
  %v1016 = insertelement <2 x float> poison, float %v1015, i64 0
  %v1017 = getelementptr inbounds [32 x float], ptr %v15, i64 0, i64 31
  %v1018 = load float, ptr %v1017, align 4
  %v1019 = insertelement <2 x float> %v1016, float %v1018, i64 1
  %v1020 = add i64 %v989, 24
  %v1021 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v1020
  store <2 x float> %v1019, ptr addrspace(1) %v1021, align 8
  ret void
}

define internal float @fn1(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 7, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 13, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 101, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 50, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to float
  store float %t33, ptr %o1
  %t34 = load float, ptr %o1
  ret float %t34
}

define ptx_kernel void @mapal_gen_7a2ade86c804ef09(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call float @fn1(i32 %x)
  %p = getelementptr inbounds float, ptr addrspace(1) %o, i64 %i
  store float %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

define internal float @fn2(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 7, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 57, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 101, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 50, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to float
  store float %t33, ptr %o1
  %t34 = load float, ptr %o1
  ret float %t34
}

define ptx_kernel void @mapal_gen_1aeae5b5ba14d87e(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call float @fn2(i32 %x)
  %p = getelementptr inbounds float, ptr addrspace(1) %o, i64 %i
  store float %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

