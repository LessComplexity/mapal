; mapal-backend-llvm device module
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@mapal_smem = external addrspace(3) global [0 x i8], align 16
declare i32 @llvm.nvvm.read.ptx.sreg.tid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
declare void @llvm.nvvm.barrier0()
declare void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.8(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.commit.group()
declare void @llvm.nvvm.cp.async.wait.group(i32 immarg)
declare float @llvm.fma.f32(float, float, float)
declare double @llvm.fma.f64(double, double, double)

define ptx_kernel void @mapal_tile_5dccd94ababd20c9(ptr addrspace(1) noalias readonly align 16 %a, ptr addrspace(1) noalias readonly align 16 %b, ptr addrspace(1) noalias align 16 %o) "nvvm.maxntid"="32" "nvvm.minctasm"="16" {
entry:
  %v1 = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = zext i32 %v1 to i64
  %v3 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v4 = zext i32 %v3 to i64
  %v5 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
  %v6 = zext i32 %v5 to i64
  %v7 = udiv i64 %v2, 4
  %v8 = urem i64 %v2, 4
  %v9 = mul i64 %v6, 64
  %v10 = mul i64 %v4, 32
  %v11 = alloca [64 x float], align 16
  %v12 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 0
  store float 0x0000000000000000, ptr %v12, align 4
  %v13 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 1
  store float 0x0000000000000000, ptr %v13, align 4
  %v14 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 2
  store float 0x0000000000000000, ptr %v14, align 4
  %v15 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 3
  store float 0x0000000000000000, ptr %v15, align 4
  %v16 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 4
  store float 0x0000000000000000, ptr %v16, align 4
  %v17 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 5
  store float 0x0000000000000000, ptr %v17, align 4
  %v18 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 6
  store float 0x0000000000000000, ptr %v18, align 4
  %v19 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 7
  store float 0x0000000000000000, ptr %v19, align 4
  %v20 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 8
  store float 0x0000000000000000, ptr %v20, align 4
  %v21 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 9
  store float 0x0000000000000000, ptr %v21, align 4
  %v22 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 10
  store float 0x0000000000000000, ptr %v22, align 4
  %v23 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 11
  store float 0x0000000000000000, ptr %v23, align 4
  %v24 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 12
  store float 0x0000000000000000, ptr %v24, align 4
  %v25 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 13
  store float 0x0000000000000000, ptr %v25, align 4
  %v26 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 14
  store float 0x0000000000000000, ptr %v26, align 4
  %v27 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 15
  store float 0x0000000000000000, ptr %v27, align 4
  %v28 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 16
  store float 0x0000000000000000, ptr %v28, align 4
  %v29 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 17
  store float 0x0000000000000000, ptr %v29, align 4
  %v30 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 18
  store float 0x0000000000000000, ptr %v30, align 4
  %v31 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 19
  store float 0x0000000000000000, ptr %v31, align 4
  %v32 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 20
  store float 0x0000000000000000, ptr %v32, align 4
  %v33 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 21
  store float 0x0000000000000000, ptr %v33, align 4
  %v34 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 22
  store float 0x0000000000000000, ptr %v34, align 4
  %v35 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 23
  store float 0x0000000000000000, ptr %v35, align 4
  %v36 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 24
  store float 0x0000000000000000, ptr %v36, align 4
  %v37 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 25
  store float 0x0000000000000000, ptr %v37, align 4
  %v38 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 26
  store float 0x0000000000000000, ptr %v38, align 4
  %v39 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 27
  store float 0x0000000000000000, ptr %v39, align 4
  %v40 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 28
  store float 0x0000000000000000, ptr %v40, align 4
  %v41 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 29
  store float 0x0000000000000000, ptr %v41, align 4
  %v42 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 30
  store float 0x0000000000000000, ptr %v42, align 4
  %v43 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 31
  store float 0x0000000000000000, ptr %v43, align 4
  %v44 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 32
  store float 0x0000000000000000, ptr %v44, align 4
  %v45 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 33
  store float 0x0000000000000000, ptr %v45, align 4
  %v46 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 34
  store float 0x0000000000000000, ptr %v46, align 4
  %v47 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 35
  store float 0x0000000000000000, ptr %v47, align 4
  %v48 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 36
  store float 0x0000000000000000, ptr %v48, align 4
  %v49 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 37
  store float 0x0000000000000000, ptr %v49, align 4
  %v50 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 38
  store float 0x0000000000000000, ptr %v50, align 4
  %v51 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 39
  store float 0x0000000000000000, ptr %v51, align 4
  %v52 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 40
  store float 0x0000000000000000, ptr %v52, align 4
  %v53 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 41
  store float 0x0000000000000000, ptr %v53, align 4
  %v54 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 42
  store float 0x0000000000000000, ptr %v54, align 4
  %v55 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 43
  store float 0x0000000000000000, ptr %v55, align 4
  %v56 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 44
  store float 0x0000000000000000, ptr %v56, align 4
  %v57 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 45
  store float 0x0000000000000000, ptr %v57, align 4
  %v58 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 46
  store float 0x0000000000000000, ptr %v58, align 4
  %v59 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 47
  store float 0x0000000000000000, ptr %v59, align 4
  %v60 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 48
  store float 0x0000000000000000, ptr %v60, align 4
  %v61 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 49
  store float 0x0000000000000000, ptr %v61, align 4
  %v62 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 50
  store float 0x0000000000000000, ptr %v62, align 4
  %v63 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 51
  store float 0x0000000000000000, ptr %v63, align 4
  %v64 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 52
  store float 0x0000000000000000, ptr %v64, align 4
  %v65 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 53
  store float 0x0000000000000000, ptr %v65, align 4
  %v66 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 54
  store float 0x0000000000000000, ptr %v66, align 4
  %v67 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 55
  store float 0x0000000000000000, ptr %v67, align 4
  %v68 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 56
  store float 0x0000000000000000, ptr %v68, align 4
  %v69 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 57
  store float 0x0000000000000000, ptr %v69, align 4
  %v70 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 58
  store float 0x0000000000000000, ptr %v70, align 4
  %v71 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 59
  store float 0x0000000000000000, ptr %v71, align 4
  %v72 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 60
  store float 0x0000000000000000, ptr %v72, align 4
  %v73 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 61
  store float 0x0000000000000000, ptr %v73, align 4
  %v74 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 62
  store float 0x0000000000000000, ptr %v74, align 4
  %v75 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 63
  store float 0x0000000000000000, ptr %v75, align 4
  %v76 = add i64 %v2, 0
  %v77 = udiv i64 %v76, 64
  %v78 = urem i64 %v76, 64
  %v79 = add i64 %v9, %v78
  %v80 = mul i64 %v79, 1
  %v81 = mul i64 %v77, 256
  %v82 = add i64 %v80, %v81
  %v83 = add i64 %v82, 0
  %v84 = mul i64 %v77, 64
  %v85 = add i64 %v84, %v78
  %v86 = add i64 %v2, 32
  %v87 = udiv i64 %v86, 64
  %v88 = urem i64 %v86, 64
  %v89 = add i64 %v9, %v88
  %v90 = mul i64 %v89, 1
  %v91 = mul i64 %v87, 256
  %v92 = add i64 %v90, %v91
  %v93 = add i64 %v92, 0
  %v94 = mul i64 %v87, 64
  %v95 = add i64 %v94, %v88
  %v96 = add i64 %v2, 64
  %v97 = udiv i64 %v96, 64
  %v98 = urem i64 %v96, 64
  %v99 = add i64 %v9, %v98
  %v100 = mul i64 %v99, 1
  %v101 = mul i64 %v97, 256
  %v102 = add i64 %v100, %v101
  %v103 = add i64 %v102, 0
  %v104 = mul i64 %v97, 64
  %v105 = add i64 %v104, %v98
  %v106 = add i64 %v2, 96
  %v107 = udiv i64 %v106, 64
  %v108 = urem i64 %v106, 64
  %v109 = add i64 %v9, %v108
  %v110 = mul i64 %v109, 1
  %v111 = mul i64 %v107, 256
  %v112 = add i64 %v110, %v111
  %v113 = add i64 %v112, 0
  %v114 = mul i64 %v107, 64
  %v115 = add i64 %v114, %v108
  %v116 = add i64 %v2, 128
  %v117 = udiv i64 %v116, 64
  %v118 = urem i64 %v116, 64
  %v119 = add i64 %v9, %v118
  %v120 = mul i64 %v119, 1
  %v121 = mul i64 %v117, 256
  %v122 = add i64 %v120, %v121
  %v123 = add i64 %v122, 0
  %v124 = mul i64 %v117, 64
  %v125 = add i64 %v124, %v118
  %v126 = add i64 %v2, 160
  %v127 = udiv i64 %v126, 64
  %v128 = urem i64 %v126, 64
  %v129 = add i64 %v9, %v128
  %v130 = mul i64 %v129, 1
  %v131 = mul i64 %v127, 256
  %v132 = add i64 %v130, %v131
  %v133 = add i64 %v132, 0
  %v134 = mul i64 %v127, 64
  %v135 = add i64 %v134, %v128
  %v136 = add i64 %v2, 192
  %v137 = udiv i64 %v136, 64
  %v138 = urem i64 %v136, 64
  %v139 = add i64 %v9, %v138
  %v140 = mul i64 %v139, 1
  %v141 = mul i64 %v137, 256
  %v142 = add i64 %v140, %v141
  %v143 = add i64 %v142, 0
  %v144 = mul i64 %v137, 64
  %v145 = add i64 %v144, %v138
  %v146 = add i64 %v2, 224
  %v147 = udiv i64 %v146, 64
  %v148 = urem i64 %v146, 64
  %v149 = add i64 %v9, %v148
  %v150 = mul i64 %v149, 1
  %v151 = mul i64 %v147, 256
  %v152 = add i64 %v150, %v151
  %v153 = add i64 %v152, 0
  %v154 = mul i64 %v147, 64
  %v155 = add i64 %v154, %v148
  %v156 = add i64 %v2, 0
  %v157 = udiv i64 %v156, 8
  %v158 = urem i64 %v156, 8
  %v159 = mul i64 %v158, 4
  %v160 = mul i64 %v157, 256
  %v161 = add i64 %v10, %v159
  %v162 = mul i64 %v161, 1
  %v163 = add i64 %v160, %v162
  %v164 = add i64 %v163, 0
  %v165 = mul i64 %v157, 32
  %v166 = add i64 %v165, %v159
  %v167 = add i64 %v166, 256
  %v168 = mul i64 %v7, 8
  %v169 = mul i64 %v8, 8
  %v170 = mul i64 0, 256
  %v171 = mul i64 0, 256
  %v172 = add i64 %v83, %v170
  %v173 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v172
  %v174 = load float, ptr addrspace(1) %v173, align 4
  %v175 = add i64 %v93, %v170
  %v176 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v175
  %v177 = load float, ptr addrspace(1) %v176, align 4
  %v178 = add i64 %v103, %v170
  %v179 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v178
  %v180 = load float, ptr addrspace(1) %v179, align 4
  %v181 = add i64 %v113, %v170
  %v182 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v181
  %v183 = load float, ptr addrspace(1) %v182, align 4
  %v184 = add i64 %v123, %v170
  %v185 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v184
  %v186 = load float, ptr addrspace(1) %v185, align 4
  %v187 = add i64 %v133, %v170
  %v188 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v187
  %v189 = load float, ptr addrspace(1) %v188, align 4
  %v190 = add i64 %v143, %v170
  %v191 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v190
  %v192 = load float, ptr addrspace(1) %v191, align 4
  %v193 = add i64 %v153, %v170
  %v194 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v193
  %v195 = load float, ptr addrspace(1) %v194, align 4
  %v196 = add i64 %v164, %v171
  %v197 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v196
  %v198 = load <4 x float>, ptr addrspace(1) %v197, align 16
  br label %kt
kt:
  %v199 = phi i64 [0, %entry], [%v200, %ktl]
  %v201 = phi float [%v174, %entry], [%v226, %ktl]
  %v202 = phi float [%v177, %entry], [%v229, %ktl]
  %v203 = phi float [%v180, %entry], [%v232, %ktl]
  %v204 = phi float [%v183, %entry], [%v235, %ktl]
  %v205 = phi float [%v186, %entry], [%v238, %ktl]
  %v206 = phi float [%v189, %entry], [%v241, %ktl]
  %v207 = phi float [%v192, %entry], [%v244, %ktl]
  %v208 = phi float [%v195, %entry], [%v247, %ktl]
  %v209 = phi <4 x float> [%v198, %entry], [%v250, %ktl]
  %v210 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v85
  store float %v201, ptr addrspace(3) %v210, align 4
  %v211 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v95
  store float %v202, ptr addrspace(3) %v211, align 4
  %v212 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v105
  store float %v203, ptr addrspace(3) %v212, align 4
  %v213 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v115
  store float %v204, ptr addrspace(3) %v213, align 4
  %v214 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v125
  store float %v205, ptr addrspace(3) %v214, align 4
  %v215 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v135
  store float %v206, ptr addrspace(3) %v215, align 4
  %v216 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v145
  store float %v207, ptr addrspace(3) %v216, align 4
  %v217 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v155
  store float %v208, ptr addrspace(3) %v217, align 4
  %v218 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v167
  store <4 x float> %v209, ptr addrspace(3) %v218, align 16
  call void @llvm.nvvm.barrier0()
  %v219 = add i64 %v199, 4
  %v220 = icmp ult i64 %v219, 128
  %v221 = select i1 %v220, i64 %v219, i64 %v199
  %v222 = mul i64 %v221, 256
  %v223 = mul i64 %v221, 256
  %v224 = add i64 %v83, %v222
  %v225 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v224
  %v226 = load float, ptr addrspace(1) %v225, align 4
  %v227 = add i64 %v93, %v222
  %v228 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v227
  %v229 = load float, ptr addrspace(1) %v228, align 4
  %v230 = add i64 %v103, %v222
  %v231 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v230
  %v232 = load float, ptr addrspace(1) %v231, align 4
  %v233 = add i64 %v113, %v222
  %v234 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v233
  %v235 = load float, ptr addrspace(1) %v234, align 4
  %v236 = add i64 %v123, %v222
  %v237 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v236
  %v238 = load float, ptr addrspace(1) %v237, align 4
  %v239 = add i64 %v133, %v222
  %v240 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v239
  %v241 = load float, ptr addrspace(1) %v240, align 4
  %v242 = add i64 %v143, %v222
  %v243 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v242
  %v244 = load float, ptr addrspace(1) %v243, align 4
  %v245 = add i64 %v153, %v222
  %v246 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v245
  %v247 = load float, ptr addrspace(1) %v246, align 4
  %v248 = add i64 %v164, %v223
  %v249 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v248
  %v250 = load <4 x float>, ptr addrspace(1) %v249, align 16
  br label %kk
kk:
  %v251 = phi i64 [0, %kt], [%v252, %kk]
  %v253 = mul i64 %v251, 64
  %v254 = add i64 %v253, %v168
  %v255 = add i64 %v254, 0
  %v256 = add i64 %v255, 0
  %v257 = add i64 %v256, 0
  %v258 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v257
  %v259 = load <4 x float>, ptr addrspace(3) %v258, align 16
  %v260 = extractelement <4 x float> %v259, i64 0
  %v261 = extractelement <4 x float> %v259, i64 1
  %v262 = extractelement <4 x float> %v259, i64 2
  %v263 = extractelement <4 x float> %v259, i64 3
  %v264 = add i64 %v256, 4
  %v265 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v264
  %v266 = load <4 x float>, ptr addrspace(3) %v265, align 16
  %v267 = extractelement <4 x float> %v266, i64 0
  %v268 = extractelement <4 x float> %v266, i64 1
  %v269 = extractelement <4 x float> %v266, i64 2
  %v270 = extractelement <4 x float> %v266, i64 3
  %v271 = mul i64 %v251, 32
  %v272 = add i64 %v271, %v169
  %v273 = add i64 %v272, 256
  %v274 = add i64 %v273, 0
  %v275 = add i64 %v274, 0
  %v276 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v275
  %v277 = load <4 x float>, ptr addrspace(3) %v276, align 16
  %v278 = extractelement <4 x float> %v277, i64 0
  %v279 = extractelement <4 x float> %v277, i64 1
  %v280 = extractelement <4 x float> %v277, i64 2
  %v281 = extractelement <4 x float> %v277, i64 3
  %v282 = add i64 %v274, 4
  %v283 = getelementptr inbounds float, ptr addrspace(3) @mapal_smem, i64 %v282
  %v284 = load <4 x float>, ptr addrspace(3) %v283, align 16
  %v285 = extractelement <4 x float> %v284, i64 0
  %v286 = extractelement <4 x float> %v284, i64 1
  %v287 = extractelement <4 x float> %v284, i64 2
  %v288 = extractelement <4 x float> %v284, i64 3
  %v289 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 0
  %v290 = load float, ptr %v289, align 4
  %v291 = call float @llvm.fma.f32(float %v260, float %v278, float %v290)
  store float %v291, ptr %v289, align 4
  %v292 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 1
  %v293 = load float, ptr %v292, align 4
  %v294 = call float @llvm.fma.f32(float %v260, float %v279, float %v293)
  store float %v294, ptr %v292, align 4
  %v295 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 2
  %v296 = load float, ptr %v295, align 4
  %v297 = call float @llvm.fma.f32(float %v260, float %v280, float %v296)
  store float %v297, ptr %v295, align 4
  %v298 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 3
  %v299 = load float, ptr %v298, align 4
  %v300 = call float @llvm.fma.f32(float %v260, float %v281, float %v299)
  store float %v300, ptr %v298, align 4
  %v301 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 4
  %v302 = load float, ptr %v301, align 4
  %v303 = call float @llvm.fma.f32(float %v260, float %v285, float %v302)
  store float %v303, ptr %v301, align 4
  %v304 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 5
  %v305 = load float, ptr %v304, align 4
  %v306 = call float @llvm.fma.f32(float %v260, float %v286, float %v305)
  store float %v306, ptr %v304, align 4
  %v307 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 6
  %v308 = load float, ptr %v307, align 4
  %v309 = call float @llvm.fma.f32(float %v260, float %v287, float %v308)
  store float %v309, ptr %v307, align 4
  %v310 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 7
  %v311 = load float, ptr %v310, align 4
  %v312 = call float @llvm.fma.f32(float %v260, float %v288, float %v311)
  store float %v312, ptr %v310, align 4
  %v313 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 8
  %v314 = load float, ptr %v313, align 4
  %v315 = call float @llvm.fma.f32(float %v261, float %v278, float %v314)
  store float %v315, ptr %v313, align 4
  %v316 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 9
  %v317 = load float, ptr %v316, align 4
  %v318 = call float @llvm.fma.f32(float %v261, float %v279, float %v317)
  store float %v318, ptr %v316, align 4
  %v319 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 10
  %v320 = load float, ptr %v319, align 4
  %v321 = call float @llvm.fma.f32(float %v261, float %v280, float %v320)
  store float %v321, ptr %v319, align 4
  %v322 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 11
  %v323 = load float, ptr %v322, align 4
  %v324 = call float @llvm.fma.f32(float %v261, float %v281, float %v323)
  store float %v324, ptr %v322, align 4
  %v325 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 12
  %v326 = load float, ptr %v325, align 4
  %v327 = call float @llvm.fma.f32(float %v261, float %v285, float %v326)
  store float %v327, ptr %v325, align 4
  %v328 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 13
  %v329 = load float, ptr %v328, align 4
  %v330 = call float @llvm.fma.f32(float %v261, float %v286, float %v329)
  store float %v330, ptr %v328, align 4
  %v331 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 14
  %v332 = load float, ptr %v331, align 4
  %v333 = call float @llvm.fma.f32(float %v261, float %v287, float %v332)
  store float %v333, ptr %v331, align 4
  %v334 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 15
  %v335 = load float, ptr %v334, align 4
  %v336 = call float @llvm.fma.f32(float %v261, float %v288, float %v335)
  store float %v336, ptr %v334, align 4
  %v337 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 16
  %v338 = load float, ptr %v337, align 4
  %v339 = call float @llvm.fma.f32(float %v262, float %v278, float %v338)
  store float %v339, ptr %v337, align 4
  %v340 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 17
  %v341 = load float, ptr %v340, align 4
  %v342 = call float @llvm.fma.f32(float %v262, float %v279, float %v341)
  store float %v342, ptr %v340, align 4
  %v343 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 18
  %v344 = load float, ptr %v343, align 4
  %v345 = call float @llvm.fma.f32(float %v262, float %v280, float %v344)
  store float %v345, ptr %v343, align 4
  %v346 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 19
  %v347 = load float, ptr %v346, align 4
  %v348 = call float @llvm.fma.f32(float %v262, float %v281, float %v347)
  store float %v348, ptr %v346, align 4
  %v349 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 20
  %v350 = load float, ptr %v349, align 4
  %v351 = call float @llvm.fma.f32(float %v262, float %v285, float %v350)
  store float %v351, ptr %v349, align 4
  %v352 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 21
  %v353 = load float, ptr %v352, align 4
  %v354 = call float @llvm.fma.f32(float %v262, float %v286, float %v353)
  store float %v354, ptr %v352, align 4
  %v355 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 22
  %v356 = load float, ptr %v355, align 4
  %v357 = call float @llvm.fma.f32(float %v262, float %v287, float %v356)
  store float %v357, ptr %v355, align 4
  %v358 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 23
  %v359 = load float, ptr %v358, align 4
  %v360 = call float @llvm.fma.f32(float %v262, float %v288, float %v359)
  store float %v360, ptr %v358, align 4
  %v361 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 24
  %v362 = load float, ptr %v361, align 4
  %v363 = call float @llvm.fma.f32(float %v263, float %v278, float %v362)
  store float %v363, ptr %v361, align 4
  %v364 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 25
  %v365 = load float, ptr %v364, align 4
  %v366 = call float @llvm.fma.f32(float %v263, float %v279, float %v365)
  store float %v366, ptr %v364, align 4
  %v367 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 26
  %v368 = load float, ptr %v367, align 4
  %v369 = call float @llvm.fma.f32(float %v263, float %v280, float %v368)
  store float %v369, ptr %v367, align 4
  %v370 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 27
  %v371 = load float, ptr %v370, align 4
  %v372 = call float @llvm.fma.f32(float %v263, float %v281, float %v371)
  store float %v372, ptr %v370, align 4
  %v373 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 28
  %v374 = load float, ptr %v373, align 4
  %v375 = call float @llvm.fma.f32(float %v263, float %v285, float %v374)
  store float %v375, ptr %v373, align 4
  %v376 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 29
  %v377 = load float, ptr %v376, align 4
  %v378 = call float @llvm.fma.f32(float %v263, float %v286, float %v377)
  store float %v378, ptr %v376, align 4
  %v379 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 30
  %v380 = load float, ptr %v379, align 4
  %v381 = call float @llvm.fma.f32(float %v263, float %v287, float %v380)
  store float %v381, ptr %v379, align 4
  %v382 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 31
  %v383 = load float, ptr %v382, align 4
  %v384 = call float @llvm.fma.f32(float %v263, float %v288, float %v383)
  store float %v384, ptr %v382, align 4
  %v385 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 32
  %v386 = load float, ptr %v385, align 4
  %v387 = call float @llvm.fma.f32(float %v267, float %v278, float %v386)
  store float %v387, ptr %v385, align 4
  %v388 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 33
  %v389 = load float, ptr %v388, align 4
  %v390 = call float @llvm.fma.f32(float %v267, float %v279, float %v389)
  store float %v390, ptr %v388, align 4
  %v391 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 34
  %v392 = load float, ptr %v391, align 4
  %v393 = call float @llvm.fma.f32(float %v267, float %v280, float %v392)
  store float %v393, ptr %v391, align 4
  %v394 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 35
  %v395 = load float, ptr %v394, align 4
  %v396 = call float @llvm.fma.f32(float %v267, float %v281, float %v395)
  store float %v396, ptr %v394, align 4
  %v397 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 36
  %v398 = load float, ptr %v397, align 4
  %v399 = call float @llvm.fma.f32(float %v267, float %v285, float %v398)
  store float %v399, ptr %v397, align 4
  %v400 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 37
  %v401 = load float, ptr %v400, align 4
  %v402 = call float @llvm.fma.f32(float %v267, float %v286, float %v401)
  store float %v402, ptr %v400, align 4
  %v403 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 38
  %v404 = load float, ptr %v403, align 4
  %v405 = call float @llvm.fma.f32(float %v267, float %v287, float %v404)
  store float %v405, ptr %v403, align 4
  %v406 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 39
  %v407 = load float, ptr %v406, align 4
  %v408 = call float @llvm.fma.f32(float %v267, float %v288, float %v407)
  store float %v408, ptr %v406, align 4
  %v409 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 40
  %v410 = load float, ptr %v409, align 4
  %v411 = call float @llvm.fma.f32(float %v268, float %v278, float %v410)
  store float %v411, ptr %v409, align 4
  %v412 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 41
  %v413 = load float, ptr %v412, align 4
  %v414 = call float @llvm.fma.f32(float %v268, float %v279, float %v413)
  store float %v414, ptr %v412, align 4
  %v415 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 42
  %v416 = load float, ptr %v415, align 4
  %v417 = call float @llvm.fma.f32(float %v268, float %v280, float %v416)
  store float %v417, ptr %v415, align 4
  %v418 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 43
  %v419 = load float, ptr %v418, align 4
  %v420 = call float @llvm.fma.f32(float %v268, float %v281, float %v419)
  store float %v420, ptr %v418, align 4
  %v421 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 44
  %v422 = load float, ptr %v421, align 4
  %v423 = call float @llvm.fma.f32(float %v268, float %v285, float %v422)
  store float %v423, ptr %v421, align 4
  %v424 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 45
  %v425 = load float, ptr %v424, align 4
  %v426 = call float @llvm.fma.f32(float %v268, float %v286, float %v425)
  store float %v426, ptr %v424, align 4
  %v427 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 46
  %v428 = load float, ptr %v427, align 4
  %v429 = call float @llvm.fma.f32(float %v268, float %v287, float %v428)
  store float %v429, ptr %v427, align 4
  %v430 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 47
  %v431 = load float, ptr %v430, align 4
  %v432 = call float @llvm.fma.f32(float %v268, float %v288, float %v431)
  store float %v432, ptr %v430, align 4
  %v433 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 48
  %v434 = load float, ptr %v433, align 4
  %v435 = call float @llvm.fma.f32(float %v269, float %v278, float %v434)
  store float %v435, ptr %v433, align 4
  %v436 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 49
  %v437 = load float, ptr %v436, align 4
  %v438 = call float @llvm.fma.f32(float %v269, float %v279, float %v437)
  store float %v438, ptr %v436, align 4
  %v439 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 50
  %v440 = load float, ptr %v439, align 4
  %v441 = call float @llvm.fma.f32(float %v269, float %v280, float %v440)
  store float %v441, ptr %v439, align 4
  %v442 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 51
  %v443 = load float, ptr %v442, align 4
  %v444 = call float @llvm.fma.f32(float %v269, float %v281, float %v443)
  store float %v444, ptr %v442, align 4
  %v445 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 52
  %v446 = load float, ptr %v445, align 4
  %v447 = call float @llvm.fma.f32(float %v269, float %v285, float %v446)
  store float %v447, ptr %v445, align 4
  %v448 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 53
  %v449 = load float, ptr %v448, align 4
  %v450 = call float @llvm.fma.f32(float %v269, float %v286, float %v449)
  store float %v450, ptr %v448, align 4
  %v451 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 54
  %v452 = load float, ptr %v451, align 4
  %v453 = call float @llvm.fma.f32(float %v269, float %v287, float %v452)
  store float %v453, ptr %v451, align 4
  %v454 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 55
  %v455 = load float, ptr %v454, align 4
  %v456 = call float @llvm.fma.f32(float %v269, float %v288, float %v455)
  store float %v456, ptr %v454, align 4
  %v457 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 56
  %v458 = load float, ptr %v457, align 4
  %v459 = call float @llvm.fma.f32(float %v270, float %v278, float %v458)
  store float %v459, ptr %v457, align 4
  %v460 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 57
  %v461 = load float, ptr %v460, align 4
  %v462 = call float @llvm.fma.f32(float %v270, float %v279, float %v461)
  store float %v462, ptr %v460, align 4
  %v463 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 58
  %v464 = load float, ptr %v463, align 4
  %v465 = call float @llvm.fma.f32(float %v270, float %v280, float %v464)
  store float %v465, ptr %v463, align 4
  %v466 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 59
  %v467 = load float, ptr %v466, align 4
  %v468 = call float @llvm.fma.f32(float %v270, float %v281, float %v467)
  store float %v468, ptr %v466, align 4
  %v469 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 60
  %v470 = load float, ptr %v469, align 4
  %v471 = call float @llvm.fma.f32(float %v270, float %v285, float %v470)
  store float %v471, ptr %v469, align 4
  %v472 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 61
  %v473 = load float, ptr %v472, align 4
  %v474 = call float @llvm.fma.f32(float %v270, float %v286, float %v473)
  store float %v474, ptr %v472, align 4
  %v475 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 62
  %v476 = load float, ptr %v475, align 4
  %v477 = call float @llvm.fma.f32(float %v270, float %v287, float %v476)
  store float %v477, ptr %v475, align 4
  %v478 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 63
  %v479 = load float, ptr %v478, align 4
  %v480 = call float @llvm.fma.f32(float %v270, float %v288, float %v479)
  store float %v480, ptr %v478, align 4
  %v252 = add i64 %v251, 1
  %v481 = icmp eq i64 %v252, 4
  br i1 %v481, label %ktl, label %kk, !llvm.loop !0
ktl:
  call void @llvm.nvvm.barrier0()
  %v200 = add i64 %v199, 4
  %v482 = icmp eq i64 %v200, 128
  br i1 %v482, label %done, label %kt
done:
  %v483 = add i64 %v9, %v168
  %v484 = add i64 %v483, 0
  %v485 = mul i64 %v484, 256
  %v486 = add i64 %v485, %v10
  %v487 = add i64 %v486, %v169
  %v488 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 0
  %v489 = load float, ptr %v488, align 4
  %v490 = insertelement <4 x float> poison, float %v489, i64 0
  %v491 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 1
  %v492 = load float, ptr %v491, align 4
  %v493 = insertelement <4 x float> %v490, float %v492, i64 1
  %v494 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 2
  %v495 = load float, ptr %v494, align 4
  %v496 = insertelement <4 x float> %v493, float %v495, i64 2
  %v497 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 3
  %v498 = load float, ptr %v497, align 4
  %v499 = insertelement <4 x float> %v496, float %v498, i64 3
  %v500 = add i64 %v487, 0
  %v501 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v500
  store <4 x float> %v499, ptr addrspace(1) %v501, align 16
  %v502 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 4
  %v503 = load float, ptr %v502, align 4
  %v504 = insertelement <4 x float> poison, float %v503, i64 0
  %v505 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 5
  %v506 = load float, ptr %v505, align 4
  %v507 = insertelement <4 x float> %v504, float %v506, i64 1
  %v508 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 6
  %v509 = load float, ptr %v508, align 4
  %v510 = insertelement <4 x float> %v507, float %v509, i64 2
  %v511 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 7
  %v512 = load float, ptr %v511, align 4
  %v513 = insertelement <4 x float> %v510, float %v512, i64 3
  %v514 = add i64 %v487, 4
  %v515 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v514
  store <4 x float> %v513, ptr addrspace(1) %v515, align 16
  %v516 = add i64 %v9, %v168
  %v517 = add i64 %v516, 1
  %v518 = mul i64 %v517, 256
  %v519 = add i64 %v518, %v10
  %v520 = add i64 %v519, %v169
  %v521 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 8
  %v522 = load float, ptr %v521, align 4
  %v523 = insertelement <4 x float> poison, float %v522, i64 0
  %v524 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 9
  %v525 = load float, ptr %v524, align 4
  %v526 = insertelement <4 x float> %v523, float %v525, i64 1
  %v527 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 10
  %v528 = load float, ptr %v527, align 4
  %v529 = insertelement <4 x float> %v526, float %v528, i64 2
  %v530 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 11
  %v531 = load float, ptr %v530, align 4
  %v532 = insertelement <4 x float> %v529, float %v531, i64 3
  %v533 = add i64 %v520, 0
  %v534 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v533
  store <4 x float> %v532, ptr addrspace(1) %v534, align 16
  %v535 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 12
  %v536 = load float, ptr %v535, align 4
  %v537 = insertelement <4 x float> poison, float %v536, i64 0
  %v538 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 13
  %v539 = load float, ptr %v538, align 4
  %v540 = insertelement <4 x float> %v537, float %v539, i64 1
  %v541 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 14
  %v542 = load float, ptr %v541, align 4
  %v543 = insertelement <4 x float> %v540, float %v542, i64 2
  %v544 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 15
  %v545 = load float, ptr %v544, align 4
  %v546 = insertelement <4 x float> %v543, float %v545, i64 3
  %v547 = add i64 %v520, 4
  %v548 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v547
  store <4 x float> %v546, ptr addrspace(1) %v548, align 16
  %v549 = add i64 %v9, %v168
  %v550 = add i64 %v549, 2
  %v551 = mul i64 %v550, 256
  %v552 = add i64 %v551, %v10
  %v553 = add i64 %v552, %v169
  %v554 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 16
  %v555 = load float, ptr %v554, align 4
  %v556 = insertelement <4 x float> poison, float %v555, i64 0
  %v557 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 17
  %v558 = load float, ptr %v557, align 4
  %v559 = insertelement <4 x float> %v556, float %v558, i64 1
  %v560 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 18
  %v561 = load float, ptr %v560, align 4
  %v562 = insertelement <4 x float> %v559, float %v561, i64 2
  %v563 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 19
  %v564 = load float, ptr %v563, align 4
  %v565 = insertelement <4 x float> %v562, float %v564, i64 3
  %v566 = add i64 %v553, 0
  %v567 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v566
  store <4 x float> %v565, ptr addrspace(1) %v567, align 16
  %v568 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 20
  %v569 = load float, ptr %v568, align 4
  %v570 = insertelement <4 x float> poison, float %v569, i64 0
  %v571 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 21
  %v572 = load float, ptr %v571, align 4
  %v573 = insertelement <4 x float> %v570, float %v572, i64 1
  %v574 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 22
  %v575 = load float, ptr %v574, align 4
  %v576 = insertelement <4 x float> %v573, float %v575, i64 2
  %v577 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 23
  %v578 = load float, ptr %v577, align 4
  %v579 = insertelement <4 x float> %v576, float %v578, i64 3
  %v580 = add i64 %v553, 4
  %v581 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v580
  store <4 x float> %v579, ptr addrspace(1) %v581, align 16
  %v582 = add i64 %v9, %v168
  %v583 = add i64 %v582, 3
  %v584 = mul i64 %v583, 256
  %v585 = add i64 %v584, %v10
  %v586 = add i64 %v585, %v169
  %v587 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 24
  %v588 = load float, ptr %v587, align 4
  %v589 = insertelement <4 x float> poison, float %v588, i64 0
  %v590 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 25
  %v591 = load float, ptr %v590, align 4
  %v592 = insertelement <4 x float> %v589, float %v591, i64 1
  %v593 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 26
  %v594 = load float, ptr %v593, align 4
  %v595 = insertelement <4 x float> %v592, float %v594, i64 2
  %v596 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 27
  %v597 = load float, ptr %v596, align 4
  %v598 = insertelement <4 x float> %v595, float %v597, i64 3
  %v599 = add i64 %v586, 0
  %v600 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v599
  store <4 x float> %v598, ptr addrspace(1) %v600, align 16
  %v601 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 28
  %v602 = load float, ptr %v601, align 4
  %v603 = insertelement <4 x float> poison, float %v602, i64 0
  %v604 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 29
  %v605 = load float, ptr %v604, align 4
  %v606 = insertelement <4 x float> %v603, float %v605, i64 1
  %v607 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 30
  %v608 = load float, ptr %v607, align 4
  %v609 = insertelement <4 x float> %v606, float %v608, i64 2
  %v610 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 31
  %v611 = load float, ptr %v610, align 4
  %v612 = insertelement <4 x float> %v609, float %v611, i64 3
  %v613 = add i64 %v586, 4
  %v614 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v613
  store <4 x float> %v612, ptr addrspace(1) %v614, align 16
  %v615 = add i64 %v9, %v168
  %v616 = add i64 %v615, 4
  %v617 = mul i64 %v616, 256
  %v618 = add i64 %v617, %v10
  %v619 = add i64 %v618, %v169
  %v620 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 32
  %v621 = load float, ptr %v620, align 4
  %v622 = insertelement <4 x float> poison, float %v621, i64 0
  %v623 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 33
  %v624 = load float, ptr %v623, align 4
  %v625 = insertelement <4 x float> %v622, float %v624, i64 1
  %v626 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 34
  %v627 = load float, ptr %v626, align 4
  %v628 = insertelement <4 x float> %v625, float %v627, i64 2
  %v629 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 35
  %v630 = load float, ptr %v629, align 4
  %v631 = insertelement <4 x float> %v628, float %v630, i64 3
  %v632 = add i64 %v619, 0
  %v633 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v632
  store <4 x float> %v631, ptr addrspace(1) %v633, align 16
  %v634 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 36
  %v635 = load float, ptr %v634, align 4
  %v636 = insertelement <4 x float> poison, float %v635, i64 0
  %v637 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 37
  %v638 = load float, ptr %v637, align 4
  %v639 = insertelement <4 x float> %v636, float %v638, i64 1
  %v640 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 38
  %v641 = load float, ptr %v640, align 4
  %v642 = insertelement <4 x float> %v639, float %v641, i64 2
  %v643 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 39
  %v644 = load float, ptr %v643, align 4
  %v645 = insertelement <4 x float> %v642, float %v644, i64 3
  %v646 = add i64 %v619, 4
  %v647 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v646
  store <4 x float> %v645, ptr addrspace(1) %v647, align 16
  %v648 = add i64 %v9, %v168
  %v649 = add i64 %v648, 5
  %v650 = mul i64 %v649, 256
  %v651 = add i64 %v650, %v10
  %v652 = add i64 %v651, %v169
  %v653 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 40
  %v654 = load float, ptr %v653, align 4
  %v655 = insertelement <4 x float> poison, float %v654, i64 0
  %v656 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 41
  %v657 = load float, ptr %v656, align 4
  %v658 = insertelement <4 x float> %v655, float %v657, i64 1
  %v659 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 42
  %v660 = load float, ptr %v659, align 4
  %v661 = insertelement <4 x float> %v658, float %v660, i64 2
  %v662 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 43
  %v663 = load float, ptr %v662, align 4
  %v664 = insertelement <4 x float> %v661, float %v663, i64 3
  %v665 = add i64 %v652, 0
  %v666 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v665
  store <4 x float> %v664, ptr addrspace(1) %v666, align 16
  %v667 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 44
  %v668 = load float, ptr %v667, align 4
  %v669 = insertelement <4 x float> poison, float %v668, i64 0
  %v670 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 45
  %v671 = load float, ptr %v670, align 4
  %v672 = insertelement <4 x float> %v669, float %v671, i64 1
  %v673 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 46
  %v674 = load float, ptr %v673, align 4
  %v675 = insertelement <4 x float> %v672, float %v674, i64 2
  %v676 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 47
  %v677 = load float, ptr %v676, align 4
  %v678 = insertelement <4 x float> %v675, float %v677, i64 3
  %v679 = add i64 %v652, 4
  %v680 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v679
  store <4 x float> %v678, ptr addrspace(1) %v680, align 16
  %v681 = add i64 %v9, %v168
  %v682 = add i64 %v681, 6
  %v683 = mul i64 %v682, 256
  %v684 = add i64 %v683, %v10
  %v685 = add i64 %v684, %v169
  %v686 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 48
  %v687 = load float, ptr %v686, align 4
  %v688 = insertelement <4 x float> poison, float %v687, i64 0
  %v689 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 49
  %v690 = load float, ptr %v689, align 4
  %v691 = insertelement <4 x float> %v688, float %v690, i64 1
  %v692 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 50
  %v693 = load float, ptr %v692, align 4
  %v694 = insertelement <4 x float> %v691, float %v693, i64 2
  %v695 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 51
  %v696 = load float, ptr %v695, align 4
  %v697 = insertelement <4 x float> %v694, float %v696, i64 3
  %v698 = add i64 %v685, 0
  %v699 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v698
  store <4 x float> %v697, ptr addrspace(1) %v699, align 16
  %v700 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 52
  %v701 = load float, ptr %v700, align 4
  %v702 = insertelement <4 x float> poison, float %v701, i64 0
  %v703 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 53
  %v704 = load float, ptr %v703, align 4
  %v705 = insertelement <4 x float> %v702, float %v704, i64 1
  %v706 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 54
  %v707 = load float, ptr %v706, align 4
  %v708 = insertelement <4 x float> %v705, float %v707, i64 2
  %v709 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 55
  %v710 = load float, ptr %v709, align 4
  %v711 = insertelement <4 x float> %v708, float %v710, i64 3
  %v712 = add i64 %v685, 4
  %v713 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v712
  store <4 x float> %v711, ptr addrspace(1) %v713, align 16
  %v714 = add i64 %v9, %v168
  %v715 = add i64 %v714, 7
  %v716 = mul i64 %v715, 256
  %v717 = add i64 %v716, %v10
  %v718 = add i64 %v717, %v169
  %v719 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 56
  %v720 = load float, ptr %v719, align 4
  %v721 = insertelement <4 x float> poison, float %v720, i64 0
  %v722 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 57
  %v723 = load float, ptr %v722, align 4
  %v724 = insertelement <4 x float> %v721, float %v723, i64 1
  %v725 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 58
  %v726 = load float, ptr %v725, align 4
  %v727 = insertelement <4 x float> %v724, float %v726, i64 2
  %v728 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 59
  %v729 = load float, ptr %v728, align 4
  %v730 = insertelement <4 x float> %v727, float %v729, i64 3
  %v731 = add i64 %v718, 0
  %v732 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v731
  store <4 x float> %v730, ptr addrspace(1) %v732, align 16
  %v733 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 60
  %v734 = load float, ptr %v733, align 4
  %v735 = insertelement <4 x float> poison, float %v734, i64 0
  %v736 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 61
  %v737 = load float, ptr %v736, align 4
  %v738 = insertelement <4 x float> %v735, float %v737, i64 1
  %v739 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 62
  %v740 = load float, ptr %v739, align 4
  %v741 = insertelement <4 x float> %v738, float %v740, i64 2
  %v742 = getelementptr inbounds [64 x float], ptr %v11, i64 0, i64 63
  %v743 = load float, ptr %v742, align 4
  %v744 = insertelement <4 x float> %v741, float %v743, i64 3
  %v745 = add i64 %v718, 4
  %v746 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v745
  store <4 x float> %v744, ptr addrspace(1) %v746, align 16
  ret void
}

define internal float @fn1(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  %o10 = alloca float
  %o11 = alloca { float, float }
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 7, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 13, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 101, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 50, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to float
  store float %t33, ptr %o10
  %t34 = load float, ptr %o10
  %t35 = getelementptr { float, float }, ptr %o11, i32 0, i32 0
  store float %t34, ptr %t35
  %t36 = getelementptr { float, float }, ptr %o11, i32 0, i32 1
  store float 0x401C000000000000, ptr %t36
  %t37 = getelementptr { float, float }, ptr %o11, i32 0, i32 0
  %t38 = load float, ptr %t37
  %t39 = getelementptr { float, float }, ptr %o11, i32 0, i32 1
  %t40 = load float, ptr %t39
  %t41 = fdiv float %t38, %t40
  store float %t41, ptr %o1
  %t42 = load float, ptr %o1
  ret float %t42
}

define ptx_kernel void @mapal_gen_8ffe47670bd33645(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call float @fn1(i32 %x)
  %p = getelementptr inbounds float, ptr addrspace(1) %o, i64 %i
  store float %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

define internal float @fn2(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  %o2 = alloca { i32, i32 }
  %o3 = alloca i32
  %o4 = alloca { i32, i32 }
  %o5 = alloca i32
  %o6 = alloca { i32, i32 }
  %o7 = alloca i32
  %o8 = alloca { i32, i32 }
  %o9 = alloca i32
  %o10 = alloca float
  %o11 = alloca { float, float }
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  store i32 %t0, ptr %t1
  %t2 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  store i32 11, ptr %t2
  %t3 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 0
  %t4 = load i32, ptr %t3
  %t5 = getelementptr { i32, i32 }, ptr %o2, i32 0, i32 1
  %t6 = load i32, ptr %t5
  %t7 = mul i32 %t4, %t6
  store i32 %t7, ptr %o3
  %t8 = load i32, ptr %o3
  %t9 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  store i32 %t8, ptr %t9
  %t10 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  store i32 57, ptr %t10
  %t11 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 0
  %t12 = load i32, ptr %t11
  %t13 = getelementptr { i32, i32 }, ptr %o4, i32 0, i32 1
  %t14 = load i32, ptr %t13
  %t15 = add i32 %t12, %t14
  store i32 %t15, ptr %o5
  %t16 = load i32, ptr %o5
  %t17 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  store i32 %t16, ptr %t17
  %t18 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  store i32 103, ptr %t18
  %t19 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 0
  %t20 = load i32, ptr %t19
  %t21 = getelementptr { i32, i32 }, ptr %o6, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t23 = srem i32 %t20, %t22
  store i32 %t23, ptr %o7
  %t24 = load i32, ptr %o7
  %t25 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  store i32 %t24, ptr %t25
  %t26 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  store i32 51, ptr %t26
  %t27 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 0
  %t28 = load i32, ptr %t27
  %t29 = getelementptr { i32, i32 }, ptr %o8, i32 0, i32 1
  %t30 = load i32, ptr %t29
  %t31 = sub i32 %t28, %t30
  store i32 %t31, ptr %o9
  %t32 = load i32, ptr %o9
  %t33 = sitofp i32 %t32 to float
  store float %t33, ptr %o10
  %t34 = load float, ptr %o10
  %t35 = getelementptr { float, float }, ptr %o11, i32 0, i32 0
  store float %t34, ptr %t35
  %t36 = getelementptr { float, float }, ptr %o11, i32 0, i32 1
  store float 0x4022000000000000, ptr %t36
  %t37 = getelementptr { float, float }, ptr %o11, i32 0, i32 0
  %t38 = load float, ptr %t37
  %t39 = getelementptr { float, float }, ptr %o11, i32 0, i32 1
  %t40 = load float, ptr %t39
  %t41 = fdiv float %t38, %t40
  store float %t41, ptr %o1
  %t42 = load float, ptr %o1
  ret float %t42
}

define ptx_kernel void @mapal_gen_df380f056691f9de(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call float @fn2(i32 %x)
  %p = getelementptr inbounds float, ptr addrspace(1) %o, i64 %i
  store float %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

!0 = distinct !{!0, !1}
!1 = !{!"llvm.loop.unroll.full"}
