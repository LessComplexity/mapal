; mapal-backend-llvm device module
target datalayout = "e-p6:32:32-i64:64-i128:128-i256:256-v16:16-v32:32-n16:32:64"
target triple = "nvptx64-nvidia-cuda"

@mapal_smem = external addrspace(3) global [0 x i8], align 16
declare i32 @llvm.nvvm.read.ptx.sreg.tid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.y()
declare void @llvm.nvvm.barrier0()
declare void @llvm.nvvm.cp.async.cg.shared.global.16(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.4(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.ca.shared.global.8(ptr addrspace(3), ptr addrspace(1))
declare void @llvm.nvvm.cp.async.commit.group()
declare void @llvm.nvvm.cp.async.wait.group(i32 immarg)
declare float @llvm.fma.f32(float, float, float)
declare double @llvm.fma.f64(double, double, double)

define ptx_kernel void @mapal_tile_d51aa3cbc2658d57(ptr addrspace(1) noalias readonly align 4 %a, ptr addrspace(1) noalias readonly align 4 %b, ptr addrspace(1) noalias align 4 %o) "nvvm.maxntid"="256" {
entry:
  %v1 = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %v2 = zext i32 %v1 to i64
  %v3 = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %v4 = zext i32 %v3 to i64
  %v5 = mul i64 %v4, 256
  %v6 = add i64 %v5, %v2
  %v7 = icmp ult i64 %v6, 256
  br i1 %v7, label %body, label %done
body:
  %v8 = udiv i64 %v6, 256
  %v9 = urem i64 %v6, 256
  %v10 = mul i64 %v8, 0
  %v11 = mul i64 %v9, 0
  %v12 = add i64 %v10, %v11
  %v13 = add i64 %v12, 0
  %v14 = mul i64 %v8, 0
  %v15 = mul i64 %v9, 128
  %v16 = add i64 %v14, %v15
  %v17 = add i64 %v16, 0
  br label %kloop
kloop:
  %v18 = phi i64 [0, %body], [%v20, %kloop]
  %v19 = phi float [0x4000000000000000, %body], [%v29, %kloop]
  %v21 = mul i64 %v18, 1
  %v22 = add i64 %v13, %v21
  %v23 = getelementptr inbounds float, ptr addrspace(1) %a, i64 %v22
  %v24 = load float, ptr addrspace(1) %v23, align 4
  %v25 = mul i64 %v18, 1
  %v26 = add i64 %v17, %v25
  %v27 = getelementptr inbounds float, ptr addrspace(1) %b, i64 %v26
  %v28 = load float, ptr addrspace(1) %v27, align 4
  %v30 = fmul float %v24, %v28
  %v29 = fadd float %v30, %v19
  %v20 = add i64 %v18, 1
  %v31 = icmp eq i64 %v20, 128
  br i1 %v31, label %store, label %kloop
store:
  %v32 = getelementptr inbounds float, ptr addrspace(1) %o, i64 %v6
  store float %v29, ptr addrspace(1) %v32, align 4
  br label %done
done:
  ret void
}

define internal float @fn1(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = sitofp i32 %t0 to float
  store float %t1, ptr %o1
  %t2 = load float, ptr %o1
  ret float %t2
}

define ptx_kernel void @mapal_gen_fe449f90d1eda582(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call float @fn1(i32 %x)
  %p = getelementptr inbounds float, ptr addrspace(1) %o, i64 %i
  store float %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

define internal float @fn2(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = sitofp i32 %t0 to float
  store float %t1, ptr %o1
  %t2 = load float, ptr %o1
  ret float %t2
}

define ptx_kernel void @mapal_gen_5cee44f9496d8476(ptr addrspace(1) %o, i64 %n) "nvvm.maxntid"="256" {
entry:
  %t = call i32 @llvm.nvvm.read.ptx.sreg.tid.x()
  %b = call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()
  %t64 = zext i32 %t to i64
  %b64 = zext i32 %b to i64
  %base = mul i64 %b64, 256
  %i = add i64 %base, %t64
  %in = icmp ult i64 %i, %n
  br i1 %in, label %body, label %done
body:
  %x = trunc i64 %i to i32
  %v = call float @fn2(i32 %x)
  %p = getelementptr inbounds float, ptr addrspace(1) %o, i64 %i
  store float %v, ptr addrspace(1) %p
  br label %done
done:
  ret void
}

