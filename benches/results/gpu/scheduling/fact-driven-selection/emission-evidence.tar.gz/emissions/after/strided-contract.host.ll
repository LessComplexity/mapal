; mapal-backend-llvm emitted module
declare void @mapal_print_i32(i32, i1 zeroext)
declare void @mapal_print_i64(i64, i1 zeroext)
declare void @mapal_print_u8(i8 zeroext, i1 zeroext)
declare void @mapal_print_bool(i1 zeroext, i1 zeroext)
declare void @mapal_print_f32(float, i1 zeroext)
declare void @mapal_print_f64(double, i1 zeroext)
declare void @mapal_print_str(ptr, i64, i1 zeroext)
declare double @mapal_time_ms()
declare void @mapal_trap(i32) noreturn
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @mapal_gpu_init(i32)
declare i64 @mapal_gpu_alloc(ptr, i64)
declare void @mapal_gpu_h2d(i64, ptr, i64)
declare void @mapal_gpu_d2h(ptr, i64, i64, i64)
declare void @mapal_gpu_launch(i64, i64, i64, i64, i32, i32, i32, i32)
declare void @mapal_gpu_gen(i64, i64, i64)
declare void @mapal_gpu_free(ptr)
declare i64 @mapal_gpu_arena(ptr, i64)

define internal void @mapal_main() {
entry:
  %darena = alloca i64
  store i64 0, ptr %darena
  %o8 = alloca { ptr, ptr, ptr, ptr }
  %o10 = alloca { ptr, i32 }
  %o11 = alloca float
  %o12 = alloca float
  %d0 = alloca i64
  store i64 0, ptr %d0
  %d4 = alloca i64
  store i64 0, ptr %d4
  %d12 = alloca i64
  store i64 0, ptr %d12
  %s20 = alloca float
  %t2 = call i64 @mapal_gpu_arena(ptr %darena, i64 132608)
  %t1 = add i64 %t2, 0
  store i64 %t1, ptr %d0
  call void @mapal_gpu_gen(i64 -124799445313411710, i64 %t1, i64 128)
  %t3 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o8, i32 0, i32 1
  store ptr null, ptr %t3
  %t6 = call i64 @mapal_gpu_arena(ptr %darena, i64 132608)
  %t5 = add i64 %t6, 512
  store i64 %t5, ptr %d4
  call void @mapal_gpu_gen(i64 6696365533415965814, i64 %t5, i64 32768)
  %t7 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o8, i32 0, i32 2
  store ptr null, ptr %t7
  %t8 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o8, i32 0, i32 0
  store ptr null, ptr %t8
  %t9 = getelementptr { ptr, ptr, ptr, ptr }, ptr %o8, i32 0, i32 3
  store ptr null, ptr %t9
  %t10 = load i64, ptr %d0
  %t11 = load i64, ptr %d4
  %t14 = call i64 @mapal_gpu_arena(ptr %darena, i64 132608)
  %t13 = add i64 %t14, 131584
  store i64 %t13, ptr %d12
  call void @mapal_gpu_launch(i64 -3090978098701300393, i64 %t10, i64 %t11, i64 %t13, i32 1, i32 1, i32 256, i32 0)
  %t15 = getelementptr { ptr, i32 }, ptr %o10, i32 0, i32 0
  store ptr null, ptr %t15
  %t16 = getelementptr { ptr, i32 }, ptr %o10, i32 0, i32 1
  store i32 0, ptr %t16
  %t17 = getelementptr { ptr, i32 }, ptr %o10, i32 0, i32 1
  %t18 = load i32, ptr %t17
  %t19 = sext i32 %t18 to i64
  %t21 = load i64, ptr %d12
  %t22 = mul i64 %t19, 4
  call void @mapal_gpu_d2h(ptr %s20, i64 %t21, i64 %t22, i64 4)
  %t23 = load float, ptr %s20
  store float %t23, ptr %o11
  %t24 = load float, ptr %o11
  store float %t24, ptr %o12
  %t25 = load float, ptr %o12
  call void @mapal_print_f32(float %t25, i1 zeroext true)
  call void @mapal_gpu_free(ptr %darena)
  ret void
}

define internal float @fn1(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = sitofp i32 %t0 to float
  store float %t1, ptr %o1
  %t2 = load float, ptr %o1
  ret float %t2
}

define internal float @fn2(i32 %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca i32
  %o1 = alloca float
  store i32 %arg, ptr %o0
  %t0 = load i32, ptr %o0
  %t1 = sitofp i32 %t0 to float
  store float %t1, ptr %o1
  %t2 = load float, ptr %o1
  ret float %t2
}

define internal float @fn3({ ptr, ptr, i32, float, i32 } %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca { ptr, ptr, i32, float, i32 }
  %o1 = alloca float
  %o2 = alloca ptr
  %o3 = alloca ptr
  %o4 = alloca i32
  %o5 = alloca float
  %o6 = alloca i32
  %o7 = alloca { ptr, i32 }
  %o8 = alloca float
  %o9 = alloca { i32, i32 }
  %o10 = alloca i32
  %o11 = alloca { i32, i32 }
  %o12 = alloca i32
  %o13 = alloca { ptr, i32 }
  %o14 = alloca float
  %o15 = alloca { float, float }
  %o16 = alloca float
  %o17 = alloca { float, float }
  store { ptr, ptr, i32, float, i32 } %arg, ptr %o0
  %t0 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 0
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %o2
  %t2 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 1
  %t3 = load ptr, ptr %t2
  store ptr %t3, ptr %o3
  %t4 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 2
  %t5 = load i32, ptr %t4
  store i32 %t5, ptr %o4
  %t6 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 3
  %t7 = load float, ptr %t6
  store float %t7, ptr %o5
  %t8 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %o0, i32 0, i32 4
  %t9 = load i32, ptr %t8
  store i32 %t9, ptr %o6
  %t10 = load ptr, ptr %o2
  %t11 = getelementptr { ptr, i32 }, ptr %o7, i32 0, i32 0
  store ptr %t10, ptr %t11
  %t12 = load ptr, ptr %o3
  %t13 = getelementptr { ptr, i32 }, ptr %o13, i32 0, i32 0
  store ptr %t12, ptr %t13
  %t14 = load i32, ptr %o4
  %t15 = getelementptr { i32, i32 }, ptr %o9, i32 0, i32 0
  store i32 %t14, ptr %t15
  %t16 = load float, ptr %o5
  %t17 = getelementptr { float, float }, ptr %o17, i32 0, i32 1
  store float %t16, ptr %t17
  %t18 = load i32, ptr %o6
  %t19 = getelementptr { ptr, i32 }, ptr %o7, i32 0, i32 1
  store i32 %t18, ptr %t19
  %t20 = load i32, ptr %o6
  %t21 = getelementptr { i32, i32 }, ptr %o11, i32 0, i32 1
  store i32 %t20, ptr %t21
  %t22 = load ptr, ptr %o2
  %t23 = getelementptr { ptr, i32 }, ptr %o7, i32 0, i32 1
  %t24 = load i32, ptr %t23
  %t25 = sext i32 %t24 to i64
  %t26 = getelementptr [128 x float], ptr %t22, i64 0, i64 %t25
  %t27 = load float, ptr %t26
  store float %t27, ptr %o8
  %t28 = load float, ptr %o8
  %t29 = getelementptr { float, float }, ptr %o15, i32 0, i32 0
  store float %t28, ptr %t29
  %t30 = getelementptr { i32, i32 }, ptr %o9, i32 0, i32 1
  store i32 128, ptr %t30
  %t31 = getelementptr { i32, i32 }, ptr %o9, i32 0, i32 0
  %t32 = load i32, ptr %t31
  %t33 = getelementptr { i32, i32 }, ptr %o9, i32 0, i32 1
  %t34 = load i32, ptr %t33
  %t35 = mul i32 %t32, %t34
  store i32 %t35, ptr %o10
  %t36 = load i32, ptr %o10
  %t37 = getelementptr { i32, i32 }, ptr %o11, i32 0, i32 0
  store i32 %t36, ptr %t37
  %t38 = getelementptr { i32, i32 }, ptr %o11, i32 0, i32 0
  %t39 = load i32, ptr %t38
  %t40 = getelementptr { i32, i32 }, ptr %o11, i32 0, i32 1
  %t41 = load i32, ptr %t40
  %t42 = add i32 %t39, %t41
  store i32 %t42, ptr %o12
  %t43 = load i32, ptr %o12
  %t44 = getelementptr { ptr, i32 }, ptr %o13, i32 0, i32 1
  store i32 %t43, ptr %t44
  %t45 = load ptr, ptr %o3
  %t46 = getelementptr { ptr, i32 }, ptr %o13, i32 0, i32 1
  %t47 = load i32, ptr %t46
  %t48 = sext i32 %t47 to i64
  %t49 = getelementptr [32768 x float], ptr %t45, i64 0, i64 %t48
  %t50 = load float, ptr %t49
  store float %t50, ptr %o14
  %t51 = load float, ptr %o14
  %t52 = getelementptr { float, float }, ptr %o15, i32 0, i32 1
  store float %t51, ptr %t52
  %t53 = getelementptr { float, float }, ptr %o15, i32 0, i32 0
  %t54 = load float, ptr %t53
  %t55 = getelementptr { float, float }, ptr %o15, i32 0, i32 1
  %t56 = load float, ptr %t55
  %t57 = fmul float %t54, %t56
  store float %t57, ptr %o16
  %t58 = load float, ptr %o16
  %t59 = getelementptr { float, float }, ptr %o17, i32 0, i32 0
  store float %t58, ptr %t59
  %t60 = getelementptr { float, float }, ptr %o17, i32 0, i32 0
  %t61 = load float, ptr %t60
  %t62 = getelementptr { float, float }, ptr %o17, i32 0, i32 1
  %t63 = load float, ptr %t62
  %t64 = fadd float %t61, %t63
  store float %t64, ptr %o1
  %t65 = load float, ptr %o1
  ret float %t65
}

define internal float @fn4({ ptr, ptr, ptr, i32 } %arg) readonly nounwind willreturn {
entry:
  %o0 = alloca { ptr, ptr, ptr, i32 }
  %o1 = alloca float
  %o2 = alloca ptr
  %o3 = alloca ptr
  %o4 = alloca ptr
  %o5 = alloca i32
  %o6 = alloca { ptr, ptr, i32, float, ptr }
  %s20 = alloca float
  %s21 = alloca i64
  %s30 = alloca { ptr, ptr, i32, float, i32 }
  store { ptr, ptr, ptr, i32 } %arg, ptr %o0
  %t0 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 0
  %t1 = load ptr, ptr %t0
  store ptr %t1, ptr %o2
  %t2 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 1
  %t3 = load ptr, ptr %t2
  store ptr %t3, ptr %o3
  %t4 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 2
  %t5 = load ptr, ptr %t4
  store ptr %t5, ptr %o4
  %t6 = getelementptr { ptr, ptr, ptr, i32 }, ptr %o0, i32 0, i32 3
  %t7 = load i32, ptr %t6
  store i32 %t7, ptr %o5
  %t8 = load ptr, ptr %o2
  %t9 = getelementptr { ptr, ptr, i32, float, ptr }, ptr %o6, i32 0, i32 4
  store ptr %t8, ptr %t9
  %t10 = load ptr, ptr %o3
  %t11 = getelementptr { ptr, ptr, i32, float, ptr }, ptr %o6, i32 0, i32 0
  store ptr %t10, ptr %t11
  %t12 = load ptr, ptr %o4
  %t13 = getelementptr { ptr, ptr, i32, float, ptr }, ptr %o6, i32 0, i32 1
  store ptr %t12, ptr %t13
  %t14 = load i32, ptr %o5
  %t15 = getelementptr { ptr, ptr, i32, float, ptr }, ptr %o6, i32 0, i32 2
  store i32 %t14, ptr %t15
  %t16 = getelementptr { ptr, ptr, i32, float, ptr }, ptr %o6, i32 0, i32 3
  store float 0x4000000000000000, ptr %t16
  %t17 = getelementptr { ptr, ptr, i32, float, ptr }, ptr %o6, i32 0, i32 3
  %t18 = load float, ptr %t17
  %t19 = load ptr, ptr %o2
  store float %t18, ptr %s20
  store i64 0, ptr %s21
  br label %bb22
bb22:
  %t25 = load i64, ptr %s21
  %t26 = icmp uge i64 %t25, 128
  br i1 %t26, label %bb24, label %bb23
bb23:
  %t27 = getelementptr [128 x i32], ptr %t19, i64 0, i64 %t25
  %t28 = load i32, ptr %t27
  %t29 = load float, ptr %s20
  %t31 = load ptr, ptr %o3
  %t32 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %s30, i32 0, i32 0
  store ptr %t31, ptr %t32
  %t33 = load ptr, ptr %o4
  %t34 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %s30, i32 0, i32 1
  store ptr %t33, ptr %t34
  %t35 = getelementptr { ptr, ptr, i32, float, ptr }, ptr %o6, i32 0, i32 2
  %t36 = load i32, ptr %t35
  %t37 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %s30, i32 0, i32 2
  store i32 %t36, ptr %t37
  %t38 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %s30, i32 0, i32 3
  store float %t29, ptr %t38
  %t39 = getelementptr { ptr, ptr, i32, float, i32 }, ptr %s30, i32 0, i32 4
  store i32 %t28, ptr %t39
  %t40 = load { ptr, ptr, i32, float, i32 }, ptr %s30
  %t41 = call float @fn3({ ptr, ptr, i32, float, i32 } %t40)
  store float %t41, ptr %s20
  %t42 = add i64 %t25, 1
  store i64 %t42, ptr %s21
  br label %bb22
bb24:
  %t43 = load float, ptr %s20
  store float %t43, ptr %o1
  %t44 = load float, ptr %o1
  ret float %t44
}

define i32 @main() {
entry:
  call void @mapal_gpu_init(i32 1)
  call void @mapal_main()
  ret i32 0
}
